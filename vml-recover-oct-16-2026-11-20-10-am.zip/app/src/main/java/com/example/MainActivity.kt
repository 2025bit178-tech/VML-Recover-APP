package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.AppDatabase
import com.example.data.model.PlatformMode
import com.example.repository.VmlRepository
import com.example.ui.components.CrossPlatformGuideDialog
import com.example.ui.components.VmlBottomNavigationBar
import com.example.ui.components.VmlTopAppBar
import com.example.ui.screens.AdminAnalyticsScreen
import com.example.ui.screens.AdminControlScreen
import com.example.ui.screens.AdminPasswordManagementDialog
import com.example.ui.screens.CaseDetailScreen
import com.example.ui.screens.CaseListScreen
import com.example.ui.screens.ClientPortalScreen
import com.example.ui.screens.CollectionManagerScreen
import com.example.ui.screens.CreatePaymentPlanDialog
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DebtorPortalScreen
import com.example.ui.screens.EscalateStageDialog
import com.example.ui.screens.FieldOfficerScreen
import com.example.ui.screens.FinanceOfficerScreen
import com.example.ui.screens.LegalHubScreen
import com.example.ui.screens.LogCallDialog
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.ReportsScreen

import com.example.ui.screens.NewCaseDialog
import com.example.ui.screens.PromiseTrackerScreen
import com.example.ui.screens.RecordPaymentDialog
import com.example.ui.screens.RecordPromiseDialog
import com.example.service.SmsNotificationService
import com.example.ui.screens.ScheduleVisitDialog
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.VmlNavyDark
import com.example.viewmodel.NavigationScreen
import com.example.viewmodel.UserRole
import com.example.viewmodel.VmlViewModel
import com.example.viewmodel.VmlViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(applicationContext, lifecycleScope)
        val repository = VmlRepository(database)
        val smsService = SmsNotificationService(applicationContext, database.smsNotificationDao())
        val firebaseService = com.example.data.firebase.FirebaseRealtimeDbService(applicationContext, database, lifecycleScope)
        val viewModelFactory = VmlViewModelFactory(repository, smsService, firebaseService)

        setContent {
            MyApplicationTheme(darkTheme = true) {
                val viewModel: VmlViewModel = viewModel(factory = viewModelFactory)
                VmlApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun VmlApp(viewModel: VmlViewModel) {
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val currentRole by viewModel.currentRole.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()
    val metrics by viewModel.portfolioMetrics.collectAsState()

    // Dialog state management
    var showNewCaseDialog by remember { mutableStateOf(false) }
    var showAdminPasswordDialog by remember { mutableStateOf(false) }
    var showCrossPlatformGuide by remember { mutableStateOf(false) }
    var paymentDialogCaseId by remember { mutableStateOf<String?>(null) }
    var promiseDialogData by remember { mutableStateOf<Pair<String, String>?>(null) }
    var callDialogCaseId by remember { mutableStateOf<String?>(null) }
    var escalateDialogData by remember { mutableStateOf<Pair<String, String>?>(null) }
    var planDialogData by remember { mutableStateOf<Triple<String, String, Double>?>(null) }
    var visitDialogData by remember { mutableStateOf<Triple<String, String, String>?>(null) }

    // Role-specific Tab States
    val debtorTab by viewModel.debtorPortalTab.collectAsState()
    val financeTab by viewModel.financeOfficerTab.collectAsState()
    val managerTab by viewModel.collectionManagerTab.collectAsState()
    val clientTab by viewModel.clientPortalTab.collectAsState()
    val platformMode by viewModel.platformMode.collectAsState()

    // If not authenticated, present the secure Login Gateway
    if (!isLoggedIn) {
        LoginScreen(
            viewModel = viewModel,
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        )
    } else {
        // Determine home screen for current role
        val roleHomeScreen = when (currentRole) {
            UserRole.ADMIN -> NavigationScreen.ADMIN_SYSTEM_CONTROL
            UserRole.DIRECTOR -> NavigationScreen.DASHBOARD
            UserRole.COLLECTION_MANAGER -> NavigationScreen.MANAGER_SUPERVISION
            UserRole.COLLECTION_OFFICER -> NavigationScreen.CASES
            UserRole.LEGAL_OFFICER -> NavigationScreen.LEGAL_HUB
            UserRole.FINANCE_OFFICER -> NavigationScreen.FINANCE_RECONCILIATION
            UserRole.CLIENT_PORTAL -> NavigationScreen.CLIENT_PORTAL
            UserRole.DEBTOR_PORTAL -> NavigationScreen.DEBTOR_PORTAL
        }

        // Handle back button
        BackHandler(enabled = currentScreen != roleHomeScreen) {
            if (currentScreen == NavigationScreen.CASE_DETAIL) {
                viewModel.navigateTo(NavigationScreen.CASES)
            } else {
                viewModel.navigateTo(roleHomeScreen)
            }
        }

        Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        containerColor = VmlNavyDark,
        topBar = {
            VmlTopAppBar(
                currentRole = currentRole,
                currentUser = currentUser,
                onRoleSelected = { role -> viewModel.switchRole(role) },
                onLogout = { viewModel.logout() },
                onOpenPasswordManagement = { showAdminPasswordDialog = true },
                canNavigateBack = currentScreen != roleHomeScreen,
                onNavigateBack = {
                    if (currentScreen == NavigationScreen.CASE_DETAIL) {
                        viewModel.navigateTo(NavigationScreen.CASES)
                    } else {
                        viewModel.navigateTo(roleHomeScreen)
                    }
                },
                platformMode = platformMode,
                onSelectPlatformMode = { mode -> viewModel.setPlatformMode(mode) },
                onOpenCrossPlatformGuide = { showCrossPlatformGuide = true }
            )
        },
        bottomBar = {
            VmlBottomNavigationBar(
                currentScreen = currentScreen,
                currentRole = currentRole,
                onNavigate = { screen -> viewModel.navigateTo(screen) },
                criticalCount = metrics.criticalCasesCount,
                ptpCount = metrics.followUpsDueCount,
                debtorTab = debtorTab,
                onSelectDebtorTab = { tab -> viewModel.setDebtorPortalTab(tab) },
                financeTab = financeTab,
                onSelectFinanceTab = { tab -> viewModel.setFinanceOfficerTab(tab) },
                managerTab = managerTab,
                onSelectManagerTab = { tab -> viewModel.setCollectionManagerTab(tab) },
                clientTab = clientTab,
                onSelectClientTab = { tab -> viewModel.setClientPortalTab(tab) }
            )
        }
    ) { innerPadding ->
        val screenModifier = Modifier.padding(innerPadding)

        when (currentScreen) {
            NavigationScreen.DASHBOARD -> {
                DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToCases = { viewModel.navigateTo(NavigationScreen.CASES) },
                    onNavigateToCaseDetail = { caseId -> viewModel.selectCase(caseId) },
                    onNavigateToLegal = { viewModel.navigateTo(NavigationScreen.LEGAL_HUB) },
                    onNavigateToPromises = { viewModel.navigateTo(NavigationScreen.PROMISES) },
                    onNavigateToVisits = { viewModel.navigateTo(NavigationScreen.FIELD_VISITS) },
                    onOpenNewCaseDialog = { showNewCaseDialog = true },
                    onOpenPaymentDialog = { paymentDialogCaseId = "VML-2026-00482" },
                    onOpenPromiseDialog = { promiseDialogData = Pair("VML-2026-00482", "Mukasa Godfrey Kasule") },
                    onNavigateToAnalytics = { viewModel.navigateTo(NavigationScreen.ADMIN_ANALYTICS) },
                    modifier = screenModifier
                )
            }
            NavigationScreen.ADMIN_SYSTEM_CONTROL -> {
                AdminControlScreen(
                    viewModel = viewModel,
                    onOpenPasswordManagement = { showAdminPasswordDialog = true },
                    modifier = screenModifier
                )
            }
            NavigationScreen.ADMIN_ANALYTICS -> {
                AdminAnalyticsScreen(
                    viewModel = viewModel,
                    modifier = screenModifier
                )
            }
            NavigationScreen.MANAGER_SUPERVISION,
            NavigationScreen.MANAGER_ALLOCATION -> {
                CollectionManagerScreen(
                    viewModel = viewModel,
                    onNavigateToCaseDetail = { caseId -> viewModel.selectCase(caseId) },
                    modifier = screenModifier
                )
            }
            NavigationScreen.FINANCE_RECONCILIATION -> {
                FinanceOfficerScreen(
                    viewModel = viewModel,
                    modifier = screenModifier
                )
            }
            NavigationScreen.DEBTOR_PORTAL -> {
                DebtorPortalScreen(
                    viewModel = viewModel,
                    modifier = screenModifier
                )
            }
            NavigationScreen.CASES -> {
                CaseListScreen(
                    viewModel = viewModel,
                    onCaseSelected = { caseId -> viewModel.selectCase(caseId) },
                    onOpenNewCaseDialog = { showNewCaseDialog = true },
                    modifier = screenModifier
                )
            }
            NavigationScreen.CASE_DETAIL -> {
                CaseDetailScreen(
                    viewModel = viewModel,
                    onBack = { viewModel.navigateTo(NavigationScreen.CASES) },
                    onOpenCallDialog = { id -> callDialogCaseId = id },
                    onOpenPaymentDialog = { id -> paymentDialogCaseId = id },
                    onOpenPromiseDialog = { id, name -> promiseDialogData = Pair(id, name) },
                    onOpenEscalateDialog = { id, stage -> escalateDialogData = Pair(id, stage) },
                    onOpenPlanDialog = { id, name, bal -> planDialogData = Triple(id, name, bal) },
                    onOpenVisitDialog = { id, name, addr -> visitDialogData = Triple(id, name, addr) },
                    modifier = screenModifier
                )
            }
            NavigationScreen.LEGAL_HUB -> {
                LegalHubScreen(
                    viewModel = viewModel,
                    onNavigateToCase = { caseId -> viewModel.selectCase(caseId) },
                    modifier = screenModifier
                )
            }
            NavigationScreen.PROMISES -> {
                PromiseTrackerScreen(
                    viewModel = viewModel,
                    onNavigateToCase = { caseId -> viewModel.selectCase(caseId) },
                    modifier = screenModifier
                )
            }
            NavigationScreen.FIELD_VISITS -> {
                FieldOfficerScreen(
                    viewModel = viewModel,
                    onNavigateToCase = { caseId -> viewModel.selectCase(caseId) },
                    modifier = screenModifier
                )
            }
            NavigationScreen.CLIENT_PORTAL -> {
                ClientPortalScreen(
                    viewModel = viewModel,
                    modifier = screenModifier
                )
            }
            NavigationScreen.PAYMENT_ENGINE -> {
                DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToCases = { viewModel.navigateTo(NavigationScreen.CASES) },
                    onNavigateToCaseDetail = { caseId -> viewModel.selectCase(caseId) },
                    onNavigateToLegal = { viewModel.navigateTo(NavigationScreen.LEGAL_HUB) },
                    onNavigateToPromises = { viewModel.navigateTo(NavigationScreen.PROMISES) },
                    onNavigateToVisits = { viewModel.navigateTo(NavigationScreen.FIELD_VISITS) },
                    onOpenNewCaseDialog = { showNewCaseDialog = true },
                    onOpenPaymentDialog = { paymentDialogCaseId = "VML-2026-00482" },
                    onOpenPromiseDialog = { promiseDialogData = Pair("VML-2026-00482", "Mukasa Godfrey Kasule") },
                    modifier = screenModifier
                )
            }
            NavigationScreen.REPORTS -> {
                ReportsScreen(
                    viewModel = viewModel,
                    modifier = screenModifier
                )
            }
        }
    }

    if (showAdminPasswordDialog) {
        AdminPasswordManagementDialog(
            viewModel = viewModel,
            onDismiss = { showAdminPasswordDialog = false }
        )
    }

    if (showCrossPlatformGuide) {
        CrossPlatformGuideDialog(
            platformMode = platformMode,
            onSelectPlatformMode = { mode -> viewModel.setPlatformMode(mode) },
            onDismiss = { showCrossPlatformGuide = false }
        )
    }

    // Modal Action Dialogs
    if (showNewCaseDialog) {
        NewCaseDialog(
            onDismiss = { showNewCaseDialog = false },
            onSubmit = { dName, dId, phone, email, address, employer, cred, acc, ref, p, i, pen, off ->
                viewModel.registerNewCase(dName, dId, phone, email, address, employer, cred, acc, ref, p, i, pen, off)
                showNewCaseDialog = false
            }
        )
    }

    if (paymentDialogCaseId != null) {
        val caseId = paymentDialogCaseId!!
        RecordPaymentDialog(
            caseId = caseId,
            onDismiss = { paymentDialogCaseId = null },
            onSubmit = { amount, channel, receipt, notes ->
                viewModel.recordPayment(caseId, amount, channel, receipt, notes)
                paymentDialogCaseId = null
            }
        )
    }

    if (promiseDialogData != null) {
        val (caseId, debtorName) = promiseDialogData!!
        RecordPromiseDialog(
            caseId = caseId,
            debtorName = debtorName,
            onDismiss = { promiseDialogData = null },
            onSubmit = { amount, date, method, notes ->
                viewModel.recordPromise(caseId, debtorName, amount, date, method, notes)
                promiseDialogData = null
            }
        )
    }

    if (callDialogCaseId != null) {
        val caseId = callDialogCaseId!!
        LogCallDialog(
            caseId = caseId,
            onDismiss = { callDialogCaseId = null },
            onSubmit = { title, notes, ack ->
                viewModel.logCall(caseId, title, notes, ack)
                callDialogCaseId = null
            }
        )
    }

    if (escalateDialogData != null) {
        val (caseId, currentStage) = escalateDialogData!!
        EscalateStageDialog(
            caseId = caseId,
            currentStage = currentStage,
            onDismiss = { escalateDialogData = null },
            onSubmit = { nextStage, notes ->
                viewModel.escalateLegalStage(caseId, nextStage, notes)
                escalateDialogData = null
            }
        )
    }

    if (planDialogData != null) {
        val (caseId, debtorName, balance) = planDialogData!!
        CreatePaymentPlanDialog(
            caseId = caseId,
            debtorName = debtorName,
            outstandingBalance = balance,
            onDismiss = { planDialogData = null },
            onSubmit = { amt, count, freq, start ->
                viewModel.createPaymentPlan(caseId, debtorName, amt, count, freq, start)
                planDialogData = null
            }
        )
    }

    if (visitDialogData != null) {
        val (caseId, debtorName, address) = visitDialogData!!
        ScheduleVisitDialog(
            caseId = caseId,
            debtorName = debtorName,
            address = address,
            onDismiss = { visitDialogData = null },
            onSubmit = { time, outcome ->
                viewModel.scheduleFieldVisit(caseId, debtorName, address, time, outcome)
                visitDialogData = null
            }
        )
    }
    }
}

