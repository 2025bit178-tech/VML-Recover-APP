package com.example.service

import android.content.Context
import com.example.data.dao.SmsNotificationDao
import com.example.data.model.CaseEntity
import com.example.data.model.SmsNotificationEntity
import com.example.data.model.UserEntity
import com.example.data.security.SecurityUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SmsNotificationService(
    private val context: Context,
    private val smsNotificationDao: SmsNotificationDao
) {
    private val _liveSmsEvents = MutableSharedFlow<SmsNotificationEntity>(replay = 0, extraBufferCapacity = 10)
    val liveSmsEvents: SharedFlow<SmsNotificationEntity> = _liveSmsEvents.asSharedFlow()

    private fun formatCurrency(amount: Double): String {
        return NumberFormat.getNumberInstance(Locale.US).format(amount.toLong())
    }

    private fun formatTimestamp(timestamp: Long): String {
        return SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(timestamp))
    }

    suspend fun dispatchSms(
        recipientPhone: String,
        recipientName: String,
        eventType: String,
        messageContent: String,
        referenceId: String? = null
    ): SmsNotificationEntity = withContext(Dispatchers.IO) {
        val sanitizedPhone = recipientPhone.trim()
        val isValid = SecurityUtils.isValidPhoneNumber(sanitizedPhone)
        val status = if (isValid) "DELIVERED" else "FAILED_INVALID_PHONE"

        val sms = SmsNotificationEntity(
            recipientPhone = sanitizedPhone,
            recipientName = recipientName,
            eventType = eventType,
            messageContent = messageContent,
            timestamp = System.currentTimeMillis(),
            status = status,
            referenceId = referenceId
        )

        val id = smsNotificationDao.insertSms(sms)
        val savedSms = sms.copy(id = id)
        _liveSmsEvents.emit(savedSms)
        savedSms
    }

    suspend fun sendLoginSms(user: UserEntity): SmsNotificationEntity {
        val timeStr = formatTimestamp(System.currentTimeMillis())
        val msg = "VML Security Alert: User ${user.fullName} logged into VML Recover portal at $timeStr. If this was not you, contact Admin immediately."
        return dispatchSms(
            recipientPhone = user.phoneNumber,
            recipientName = user.fullName,
            eventType = "LOGIN",
            messageContent = msg,
            referenceId = user.userId
        )
    }

    suspend fun sendNewDebtSms(caseItem: CaseEntity): SmsNotificationEntity {
        val amountStr = formatCurrency(caseItem.totalOutstanding)
        val maskedPhone = SecurityUtils.maskPhoneNumber(caseItem.debtorPhone)
        val msg = "Dear ${caseItem.debtorName}, a formal loan recovery case (${caseItem.caseId}) for UGX $amountStr has been assigned to VML Recoveries on behalf of ${caseItem.creditorName}. Due date: ${caseItem.dueDate}. Kindly clear or submit a repayment plan."
        return dispatchSms(
            recipientPhone = caseItem.debtorPhone,
            recipientName = caseItem.debtorName,
            eventType = "NEW_DEBT",
            messageContent = msg,
            referenceId = caseItem.caseId
        )
    }

    suspend fun sendPaymentConfirmationSms(
        caseItem: CaseEntity,
        amount: Double,
        receiptNo: String,
        channel: String
    ): SmsNotificationEntity {
        val amountStr = formatCurrency(amount)
        val balanceStr = formatCurrency(caseItem.totalOutstanding - amount)
        val msg = "Payment Confirmed! Receipt: $receiptNo. Received UGX $amountStr for Case ${caseItem.caseId} via $channel. Outstanding Balance: UGX $balanceStr. Thank you for using VML Recover direct payments."
        return dispatchSms(
            recipientPhone = caseItem.debtorPhone,
            recipientName = caseItem.debtorName,
            eventType = "PAYMENT_CONFIRMATION",
            messageContent = msg,
            referenceId = receiptNo
        )
    }

    suspend fun sendCreditSms(
        creditorName: String,
        creditorPhone: String,
        amount: Double,
        receiptNo: String,
        caseId: String
    ): SmsNotificationEntity {
        val amountStr = formatCurrency(amount)
        val msg = "Credit Advice to $creditorName: Direct recovery collection of UGX $amountStr (Ref: $receiptNo) received for Case $caseId. Verified and recorded in VML Recover."
        return dispatchSms(
            recipientPhone = creditorPhone,
            recipientName = creditorName,
            eventType = "CREDIT_CONFIRMATION",
            messageContent = msg,
            referenceId = receiptNo
        )
    }

    suspend fun sendPaymentReminderSms(
        caseItem: CaseEntity,
        promisedOrDueAmount: Double,
        scheduledDate: String
    ): SmsNotificationEntity {
        val amountStr = formatCurrency(promisedOrDueAmount)
        val msg = "Payment Reminder: Dear ${caseItem.debtorName}, your scheduled instalment of UGX $amountStr for Case ${caseItem.caseId} is due on $scheduledDate. Please authorise direct payment in your borrower portal."
        return dispatchSms(
            recipientPhone = caseItem.debtorPhone,
            recipientName = caseItem.debtorName,
            eventType = "PAYMENT_REMINDER",
            messageContent = msg,
            referenceId = caseItem.caseId
        )
    }

    suspend fun sendSecurityLockoutSms(user: UserEntity, reason: String): SmsNotificationEntity {
        val msg = "VML Security: Account ${user.email} has been LOCKED due to: $reason. Contact System Admin to unlock."
        return dispatchSms(
            recipientPhone = user.phoneNumber,
            recipientName = user.fullName,
            eventType = "SECURITY_LOCKOUT",
            messageContent = msg,
            referenceId = user.userId
        )
    }

    suspend fun sendAccountUnlockedSms(user: UserEntity): SmsNotificationEntity {
        val msg = "VML Security: Account ${user.email} has been UNLOCKED by the Administrator. You may now log in securely."
        return dispatchSms(
            recipientPhone = user.phoneNumber,
            recipientName = user.fullName,
            eventType = "SECURITY_UNLOCK",
            messageContent = msg,
            referenceId = user.userId
        )
    }

    suspend fun sendCustomSms(
        recipientPhone: String,
        recipientName: String,
        eventType: String,
        messageContent: String,
        referenceId: String? = null
    ): SmsNotificationEntity {
        return dispatchSms(recipientPhone, recipientName, eventType, messageContent, referenceId)
    }
}
