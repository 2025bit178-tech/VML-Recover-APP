package com.example.data.firebase

import android.content.Context
import android.util.Log
import com.example.data.AppDatabase
import com.example.data.model.CaseEntity
import com.example.data.model.PaymentTransactionEntity
import com.google.firebase.FirebaseApp
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Service managing real-time data streaming with Firebase Realtime Database.
 * Connects the Android Studio architecture with cloud real-time updates.
 */
class FirebaseRealtimeDbService(
    private val context: Context,
    private val database: AppDatabase,
    private val scope: CoroutineScope
) {
    private val TAG = "FirebaseRTDB"

    private var rtdb: FirebaseDatabase? = null
    private var casesRef: DatabaseReference? = null
    private var paymentsRef: DatabaseReference? = null

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _lastSyncTimestamp = MutableStateFlow<Long?>(null)
    val lastSyncTimestamp: StateFlow<Long?> = _lastSyncTimestamp.asStateFlow()

    private val _syncStatusMessage = MutableStateFlow("Firebase Realtime Database Initialized")
    val syncStatusMessage: StateFlow<String> = _syncStatusMessage.asStateFlow()

    init {
        initializeFirebase()
    }

    private fun initializeFirebase() {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }

            val fbInstance = try {
                FirebaseDatabase.getInstance()
            } catch (e: Exception) {
                Log.w(TAG, "Default FirebaseDatabase init fallback: ${e.message}")
                null
            }

            if (fbInstance != null) {
                rtdb = fbInstance
                try {
                    fbInstance.setPersistenceEnabled(true)
                } catch (ignored: Exception) {
                    // Persistence can only be set once
                }

                casesRef = fbInstance.getReference("cases")
                paymentsRef = fbInstance.getReference("payments")

                // Listen to connection state
                val connectedRef = fbInstance.getReference(".info/connected")
                connectedRef.addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val connected = snapshot.getValue(Boolean::class.java) ?: false
                        _isConnected.value = connected
                        _syncStatusMessage.value = if (connected) {
                            "Firebase Realtime Database: Online & Live"
                        } else {
                            "Firebase Realtime Database: Local Cached (Offline Mode)"
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Log.w(TAG, "Connection listener cancelled: ${error.message}")
                    }
                })

                // Listen for remote real-time updates on cases
                casesRef?.addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        _lastSyncTimestamp.value = System.currentTimeMillis()
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Log.e(TAG, "Cases sync error: ${error.message}")
                    }
                })
            } else {
                _syncStatusMessage.value = "Firebase RTDB Ready (Awaiting Cloud Project Binding)"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing Firebase Realtime Database: ${e.message}", e)
            _syncStatusMessage.value = "RTDB Offline Persistence Active"
        }
    }

    /**
     * Broadcasts a new or updated debtor case to Firebase Realtime Database
     */
    fun pushCaseUpdate(case: CaseEntity) {
        scope.launch(Dispatchers.IO) {
            try {
                casesRef?.child(case.caseId)?.setValue(
                    mapOf(
                        "caseId" to case.caseId,
                        "debtorName" to case.debtorName,
                        "debtorNationalId" to case.debtorNationalId,
                        "debtorPhone" to case.debtorPhone,
                        "debtorEmail" to case.debtorEmail,
                        "debtorAddress" to case.debtorAddress,
                        "creditorName" to case.creditorName,
                        "principalAmount" to case.principalAmount,
                        "interestAmount" to case.interestAmount,
                        "penaltiesAmount" to case.penaltiesAmount,
                        "amountPaid" to case.amountPaid,
                        "status" to case.status,
                        "legalStage" to case.legalStage,
                        "assignedOfficerName" to case.assignedOfficerName,
                        "lastUpdated" to System.currentTimeMillis()
                    )
                )
                _lastSyncTimestamp.value = System.currentTimeMillis()
            } catch (e: Exception) {
                Log.w(TAG, "Failed to push case update to Firebase: ${e.message}")
            }
        }
    }

    /**
     * Broadcasts a payment record to Firebase Realtime Database
     */
    fun pushPaymentRecord(payment: PaymentTransactionEntity) {
        scope.launch(Dispatchers.IO) {
            try {
                paymentsRef?.child(payment.receiptNumber)?.setValue(
                    mapOf(
                        "caseId" to payment.caseId,
                        "amount" to payment.amount,
                        "paymentDate" to payment.paymentDate,
                        "paymentChannel" to payment.paymentChannel,
                        "receiptNumber" to payment.receiptNumber,
                        "recordedBy" to payment.recordedBy,
                        "notes" to payment.notes,
                        "syncedAt" to System.currentTimeMillis()
                    )
                )
                _lastSyncTimestamp.value = System.currentTimeMillis()
            } catch (e: Exception) {
                Log.w(TAG, "Failed to push payment to Firebase: ${e.message}")
            }
        }
    }
}
