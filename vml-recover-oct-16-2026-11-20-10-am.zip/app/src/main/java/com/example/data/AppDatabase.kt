package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.AuditLogDao
import com.example.data.dao.CaseDao
import com.example.data.dao.FieldVisitDao
import com.example.data.dao.LegalDocDao
import com.example.data.dao.PaymentDao
import com.example.data.dao.PaymentPlanDao
import com.example.data.dao.PromiseDao
import com.example.data.dao.SmsNotificationDao
import com.example.data.dao.SystemConfigDao
import com.example.data.dao.TimelineDao
import com.example.data.dao.UserDao
import com.example.data.model.AuditLogEntity
import com.example.data.model.CaseEntity
import com.example.data.model.FieldVisitEntity
import com.example.data.model.LegalDocumentEntity
import com.example.data.model.PaymentPlanEntity
import com.example.data.model.PaymentTransactionEntity
import com.example.data.model.PromiseToPayEntity
import com.example.data.model.SmsNotificationEntity
import com.example.data.model.SystemConfigEntity
import com.example.data.model.TimelineActionEntity
import com.example.data.model.UserEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        CaseEntity::class,
        PaymentTransactionEntity::class,
        PromiseToPayEntity::class,
        FieldVisitEntity::class,
        PaymentPlanEntity::class,
        LegalDocumentEntity::class,
        TimelineActionEntity::class,
        SmsNotificationEntity::class,
        SystemConfigEntity::class,
        AuditLogEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun caseDao(): CaseDao
    abstract fun paymentDao(): PaymentDao
    abstract fun promiseDao(): PromiseDao
    abstract fun fieldVisitDao(): FieldVisitDao
    abstract fun paymentPlanDao(): PaymentPlanDao
    abstract fun legalDocDao(): LegalDocDao
    abstract fun timelineDao(): TimelineDao
    abstract fun smsNotificationDao(): SmsNotificationDao
    abstract fun systemConfigDao(): SystemConfigDao
    abstract fun auditLogDao(): AuditLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        // Safe non-destructive migration from version 1 to 2
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Safely create audit_logs table if not exists
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS audit_logs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        action TEXT NOT NULL,
                        actorUserId TEXT NOT NULL,
                        actorRole TEXT NOT NULL,
                        targetEntity TEXT NOT NULL,
                        targetId TEXT NOT NULL,
                        details TEXT NOT NULL,
                        timestamp INTEGER NOT NULL,
                        ipOrDevice TEXT NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_audit_logs_timestamp ON audit_logs(timestamp)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_audit_logs_actorUserId ON audit_logs(actorUserId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_audit_logs_action ON audit_logs(action)")

                // Safely add passwordSalt column to users table if not exists
                try {
                    db.execSQL("ALTER TABLE users ADD COLUMN passwordSalt TEXT NOT NULL DEFAULT ''")
                } catch (e: Exception) {
                    // Column already exists
                }
            }
        }

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                var dbInstance: AppDatabase? = null
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "vml_recover_secure.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration()
                    .addCallback(object : RoomDatabase.Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            scope.launch(Dispatchers.IO) {
                                try {
                                    val target = dbInstance ?: INSTANCE
                                    target?.let { database ->
                                        SampleDataProvider.populateInitialData(database)
                                    }
                                } catch (e: Exception) {
                                    android.util.Log.e("AppDatabase", "onCreate seed failed", e)
                                }
                            }
                        }

                        override fun onOpen(db: SupportSQLiteDatabase) {
                            super.onOpen(db)
                            // Enable SQLite foreign key constraints
                            try {
                                db.execSQL("PRAGMA foreign_keys = ON;")
                            } catch (e: Exception) {
                                android.util.Log.e("AppDatabase", "PRAGMA foreign_keys failed", e)
                            }
                        }
                    })
                    .build()
                dbInstance = instance
                INSTANCE = instance
                scope.launch(Dispatchers.IO) {
                    try {
                        SampleDataProvider.populateInitialData(instance)
                    } catch (e: Exception) {
                        android.util.Log.e("AppDatabase", "launch seed failed", e)
                    }
                }
                instance
            }
        }
    }
}
