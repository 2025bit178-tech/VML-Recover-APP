package com.example.data

import com.example.data.model.AuditLogEntity
import com.example.data.model.CaseEntity
import com.example.data.model.FieldVisitEntity
import com.example.data.model.LegalDocumentEntity
import com.example.data.model.PaymentPlanEntity
import com.example.data.model.PaymentTransactionEntity
import com.example.data.model.PromiseToPayEntity
import com.example.data.model.SystemConfigEntity
import com.example.data.model.TimelineActionEntity
import com.example.data.model.UserEntity
import com.example.data.security.SecurityUtils

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

object SampleDataProvider {

    private val seedMutex = Mutex()

    suspend fun populateInitialData(db: AppDatabase) {
        seedMutex.withLock {
            try {
                val userDao = db.userDao()
                val existingAdmin = userDao.getUserById("USR-001")
                if (existingAdmin != null) {
                    // Database is already seeded! Do not duplicate records or trigger constraint conflicts.
                    return@withLock
                }

            val caseDao = db.caseDao()
            val paymentDao = db.paymentDao()
            val promiseDao = db.promiseDao()
            val visitDao = db.fieldVisitDao()
            val planDao = db.paymentPlanDao()
            val legalDocDao = db.legalDocDao()
            val timelineDao = db.timelineDao()
            val configDao = db.systemConfigDao()
            val auditDao = db.auditLogDao()

        // 1. Initial System Configuration
        val config = SystemConfigEntity(
            configKey = "MAIN_CONFIG",
            systemName = "VML Recover Loan Recovery System",
            isSystemLocked = false,
            lockdownReason = "System operating normally",
            lastModifiedBy = "System Administrator",
            lastModifiedAt = System.currentTimeMillis(),
            smsNotificationsEnabled = true,
            defaultGracePeriodDays = 14,
            statutoryInterestRate = 12.5
        )
        configDao.insertOrUpdate(config)

        // 2. Demo Users with Cryptographically Hashed Passwords
        val demoUsers = listOf(
            createHashedUser(
                userId = "USR-001",
                email = "admin@vmlrecover.ug",
                plainPassword = "admin",
                fullName = "Grace Nakato",
                role = "ADMIN",
                department = "Executive Security",
                phone = "+256 701 445 566",
                organization = "VML Recovery Ltd"
            ),
            createHashedUser(
                userId = "USR-002",
                email = "director@vmlrecover.ug",
                plainPassword = "admin",
                fullName = "Dr. Ronald Mukasa",
                role = "DIRECTOR",
                department = "Board of Directors",
                phone = "+256 772 112 233",
                organization = "VML Recovery Ltd"
            ),
            createHashedUser(
                userId = "USR-003",
                email = "manager@vmlrecover.ug",
                plainPassword = "admin",
                fullName = "Sarah Atuhaire",
                role = "COLLECTION_MANAGER",
                department = "Recoveries Supervision",
                phone = "+256 703 998 877",
                organization = "VML Recovery Ltd"
            ),
            createHashedUser(
                userId = "USR-004",
                email = "collector@vmlrecover.ug",
                plainPassword = "admin",
                fullName = "David Ochieng",
                role = "COLLECTION_OFFICER",
                department = "Field & Call Operations",
                phone = "+256 754 332 211",
                organization = "VML Recovery Ltd"
            ),
            createHashedUser(
                userId = "USR-005",
                email = "legal@vmlrecover.ug",
                plainPassword = "admin",
                fullName = "Counsel Brenda Nabirye",
                role = "LEGAL_OFFICER",
                department = "Legal & Litigation",
                phone = "+256 702 776 655",
                organization = "VML Legal Chambers"
            ),
            createHashedUser(
                userId = "USR-006",
                email = "finance@vmlrecover.ug",
                plainPassword = "admin",
                fullName = "Patrick Kiggundu",
                role = "FINANCE_OFFICER",
                department = "Finance & Reconciliation",
                phone = "+256 776 554 433",
                organization = "VML Recovery Ltd"
            ),
            createHashedUser(
                userId = "USR-007",
                email = "client@stanbic.co.ug",
                plainPassword = "admin",
                fullName = "Stanbic Bank Recoveries Portfolio",
                role = "CLIENT",
                department = "Credit Portfolio Oversight",
                phone = "+256 312 224 000",
                organization = "Stanbic Bank Uganda"
            )
        )

        for (user in demoUsers) {
            try {
                val existing = userDao.getUserById(user.userId)
                if (existing == null) {
                    userDao.insertUser(user)
                }
            } catch (e: Exception) {
                // Ignore or handle
            }
        }

        // 3. Demo Cases
        val demoCases = listOf(
            CaseEntity(
                caseId = "VML-2025-001",
                debtorName = "Kasule John Baptist",
                debtorNationalId = "CM89021102KLAX",
                debtorPhone = "+256 701 889 900",
                debtorEmail = "john.kasule@gmail.com",
                debtorAddress = "Plot 44, Jinja Road, Nakawa Industrial Area",
                debtorEmployer = "Kasule Hardware Supplies Ltd",
                debtorEmergencyContact = "+256 772 334 455 (Brother)",
                creditorName = "Stanbic Bank Uganda",
                creditorAccountNumber = "9030018274910",
                principalAmount = 14500000.0,
                interestAmount = 1750000.0,
                penaltiesAmount = 500000.0,
                amountPaid = 4500000.0,
                dateDebtArose = "15 Jan 2024",
                dueDate = "15 Nov 2024",
                status = "ACTIVE",
                legalStage = "DEMAND_LETTER",
                riskLevel = "HIGH",
                ageingCategory = "180_PLUS",
                assignedOfficerId = "USR-004",
                assignedOfficerName = "David Ochieng",
                debtorType = "INDIVIDUAL",
                sectorOfWork = "Trade & Retail",
                originalAgreementRef = "SME-TERM-LN-2023-8891",
                supportingDocsNote = "Verified Loan Agreement, Personal Guarantee & Land Title Lien"
            ),
            CaseEntity(
                caseId = "VML-2025-002",
                debtorName = "Nalubega Harriet",
                debtorNationalId = "CF91045512BGAX",
                debtorPhone = "+256 774 123 456",
                debtorEmail = "harriet.nalubega@yahoo.com",
                debtorAddress = "Kabalagala Plaza, Ggaba Road, Kampala",
                debtorEmployer = "Pearl Beauty Parlour",
                debtorEmergencyContact = "+256 700 998 877 (Spouse)",
                creditorName = "Stanbic Bank Uganda",
                creditorAccountNumber = "9030029384711",
                principalAmount = 6800000.0,
                interestAmount = 820000.0,
                penaltiesAmount = 200000.0,
                amountPaid = 2000000.0,
                dateDebtArose = "02 Mar 2024",
                dueDate = "02 Dec 2024",
                status = "PENDING_PTP",
                legalStage = "PRE_LEGAL",
                riskLevel = "MEDIUM",
                ageingCategory = "90_DAYS",
                assignedOfficerId = "USR-004",
                assignedOfficerName = "David Ochieng",
                debtorType = "INDIVIDUAL",
                sectorOfWork = "Services",
                originalAgreementRef = "MICRO-BIZ-LN-2024-1123",
                supportingDocsNote = "Chattels mortgage registered over salon equipment"
            ),
            CaseEntity(
                caseId = "VML-2025-003",
                debtorName = "Apex Logistics East Africa Ltd",
                debtorNationalId = "CO-REG-882910-UG",
                debtorPhone = "+256 752 445 566",
                debtorEmail = "finance@apexlogistics.co.ug",
                debtorAddress = "Ntinda Complex, Block B, Kampala",
                debtorEmployer = "Apex Logistics Holding",
                debtorEmergencyContact = "+256 772 889 911 (Managing Director)",
                creditorName = "Centenary Bank",
                creditorAccountNumber = "3100293847192",
                principalAmount = 28000000.0,
                interestAmount = 3500000.0,
                penaltiesAmount = 1200000.0,
                amountPaid = 8000000.0,
                dateDebtArose = "10 Oct 2023",
                dueDate = "10 Aug 2024",
                status = "LEGAL_ESCALATION",
                legalStage = "SUMMONS_ISSUED",
                riskLevel = "CRITICAL",
                ageingCategory = "180_PLUS",
                assignedOfficerId = "USR-004",
                assignedOfficerName = "David Ochieng",
                debtorType = "COMPANY",
                sectorOfWork = "Logistics & Transport",
                originalAgreementRef = "COMM-FLEET-FIN-2023-7412",
                supportingDocsNote = "Logbooks for 2 Isuzu Tipper Trucks attached"
            ),
            CaseEntity(
                caseId = "VML-2025-004",
                debtorName = "Victoria Agro Processors Ltd",
                debtorNationalId = "CO-REG-947210-UG",
                debtorPhone = "+256 703 112 233",
                debtorEmail = "accounts@victoriaagro.ug",
                debtorAddress = "Plot 12, Jinja Industrial Estate",
                debtorEmployer = "Victoria Agro Corp",
                debtorEmergencyContact = "+256 772 556 677 (Operations Head)",
                creditorName = "DFCU Bank",
                creditorAccountNumber = "0182749100293",
                principalAmount = 45000000.0,
                interestAmount = 5200000.0,
                penaltiesAmount = 1800000.0,
                amountPaid = 12000000.0,
                dateDebtArose = "05 Feb 2024",
                dueDate = "05 Sep 2024",
                status = "ACTIVE",
                legalStage = "COURT_HEARING",
                riskLevel = "HIGH",
                ageingCategory = "180_PLUS",
                assignedOfficerId = "USR-004",
                assignedOfficerName = "David Ochieng",
                debtorType = "COMPANY",
                sectorOfWork = "Agriculture",
                originalAgreementRef = "AGRI-CROP-LN-2024-5541",
                supportingDocsNote = "Grain silos and commercial charge over plant assets"
            ),
            CaseEntity(
                caseId = "VML-2025-005",
                debtorName = "Kavuma Ronald",
                debtorNationalId = "CM87042211EBAX",
                debtorPhone = "+256 782 990 011",
                debtorEmail = "ronald.kavuma@gmail.com",
                debtorAddress = "Entebbe Road, Namasuba Stage",
                debtorEmployer = "Kavuma Real Estate Agency",
                debtorEmergencyContact = "+256 701 223 344 (Sister)",
                creditorName = "Absa Bank Uganda",
                creditorAccountNumber = "6002918475819",
                principalAmount = 18500000.0,
                interestAmount = 2100000.0,
                penaltiesAmount = 750000.0,
                amountPaid = 3500000.0,
                dateDebtArose = "12 Jun 2024",
                dueDate = "12 Dec 2024",
                status = "PENDING_PTP",
                legalStage = "PRE_LEGAL",
                riskLevel = "MEDIUM",
                ageingCategory = "60_DAYS",
                assignedOfficerId = "USR-004",
                assignedOfficerName = "David Ochieng",
                debtorType = "INDIVIDUAL",
                sectorOfWork = "Real Estate",
                originalAgreementRef = "MORTGAGE-TOPUP-2024-912",
                supportingDocsNote = "Equitable mortgage over residential plot in Namasuba"
            ),
            CaseEntity(
                caseId = "VML-2025-006",
                debtorName = "Makerere Tech Hardware Enterprises",
                debtorNationalId = "CO-REG-109283-UG",
                debtorPhone = "+256 754 887 766",
                debtorEmail = "sales@makereretech.co.ug",
                debtorAddress = "Sir Apollo Kaggwa Road, Makerere",
                debtorEmployer = "Makerere Hardware Group",
                debtorEmergencyContact = "+256 774 332 211 (Founder)",
                creditorName = "Stanbic Bank Uganda",
                creditorAccountNumber = "9030048192834",
                principalAmount = 32000000.0,
                interestAmount = 3800000.0,
                penaltiesAmount = 1500000.0,
                amountPaid = 9500000.0,
                dateDebtArose = "20 Nov 2023",
                dueDate = "20 May 2024",
                status = "LEGAL_ESCALATION",
                legalStage = "JUDGMENT_ENFORCEMENT",
                riskLevel = "CRITICAL",
                ageingCategory = "180_PLUS",
                assignedOfficerId = "USR-004",
                assignedOfficerName = "David Ochieng",
                debtorType = "COMPANY",
                sectorOfWork = "Manufacturing",
                originalAgreementRef = "COMM-INVENTORY-2023-412",
                supportingDocsNote = "Warrant of attachment issued by High Court Commercial Division"
            )
        )

        for (c in demoCases) {
            caseDao.insertCase(c)
        }

        // 4. Initial Payments
        val payments = listOf(
            PaymentTransactionEntity(
                caseId = "VML-2025-001",
                amount = 2500000.0,
                receiptNumber = "VML-REC-2025-0912",
                paymentChannel = "MTN Mobile Money",
                recordedBy = "Patrick Kiggundu (Finance)",
                notes = "First lump sum direct payment towards principal",
                verified = true
            ),
            PaymentTransactionEntity(
                caseId = "VML-2025-001",
                amount = 2000000.0,
                receiptNumber = "VML-REC-2025-0913",
                paymentChannel = "Airtel Money",
                recordedBy = "Patrick Kiggundu (Finance)",
                notes = "Second direct instalment authorized via portal",
                verified = true
            ),
            PaymentTransactionEntity(
                caseId = "VML-2025-002",
                amount = 2000000.0,
                receiptNumber = "VML-REC-2025-0914",
                paymentChannel = "Direct Debit",
                recordedBy = "Patrick Kiggundu (Finance)",
                notes = "Direct collection confirmation",
                verified = true
            )
        )

        for (p in payments) {
            try {
                paymentDao.insertPayment(p)
            } catch (e: Exception) {
                // Ignore conflict
            }
        }

        // 5. Payment Plans
        val plan = PaymentPlanEntity(
            caseId = "VML-2025-001",
            debtorName = "Kasule John Baptist",
            totalAgreedAmount = 12250000.0,
            numberOfInstalments = 4,
            frequency = "MONTHLY",
            startDate = "25 Oct 2025",
            status = "ACTIVE",
            instalmentsJson = """[{"num":1,"amount":3062500,"dueDate":"25 Oct 2025","status":"PAID"},{"num":2,"amount":3062500,"dueDate":"25 Nov 2025","status":"DUE TODAY"},{"num":3,"amount":3062500,"dueDate":"25 Dec 2025","status":"UPCOMING"},{"num":4,"amount":3062500,"dueDate":"25 Jan 2026","status":"UPCOMING"}]"""
        )
        try {
            planDao.insertPlan(plan)
        } catch (e: Exception) {
            // Ignore conflict
        }

        // 6. Promises to Pay
        val promise = PromiseToPayEntity(
            caseId = "VML-2025-001",
            debtorName = "Kasule John Baptist",
            promisedAmount = 3062500.0,
            promiseDate = "25 Nov 2025",
            paymentMethod = "MTN Mobile Money",
            status = "PENDING",
            receivedAmount = 0.0,
            notes = "Debtor confirmed direct transfer upon invoice clearance",
            officerName = "David Ochieng"
        )
        try {
            promiseDao.insertPromise(promise)
        } catch (e: Exception) {
            // Ignore conflict
        }

        // 7. Field Visits
        val visit = FieldVisitEntity(
            caseId = "VML-2025-001",
            debtorName = "Kasule John Baptist",
            scheduledDate = "18 Oct 2025",
            address = "Plot 44, Jinja Road, Nakawa Industrial Area",
            officerName = "David Ochieng",
            status = "COMPLETED",
            outcome = "Debtor present at workshop, agreed to 4-month repayment plan",
            nextAction = "Follow up on second instalment",
            complianceVerified = true,
            checkedInAt = System.currentTimeMillis() - 86400000L * 5
        )
        try {
            visitDao.insertVisit(visit)
        } catch (e: Exception) {
            // Ignore conflict
        }

        // 8. Legal Documents
        val legalDoc = LegalDocumentEntity(
            caseId = "VML-2025-001",
            docType = "DEMAND_NOTICE",
            title = "Formal 7-Day Final Statutory Demand Letter",
            contentSummary = "Demand for UGX 12,250,000 outstanding before High Court Commercial Division filing",
            generatedDate = "12 Oct 2025",
            courtReference = "HCT-00-CC-CS-2025/119",
            courtDate = "15 Nov 2025",
            assignedAdvocate = "Counsel Brenda Nabirye",
            status = "SERVED"
        )
        try {
            legalDocDao.insertDocument(legalDoc)
        } catch (e: Exception) {
            // Ignore conflict
        }

        // 9. Timeline Actions
        val actions = listOf(
            TimelineActionEntity(
                caseId = "VML-2025-001",
                actionType = "CALL",
                title = "Phone Consultation with Debtor",
                description = "Negotiated repayment terms. Debtor committed to regular monthly instalments.",
                officerName = "David Ochieng",
                timestamp = System.currentTimeMillis() - 86400000L * 7,
                tag = "TELE-COLLECTION"
            ),
            TimelineActionEntity(
                caseId = "VML-2025-001",
                actionType = "PAYMENT",
                title = "Direct Payment Received UGX 2,500,000",
                description = "Processed via MTN Mobile Money. Receipt VML-REC-2025-0912 verified.",
                officerName = "Patrick Kiggundu (Finance)",
                timestamp = System.currentTimeMillis() - 86400000L * 4,
                tag = "DIRECT_PAYMENT",
                amount = 2500000.0
            )
        )
        for (a in actions) {
            try {
                timelineDao.insertAction(a)
            } catch (e: Exception) {
                // Ignore conflict
            }
        }

        // 10. Audit Logging
        val initialAuditLogs = listOf(
            AuditLogEntity(
                action = "SYSTEM_INITIALIZATION",
                actorUserId = "SYSTEM",
                actorRole = "SYSTEM",
                targetEntity = "DATABASE",
                targetId = "ALL",
                details = "Initialized secure enterprise database with hashed credentials, safe relations, and audit controls.",
                timestamp = System.currentTimeMillis() - 86400000L * 3,
                ipOrDevice = "Local Device KeyStore"
            ),
            AuditLogEntity(
                action = "LOGIN_SUCCESS",
                actorUserId = "USR-001",
                actorRole = "ADMIN",
                targetEntity = "Session",
                targetId = "USR-001",
                details = "Admin Arthur Kato logged in via biometric/passkey verification.",
                timestamp = System.currentTimeMillis() - 86400000L * 2 - 3600000L * 4,
                ipOrDevice = "Executive Terminal #1"
            ),
            AuditLogEntity(
                action = "LOGOUT",
                actorUserId = "USR-001",
                actorRole = "ADMIN",
                targetEntity = "Session",
                targetId = "USR-001",
                details = "User Arthur Kato logged out / locked terminal.",
                timestamp = System.currentTimeMillis() - 86400000L * 2 - 3600000L * 1,
                ipOrDevice = "Executive Terminal #1"
            ),
            AuditLogEntity(
                action = "LOGIN_SUCCESS",
                actorUserId = "USR-002",
                actorRole = "DIRECTOR",
                targetEntity = "Session",
                targetId = "USR-002",
                details = "User Dr. Ronald Mukasa (Director) logged in to review monthly KPI audit reports.",
                timestamp = System.currentTimeMillis() - 86400000L * 2,
                ipOrDevice = "Android Tablet 10.1"
            ),
            AuditLogEntity(
                action = "REPORT_EXPORT",
                actorUserId = "USR-002",
                actorRole = "DIRECTOR",
                targetEntity = "PortfolioReport",
                targetId = "RECOVERY_SUMMARY",
                details = "Director exported executive debt recovery performance audit PDF.",
                timestamp = System.currentTimeMillis() - 86400000L * 2 + 1800000L,
                ipOrDevice = "Android Tablet 10.1"
            ),
            AuditLogEntity(
                action = "LOGOUT",
                actorUserId = "USR-002",
                actorRole = "DIRECTOR",
                targetEntity = "Session",
                targetId = "USR-002",
                details = "User Dr. Ronald Mukasa logged out safely.",
                timestamp = System.currentTimeMillis() - 86400000L * 2 + 3600000L,
                ipOrDevice = "Android Tablet 10.1"
            ),
            AuditLogEntity(
                action = "LOGIN_SUCCESS",
                actorUserId = "USR-003",
                actorRole = "COLLECTION_MANAGER",
                targetEntity = "Session",
                targetId = "USR-003",
                details = "Sarah Atuhaire logged in for portfolio allocation.",
                timestamp = System.currentTimeMillis() - 86400000L,
                ipOrDevice = "Supervisor Mobile App"
            ),
            AuditLogEntity(
                action = "CASE_ALLOCATION",
                actorUserId = "USR-003",
                actorRole = "COLLECTION_MANAGER",
                targetEntity = "Case",
                targetId = "VML-2025-001",
                details = "Allocated high-value case VML-2025-001 to field officer David Ochieng.",
                timestamp = System.currentTimeMillis() - 86400000L + 1200000L,
                ipOrDevice = "Supervisor Mobile App"
            ),
            AuditLogEntity(
                action = "LOGOUT",
                actorUserId = "USR-003",
                actorRole = "COLLECTION_MANAGER",
                targetEntity = "Session",
                targetId = "USR-003",
                details = "User Sarah Atuhaire logged out.",
                timestamp = System.currentTimeMillis() - 86400000L + 14400000L,
                ipOrDevice = "Supervisor Mobile App"
            ),
            AuditLogEntity(
                action = "LOGIN_SUCCESS",
                actorUserId = "USR-004",
                actorRole = "COLLECTION_OFFICER",
                targetEntity = "Session",
                targetId = "USR-004",
                details = "Field Officer David Ochieng authenticated at GPS coordinates 0.3162, 32.5825.",
                timestamp = System.currentTimeMillis() - 43200000L,
                ipOrDevice = "Field Handheld SM-G998B"
            ),
            AuditLogEntity(
                action = "CALL_LOG",
                actorUserId = "USR-004",
                actorRole = "COLLECTION_OFFICER",
                targetEntity = "Case",
                targetId = "VML-2025-001",
                details = "Logged telephone contact with debtor John Baptist Ssenyonga regarding overdue repayment.",
                timestamp = System.currentTimeMillis() - 40000000L,
                ipOrDevice = "Field Handheld SM-G998B"
            ),
            AuditLogEntity(
                action = "LOGOUT",
                actorUserId = "USR-004",
                actorRole = "COLLECTION_OFFICER",
                targetEntity = "Session",
                targetId = "USR-004",
                details = "Officer David Ochieng ended shift and logged out.",
                timestamp = System.currentTimeMillis() - 28000000L,
                ipOrDevice = "Field Handheld SM-G998B"
            ),
            AuditLogEntity(
                action = "LOGIN_SUCCESS",
                actorUserId = "USR-005",
                actorRole = "LEGAL_OFFICER",
                targetEntity = "Session",
                targetId = "USR-005",
                details = "Counsel Brenda Nabirye logged in to draft demand letters.",
                timestamp = System.currentTimeMillis() - 25000000L,
                ipOrDevice = "Legal Workstation"
            ),
            AuditLogEntity(
                action = "LEGAL_FILING",
                actorUserId = "USR-005",
                actorRole = "LEGAL_OFFICER",
                targetEntity = "Case",
                targetId = "VML-2025-005",
                details = "Generated High Court formal demand notice for Mugerwa Logistics.",
                timestamp = System.currentTimeMillis() - 20000000L,
                ipOrDevice = "Legal Workstation"
            ),
            AuditLogEntity(
                action = "LOGOUT",
                actorUserId = "USR-005",
                actorRole = "LEGAL_OFFICER",
                targetEntity = "Session",
                targetId = "USR-005",
                details = "Counsel Brenda Nabirye signed out.",
                timestamp = System.currentTimeMillis() - 15000000L,
                ipOrDevice = "Legal Workstation"
            ),
            AuditLogEntity(
                action = "LOGIN_SUCCESS",
                actorUserId = "USR-006",
                actorRole = "FINANCE_OFFICER",
                targetEntity = "Session",
                targetId = "USR-006",
                details = "Patrick Kiggundu authenticated for banking reconciliation batch.",
                timestamp = System.currentTimeMillis() - 14000000L,
                ipOrDevice = "Finance Desktop"
            ),
            AuditLogEntity(
                action = "PAYMENT_RECEIPTED",
                actorUserId = "USR-006",
                actorRole = "FINANCE_OFFICER",
                targetEntity = "Payment",
                targetId = "REC-UG-2025-091",
                details = "Receipted UGX 3,500,000 via Stanbic Bank Direct Deposit for case VML-2025-001.",
                timestamp = System.currentTimeMillis() - 10000000L,
                ipOrDevice = "Finance Desktop"
            ),
            AuditLogEntity(
                action = "LOGOUT",
                actorUserId = "USR-006",
                actorRole = "FINANCE_OFFICER",
                targetEntity = "Session",
                targetId = "USR-006",
                details = "Patrick Kiggundu completed reconciliation shift and logged out.",
                timestamp = System.currentTimeMillis() - 7200000L,
                ipOrDevice = "Finance Desktop"
            )
        )
        for (log in initialAuditLogs) {
            try {
                auditDao.insertLog(log)
            } catch (e: Exception) {
                // Ignore duplicate log
            }
        }
        } catch (e: Throwable) {
            android.util.Log.e("SampleDataProvider", "Failed to populate initial data", e)
        }
    }
}

    private fun createHashedUser(
        userId: String,
        email: String,
        plainPassword: String,
        fullName: String,
        role: String,
        department: String,
        phone: String,
        organization: String
    ): UserEntity {
        val salt = SecurityUtils.generateSalt()
        val hash = SecurityUtils.hashPassword(plainPassword, salt)
        val maskedUser = SecurityUtils.maskEmail(email)
        val maskedPass = "●●●●●●●●"

        return UserEntity(
            userId = userId,
            email = email,
            password = hash,
            fullName = fullName,
            role = role,
            department = department,
            phoneNumber = phone,
            organization = organization,
            lastLoginAt = 0L,
            maskedUsername = maskedUser,
            maskedPassword = maskedPass,
            isLocked = false,
            failedAttempts = 0,
            passwordSalt = salt
        )
    }
}
