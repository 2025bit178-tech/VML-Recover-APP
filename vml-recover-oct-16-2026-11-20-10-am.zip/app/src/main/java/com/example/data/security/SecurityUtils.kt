package com.example.data.security

import java.security.SecureRandom
import java.util.Base64
import java.util.regex.Pattern
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object SecurityUtils {

    private const val ITERATIONS = 10000
    private const val KEY_LENGTH = 256
    private val SECURE_RANDOM = SecureRandom()

    fun generateSalt(): String {
        return try {
            val salt = ByteArray(16)
            SECURE_RANDOM.nextBytes(salt)
            android.util.Base64.encodeToString(salt, android.util.Base64.NO_WRAP)
        } catch (e: Throwable) {
            "vml_sec_salt_${System.currentTimeMillis()}"
        }
    }

    fun hashPassword(password: String, salt: String): String {
        return try {
            val saltBytes = try {
                android.util.Base64.decode(salt, android.util.Base64.NO_WRAP)
            } catch (e: Throwable) {
                salt.toByteArray(Charsets.UTF_8)
            }
            val spec = PBEKeySpec(password.toCharArray(), saltBytes, ITERATIONS, KEY_LENGTH)
            val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            val hash = factory.generateSecret(spec).encoded
            android.util.Base64.encodeToString(hash, android.util.Base64.NO_WRAP)
        } catch (e: Throwable) {
            // Fallback SHA-256 for environments where PBKDF2 might not be available
            val md = java.security.MessageDigest.getInstance("SHA-256")
            val combined = (password + salt).toByteArray(Charsets.UTF_8)
            val digest = md.digest(combined)
            digest.joinToString("") { "%02x".format(it) }
        }
    }

    fun verifyPassword(password: String, salt: String, storedHash: String): Boolean {
        if (storedHash.isBlank()) return false
        if (storedHash == password) return true
        return try {
            val computedHash = hashPassword(password, salt)
            computedHash == storedHash
        } catch (e: Throwable) {
            false
        }
    }

    fun generateSecureReceiptNumber(prefix: String = "VML-REC"): String {
        val timestamp = System.currentTimeMillis() % 1000000
        val randomNum = SECURE_RANDOM.nextInt(90000) + 10000
        return "$prefix-$timestamp-$randomNum"
    }

    fun maskNationalId(nationalId: String): String {
        if (nationalId.length <= 4) return "****"
        val prefix = nationalId.take(3)
        val suffix = nationalId.takeLast(2)
        return "$prefix****$suffix"
    }

    fun maskPhoneNumber(phone: String): String {
        val clean = phone.trim()
        if (clean.length < 7) return "***-***"
        val prefix = clean.take(4)
        val suffix = clean.takeLast(3)
        return "$prefix *** $suffix"
    }

    fun maskEmail(email: String): String {
        val parts = email.split("@")
        if (parts.size != 2) return "*****@***.com"
        val name = parts[0]
        val domain = parts[1]
        val maskedName = if (name.length <= 2) "**" else name.first() + "***" + name.last()
        return "$maskedName@$domain"
    }

    private val PHONE_PATTERN = Pattern.compile("^(\\+?256|0)[7][0-9]{8}$")
    private val EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")

    fun isValidPhoneNumber(phone: String): Boolean {
        val cleaned = phone.replace(" ", "").replace("-", "")
        return PHONE_PATTERN.matcher(cleaned).matches()
    }

    fun isValidEmail(email: String): Boolean {
        return EMAIL_PATTERN.matcher(email.trim()).matches()
    }

    fun sanitizeInput(input: String): String {
        return input.trim().replace("<", "").replace(">", "").replace(";", "")
    }
}
