package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class PlatformMode(val label: String, val shortLabel: String) {
    ANDROID("Android (Material 3)", "Android"),
    IOS("iOS (Cupertino Adaptive)", "iOS"),
    AUTO("Adaptive (Universal)", "Universal")
}

@Entity(
    tableName = "users",
    indices = [Index(value = ["email"], unique = true)]
)
data class UserEntity(
    @PrimaryKey
    val userId: String,
    val email: String,
    val password: String, // Stores cryptographic hash (PBKDF2)
    val fullName: String,
    val role: String,
    val department: String = "Recoveries",
    val phoneNumber: String = "+256 700 000 000",
    val organization: String = "VML Recovery Ltd",
    val lastLoginAt: Long = 0L,
    val maskedUsername: String = "",
    val maskedPassword: String = "",
    val isLocked: Boolean = false,
    val failedAttempts: Int = 0,
    val lockReason: String? = null,
    val lockedAt: Long? = null,
    val passwordSalt: String = ""
)

@Entity(
    tableName = "cases",
    indices = [
        Index(value = ["caseId"], unique = true),
        Index(value = ["assignedOfficerId"]),
        Index(value = ["creditorName"]),
        Index(value = ["status"])
    ]
)
data class CaseEntity(
    @PrimaryKey
    val caseId: String,
    val debtorName: String,
    val debtorNationalId: String,
    val debtorPhone: String,
    val debtorEmail: String = "",
    val debtorAddress: String = "",
    val debtorEmployer: String = "",
    val debtorEmergencyContact: String = "",
    val creditorName: String,
    val creditorAccountNumber: String = "",
    val principalAmount: Double,
    val interestAmount: Double = 0.0,
    val penaltiesAmount: Double = 0.0,
    val amountPaid: Double = 0.0,
    val dateDebtArose: String = "",
    val dueDate: String = "",
    val status: String = "ACTIVE", // ACTIVE, PENDING_PTP, LEGAL_ESCALATION, FULLY_RECOVERED, WRITTEN_OFF
    val legalStage: String = "PRE_LEGAL", // PRE_LEGAL, DEMAND_LETTER, SUMMONS_ISSUED, COURT_HEARING, JUDGMENT_ENFORCEMENT
    val riskLevel: String = "MEDIUM", // LOW, MEDIUM, HIGH, CRITICAL
    val ageingCategory: String = "90_DAYS", // 30_DAYS, 60_DAYS, 90_DAYS, 180_PLUS
    val assignedOfficerId: String = "",
    val assignedOfficerName: String = "",
    val debtorType: String = "INDIVIDUAL", // INDIVIDUAL or COMPANY
    val sectorOfWork: String = "Trade & Retail", // Trade & Retail, Logistics, Manufacturing, Agriculture, Services, Construction
    val originalAgreementRef: String = "",
    val supportingDocsNote: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    val totalDebt: Double
        get() = principalAmount + interestAmount + penaltiesAmount

    val totalOutstanding: Double
        get() = (principalAmount + interestAmount + penaltiesAmount - amountPaid).coerceAtLeast(0.0)

    val outstandingBalance: Double
        get() = totalOutstanding

    val recoveryPercentage: Double
        get() = if (totalDebt > 0.0) ((amountPaid / totalDebt) * 100.0).coerceIn(0.0, 100.0) else 0.0

    val isPaidInFull: Boolean
        get() = totalOutstanding <= 0.0
}

@Entity(
    tableName = "payment_transactions",
    foreignKeys = [
        ForeignKey(
            entity = CaseEntity::class,
            parentColumns = ["caseId"],
            childColumns = ["caseId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [
        Index(value = ["caseId"]),
        Index(value = ["receiptNumber"], unique = true)
    ]
)
data class PaymentTransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val caseId: String,
    val amount: Double,
    val paymentDate: Long = System.currentTimeMillis(),
    val receiptNumber: String,
    val receiptNo: String = receiptNumber,
    val paymentChannel: String, // MTN Mobile Money, Airtel Money, Bank Wire, Direct Debit, Cash
    val recordedBy: String,
    val notes: String = "",
    val verified: Boolean = true
)

@Entity(
    tableName = "promises_to_pay",
    foreignKeys = [
        ForeignKey(
            entity = CaseEntity::class,
            parentColumns = ["caseId"],
            childColumns = ["caseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["caseId"])]
)
data class PromiseToPayEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val caseId: String,
    val debtorName: String,
    val promisedAmount: Double,
    val promiseDate: String,
    val paymentMethod: String = "Mobile Money",
    val officerName: String = "Officer David Ochieng",
    val notes: String = "",
    val status: String = "PENDING", // PENDING, FULFILLED, DEFAULTED
    val receivedAmount: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "field_visits",
    foreignKeys = [
        ForeignKey(
            entity = CaseEntity::class,
            parentColumns = ["caseId"],
            childColumns = ["caseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["caseId"])]
)
data class FieldVisitEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val caseId: String,
    val debtorName: String,
    val address: String,
    val scheduledDate: String = "",
    val scheduledTime: String = scheduledDate,
    val officerName: String = "Field Officer Patrick Okello",
    val outcome: String = "Visit scheduled to verify ongoing trading operations.",
    val nextAction: String = "Follow-up telephone call in 48 hours.",
    val status: String = "SCHEDULED", // SCHEDULED, COMPLETED, CANCELLED
    val checkedInAt: Long? = null,
    val complianceVerified: Boolean = true,
    val fairCollectionChecklistConfirmed: Boolean = complianceVerified
)

@Entity(
    tableName = "payment_plans",
    foreignKeys = [
        ForeignKey(
            entity = CaseEntity::class,
            parentColumns = ["caseId"],
            childColumns = ["caseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["caseId"])]
)
data class PaymentPlanEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val caseId: String,
    val debtorName: String,
    val totalAgreedAmount: Double,
    val numberOfInstalments: Int,
    val frequency: String = "MONTHLY", // WEEKLY, BI_WEEKLY, MONTHLY
    val instalmentAmount: Double = if (numberOfInstalments > 0) totalAgreedAmount / numberOfInstalments else totalAgreedAmount,
    val startDate: String,
    val status: String = "ACTIVE", // ACTIVE, COMPLETED, DEFAULTED
    val instalmentsJson: String = "",
    val scheduleBreakdownJson: String = instalmentsJson
)

@Entity(
    tableName = "legal_documents",
    foreignKeys = [
        ForeignKey(
            entity = CaseEntity::class,
            parentColumns = ["caseId"],
            childColumns = ["caseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["caseId"])]
)
data class LegalDocumentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val caseId: String,
    val docType: String, // DEMAND_LETTER, SUMMONS, PLAINT, ATTACHMENT_WARRANT, COURT_ORDER
    val title: String,
    val contentSummary: String,
    val generatedDate: String,
    val courtReference: String = "",
    val courtDate: String = "",
    val assignedAdvocate: String = "",
    val status: String = "DRAFT" // DRAFT, SERVED, FILED, DECREE_ENTERED
)

@Entity(
    tableName = "timeline_actions",
    foreignKeys = [
        ForeignKey(
            entity = CaseEntity::class,
            parentColumns = ["caseId"],
            childColumns = ["caseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["caseId"])]
)
data class TimelineActionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val caseId: String,
    val actionType: String, // CALL, VISIT, PAYMENT, PTP_RECORDED, LEGAL_NOTICE, SMS_ALERT
    val title: String,
    val description: String,
    val officerName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val tag: String = "GENERAL",
    val amount: Double? = null
)

@Entity(tableName = "sms_notifications")
data class SmsNotificationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val recipientPhone: String,
    val recipientName: String,
    val eventType: String, // LOGIN, NEW_DEBT, PAYMENT_CONFIRMATION, REMINDER, SECURITY_LOCKOUT
    val messageContent: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "DELIVERED",
    val referenceId: String? = null
)

@Entity(tableName = "system_config")
data class SystemConfigEntity(
    @PrimaryKey
    val configKey: String = "MAIN_CONFIG",
    val systemName: String = "VML Recover Enterprise System",
    val isSystemLocked: Boolean = false,
    val lockdownReason: String = "Maintenance lockdown active",
    val lastModifiedBy: String = "System Admin",
    val lastModifiedAt: Long = System.currentTimeMillis(),
    val smsNotificationsEnabled: Boolean = true,
    val defaultGracePeriodDays: Int = 14,
    val statutoryInterestRate: Double = 12.5
)

@Entity(
    tableName = "audit_logs",
    indices = [
        Index(value = ["timestamp"]),
        Index(value = ["actorUserId"]),
        Index(value = ["action"])
    ]
)
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val action: String, // LOGIN_SUCCESS, LOGIN_FAILED, ACCOUNT_LOCKED, ACCOUNT_UNLOCKED, PAYMENT_RECORDED, PAYMENT_REVERSED, LOCKDOWN_TOGGLED, CASE_REASSIGNED
    val actorUserId: String,
    val actorRole: String,
    val targetEntity: String, // User, Case, Payment, System
    val targetId: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis(),
    val ipOrDevice: String = "Android Device"
)
