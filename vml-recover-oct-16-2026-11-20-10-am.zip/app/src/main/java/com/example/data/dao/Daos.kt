package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.model.AuditLogEntity
import com.example.data.model.CaseEntity
import com.example.data.model.FieldVisitEntity
import com.example.data.model.LegalDocumentEntity
import com.example.data.model.PaymentPlanEntity
import com.example.data.model.PaymentTransactionEntity
import com.example.data.model.PromiseToPayEntity
import com.example.data.model.SmsNotificationEntity
import com.example.data.model.SystemConfigEntity
import com.example.data.model.TimelineActionEntity
import com.example.data.model.UserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users")
    fun getAllUsersFlow(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE isLocked = 1")
    fun getLockedUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE userId = :userId LIMIT 1")
    suspend fun getUserById(userId: String): UserEntity?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE LOWER(email) = LOWER(:identifier) OR LOWER(userId) = LOWER(:identifier) LIMIT 1")
    suspend fun findByIdentifier(identifier: String): UserEntity?

    @Query("SELECT * FROM users WHERE (LOWER(email) = LOWER(:identifier) OR LOWER(userId) = LOWER(:identifier)) AND password = :password LIMIT 1")
    suspend fun authenticate(identifier: String, password: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Delete
    suspend fun deleteUser(user: UserEntity)

    @Query("DELETE FROM users WHERE userId = :userId")
    suspend fun deleteUser(userId: String)

    @Query("UPDATE users SET failedAttempts = :attempts WHERE userId = :userId")
    suspend fun updateFailedAttempts(userId: String, attempts: Int)

    @Query("UPDATE users SET isLocked = :locked, lockReason = :reason, lockedAt = :timestamp WHERE userId = :userId")
    suspend fun setAccountLockStatus(userId: String, locked: Boolean, reason: String?, timestamp: Long?)

    @Query("UPDATE users SET isLocked = 1, lockReason = :reason, lockedAt = :timestamp WHERE userId = :userId")
    suspend fun lockUser(userId: String, reason: String, timestamp: Long)

    @Query("UPDATE users SET isLocked = 0, failedAttempts = 0, lockReason = NULL, lockedAt = NULL WHERE userId = :userId")
    suspend fun unlockUser(userId: String)

    @Query("UPDATE users SET isLocked = 0, failedAttempts = 0, lockReason = NULL, lockedAt = NULL")
    suspend fun unlockAllUsers()

    @Query("UPDATE users SET lastLoginAt = :timestamp, failedAttempts = 0 WHERE userId = :userId")
    suspend fun recordSuccessfulLogin(userId: String, timestamp: Long)

    @Query("UPDATE users SET lastLoginAt = :timestamp, failedAttempts = 0 WHERE userId = :userId")
    suspend fun updateLastLogin(userId: String, timestamp: Long)

    @Query("UPDATE users SET password = :newPass WHERE userId = :userId")
    suspend fun updatePassword(userId: String, newPass: String)
}

@Dao
interface CaseDao {
    @Query("SELECT * FROM cases ORDER BY createdAt DESC")
    fun getAllCasesFlow(): Flow<List<CaseEntity>>

    @Query("SELECT * FROM cases ORDER BY createdAt DESC")
    fun getAllCases(): Flow<List<CaseEntity>>

    @Query("SELECT * FROM cases WHERE caseId = :caseId LIMIT 1")
    suspend fun getCaseById(caseId: String): CaseEntity?

    @Query("SELECT * FROM cases WHERE caseId = :caseId LIMIT 1")
    suspend fun getCaseDirect(caseId: String): CaseEntity?

    @Query("SELECT * FROM cases WHERE caseId = :caseId LIMIT 1")
    fun getCaseByIdFlow(caseId: String): Flow<CaseEntity?>

    @Query("SELECT * FROM cases WHERE assignedOfficerId = :officerId")
    fun getCasesForOfficerFlow(officerId: String): Flow<List<CaseEntity>>

    @Query("SELECT * FROM cases WHERE creditorName = :creditorName")
    fun getCasesForCreditorFlow(creditorName: String): Flow<List<CaseEntity>>

    @Query("SELECT * FROM cases WHERE debtorEmail = :debtorEmail OR debtorPhone = :debtorPhone")
    fun getCasesForDebtorFlow(debtorEmail: String, debtorPhone: String): Flow<List<CaseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCase(caseItem: CaseEntity)

    @Update
    suspend fun updateCase(caseItem: CaseEntity)

    @Delete
    suspend fun deleteCase(caseItem: CaseEntity)

    @Query("DELETE FROM cases WHERE caseId = :caseId")
    suspend fun deleteCaseById(caseId: String)

    @Query("UPDATE cases SET amountPaid = amountPaid + :amount WHERE caseId = :caseId")
    suspend fun incrementAmountPaid(caseId: String, amount: Double)

    @Query("UPDATE cases SET amountPaid = amountPaid + :amount WHERE caseId = :caseId")
    suspend fun recordPayment(caseId: String, amount: Double)

    @Query("UPDATE cases SET amountPaid = amountPaid - :amount WHERE caseId = :caseId")
    suspend fun decrementAmountPaid(caseId: String, amount: Double)

    @Query("UPDATE cases SET assignedOfficerId = :officerId, assignedOfficerName = :officerName WHERE caseId = :caseId")
    suspend fun reassignCase(caseId: String, officerId: String, officerName: String)

    @Query("UPDATE cases SET assignedOfficerId = :officerId, assignedOfficerName = :officerName WHERE caseId = :caseId")
    suspend fun reassignOfficer(caseId: String, officerId: String, officerName: String)

    @Query("UPDATE cases SET legalStage = :stage WHERE caseId = :caseId")
    suspend fun updateLegalStage(caseId: String, stage: String)

    @Query("UPDATE cases SET status = :status WHERE caseId = :caseId")
    suspend fun updateCaseStatus(caseId: String, status: String)

    @Query("UPDATE cases SET status = :status WHERE caseId = :caseId")
    suspend fun updateStatus(caseId: String, status: String)
}

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payment_transactions ORDER BY paymentDate DESC")
    fun getAllPaymentsFlow(): Flow<List<PaymentTransactionEntity>>

    @Query("SELECT * FROM payment_transactions ORDER BY paymentDate DESC")
    fun getAllPayments(): Flow<List<PaymentTransactionEntity>>

    @Query("SELECT * FROM payment_transactions WHERE caseId = :caseId ORDER BY paymentDate DESC")
    fun getPaymentsForCaseFlow(caseId: String): Flow<List<PaymentTransactionEntity>>

    @Query("SELECT * FROM payment_transactions WHERE caseId = :caseId ORDER BY paymentDate DESC")
    fun getPaymentsForCase(caseId: String): Flow<List<PaymentTransactionEntity>>

    @Query("SELECT * FROM payment_transactions WHERE receiptNumber = :receiptNumber LIMIT 1")
    suspend fun getPaymentByReceipt(receiptNumber: String): PaymentTransactionEntity?

    @Query("SELECT * FROM payment_transactions WHERE id = :id LIMIT 1")
    suspend fun getPaymentById(id: Long): PaymentTransactionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: PaymentTransactionEntity): Long

    @Delete
    suspend fun deletePayment(payment: PaymentTransactionEntity)

    @Query("DELETE FROM payment_transactions WHERE id = :id")
    suspend fun deletePayment(id: Long)

    @Query("UPDATE payment_transactions SET verified = :verified WHERE id = :id")
    suspend fun setVerification(id: Long, verified: Boolean)

    @Query("UPDATE payment_transactions SET verified = :verified WHERE id = :id")
    suspend fun updatePaymentVerification(id: Long, verified: Boolean)
}

@Dao
interface PromiseDao {
    @Query("SELECT * FROM promises_to_pay ORDER BY createdAt DESC")
    fun getAllPromisesFlow(): Flow<List<PromiseToPayEntity>>

    @Query("SELECT * FROM promises_to_pay ORDER BY createdAt DESC")
    fun getAllPromises(): Flow<List<PromiseToPayEntity>>

    @Query("SELECT * FROM promises_to_pay WHERE caseId = :caseId ORDER BY createdAt DESC")
    fun getPromisesForCaseFlow(caseId: String): Flow<List<PromiseToPayEntity>>

    @Query("SELECT * FROM promises_to_pay WHERE caseId = :caseId ORDER BY createdAt DESC")
    fun getPromisesForCase(caseId: String): Flow<List<PromiseToPayEntity>>

    @Query("SELECT * FROM promises_to_pay WHERE id = :id LIMIT 1")
    suspend fun getPromiseById(id: Long): PromiseToPayEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPromise(promise: PromiseToPayEntity): Long

    @Update
    suspend fun updatePromise(promise: PromiseToPayEntity)

    @Query("UPDATE promises_to_pay SET status = :status WHERE id = :id")
    suspend fun updatePromiseStatus(id: Long, status: String)

    @Query("UPDATE promises_to_pay SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String)
}

@Dao
interface FieldVisitDao {
    @Query("SELECT * FROM field_visits ORDER BY id DESC")
    fun getAllVisitsFlow(): Flow<List<FieldVisitEntity>>

    @Query("SELECT * FROM field_visits ORDER BY id DESC")
    fun getAllVisits(): Flow<List<FieldVisitEntity>>

    @Query("SELECT * FROM field_visits WHERE caseId = :caseId ORDER BY id DESC")
    fun getVisitsForCaseFlow(caseId: String): Flow<List<FieldVisitEntity>>

    @Query("SELECT * FROM field_visits WHERE caseId = :caseId ORDER BY id DESC")
    fun getVisitsForCase(caseId: String): Flow<List<FieldVisitEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVisit(visit: FieldVisitEntity): Long

    @Update
    suspend fun updateVisit(visit: FieldVisitEntity)
}

@Dao
interface PaymentPlanDao {
    @Query("SELECT * FROM payment_plans WHERE caseId = :caseId LIMIT 1")
    suspend fun getPlanForCase(caseId: String): PaymentPlanEntity?

    @Query("SELECT * FROM payment_plans WHERE caseId = :caseId LIMIT 1")
    fun getPlanForCaseFlow(caseId: String): Flow<PaymentPlanEntity?>

    @Query("SELECT * FROM payment_plans ORDER BY id DESC")
    fun getAllPlans(): Flow<List<PaymentPlanEntity>>

    @Query("SELECT * FROM payment_plans WHERE caseId = :caseId ORDER BY id DESC")
    fun getPlansForCase(caseId: String): Flow<List<PaymentPlanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlan(plan: PaymentPlanEntity): Long

    @Update
    suspend fun updatePlan(plan: PaymentPlanEntity)
}

@Dao
interface LegalDocDao {
    @Query("SELECT * FROM legal_documents ORDER BY id DESC")
    fun getAllDocumentsFlow(): Flow<List<LegalDocumentEntity>>

    @Query("SELECT * FROM legal_documents ORDER BY id DESC")
    fun getAllLegalDocuments(): Flow<List<LegalDocumentEntity>>

    @Query("SELECT * FROM legal_documents WHERE caseId = :caseId ORDER BY id DESC")
    fun getDocumentsForCaseFlow(caseId: String): Flow<List<LegalDocumentEntity>>

    @Query("SELECT * FROM legal_documents WHERE caseId = :caseId ORDER BY id DESC")
    fun getDocumentsForCase(caseId: String): Flow<List<LegalDocumentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(doc: LegalDocumentEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDoc(doc: LegalDocumentEntity): Long

    @Update
    suspend fun updateDocument(doc: LegalDocumentEntity)
}

@Dao
interface TimelineDao {
    @Query("SELECT * FROM timeline_actions WHERE caseId = :caseId ORDER BY timestamp DESC")
    fun getTimelineForCaseFlow(caseId: String): Flow<List<TimelineActionEntity>>

    @Query("SELECT * FROM timeline_actions WHERE caseId = :caseId ORDER BY timestamp DESC")
    fun getTimelineForCase(caseId: String): Flow<List<TimelineActionEntity>>

    @Query("SELECT * FROM timeline_actions ORDER BY timestamp DESC LIMIT 200")
    fun getAllRecentTimeline(): Flow<List<TimelineActionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAction(action: TimelineActionEntity): Long
}

@Dao
interface SmsNotificationDao {
    @Query("SELECT * FROM sms_notifications ORDER BY timestamp DESC")
    fun getAllSmsFlow(): Flow<List<SmsNotificationEntity>>

    @Query("SELECT * FROM sms_notifications ORDER BY timestamp DESC")
    fun getAllSms(): Flow<List<SmsNotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSms(sms: SmsNotificationEntity): Long

    @Query("DELETE FROM sms_notifications")
    suspend fun clearAll()

    @Query("DELETE FROM sms_notifications")
    suspend fun clearAllSms()

    @Query("DELETE FROM sms_notifications WHERE id = :id")
    suspend fun deleteSms(id: Long)
}

@Dao
interface SystemConfigDao {
    @Query("SELECT * FROM system_config WHERE configKey = 'MAIN_CONFIG' LIMIT 1")
    fun getConfigFlow(): Flow<SystemConfigEntity?>

    @Query("SELECT * FROM system_config WHERE configKey = 'MAIN_CONFIG' LIMIT 1")
    fun getConfig(): Flow<SystemConfigEntity?>

    @Query("SELECT * FROM system_config WHERE configKey = 'MAIN_CONFIG' LIMIT 1")
    suspend fun getDirectConfig(): SystemConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(config: SystemConfigEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateConfig(config: SystemConfigEntity)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentAuditLogsFlow(limit: Int = 100): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLogEntity): Long
}
