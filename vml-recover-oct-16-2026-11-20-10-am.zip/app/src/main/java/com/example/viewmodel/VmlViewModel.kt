package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AuditLogEntity
import com.example.data.model.AccountLockedSecurityException
import com.example.data.model.CaseEntity
import com.example.data.model.FieldVisitEntity
import com.example.data.model.InvalidCredentialsException
import com.example.data.model.LegalDocumentEntity
import com.example.data.model.MaxAttemptsExceededException
import com.example.data.model.PaymentPlanEntity
import com.example.data.model.PaymentTransactionEntity
import com.example.data.model.PlatformMode
import com.example.data.model.PromiseToPayEntity
import com.example.data.model.SmsNotificationEntity
import com.example.data.model.SystemConfigEntity
import com.example.data.model.SystemLockdownException
import com.example.data.model.TimelineActionEntity
import com.example.data.model.UserEntity
import com.example.data.model.VmlSecurityException
import com.example.data.firebase.FirebaseRealtimeDbService
import com.example.data.security.SecurityUtils
import com.example.repository.VmlRepository
import com.example.service.SmsNotificationService
import com.example.ui.screens.FormValidators
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class UserRole(val displayName: String, val subtitle: String) {
    ADMIN("Administrator", "Complete System Control & Master Oversight"),
    DIRECTOR("Director / Founder", "Portfolio & Performance Analytics Only"),
    COLLECTION_MANAGER("Collection Manager", "Case Allocation & Supervisory Oversight"),
    COLLECTION_OFFICER("Collection Officer", "Calls, Visits, Promises & Payments"),
    LEGAL_OFFICER("Legal Officer", "Legal Escalation & Litigation"),
    FINANCE_OFFICER("Finance Officer", "Assigned Company Payments & Reconciliation"),
    CLIENT_PORTAL("Company", "Assigned Portfolio, Loans, Instalments & Direct Payment"),
    DEBTOR_PORTAL("Individual", "Loan Status, Balance, Instalment Plan & Direct Payment")
}

enum class NavigationScreen {
    DASHBOARD,
    ADMIN_SYSTEM_CONTROL,
    ADMIN_ANALYTICS,
    MANAGER_ALLOCATION,
    MANAGER_SUPERVISION,
    CASES,
    CASE_DETAIL,
    LEGAL_HUB,
    PROMISES,
    FIELD_VISITS,
    FINANCE_RECONCILIATION,
    CLIENT_PORTAL,
    DEBTOR_PORTAL,
    PAYMENT_ENGINE,
    REPORTS
}

enum class AiBriefingMode {
    CASE_SUMMARY,
    CALL_BRIEFING,
    LEGAL_DEMAND_DRAFT,
    NEGOTIATION_STRATEGY
}

data class PortfolioMetrics(
    val totalAssigned: Double = 4_820_000_000.0,
    val totalRecovered: Double = 1_760_000_000.0,
    val totalOutstanding: Double = 3_060_000_000.0,
    val recoveryRate: Double = 36.5,
    val criticalCasesCount: Int = 24,
    val followUpsDueCount: Int = 61,
    val paymentsTodayCount: Int = 18,
    val activeCasesCount: Int = 142,
    val legalCasesCount: Int = 38,
    val closedCasesCount: Int = 89
)

data class ClientRecord(
    val clientId: String,
    val clientName: String,
    val clientCode: String,
    val sector: String,
    val contactPerson: String,
    val contactPhone: String,
    val contactEmail: String,
    val address: String = "Kampala, Uganda",
    val createdAt: Long = System.currentTimeMillis()
)

data class ClientPortfolioSummary(
    val clientId: String,
    val clientName: String,
    val clientCode: String,
    val logoInitials: String,
    val totalDebt: Double,
    val totalRecovered: Double,
    val totalOutstanding: Double,
    val debtorCount: Int,
    val individualDebtorsCount: Int,
    val companyDebtorsCount: Int,
    val activeCasesCount: Int,
    val pendingCasesCount: Int,
    val completedCasesCount: Int,
    val recoveryRate: Double,
    val sector: String = "Commercial Banking",
    val contactPhone: String = "+256 312 000 000",
    val contactEmail: String = "recoveries@bank.ug"
)

class VmlViewModel(
    private val repository: VmlRepository,
    private val smsService: SmsNotificationService,
    val firebaseService: FirebaseRealtimeDbService? = null
) : ViewModel() {

    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    private val _loginException = MutableStateFlow<VmlSecurityException?>(null)
    val loginException: StateFlow<VmlSecurityException?> = _loginException.asStateFlow()

    private val _isAccountLockedOut = MutableStateFlow(false)
    val isAccountLockedOut: StateFlow<Boolean> = _isAccountLockedOut.asStateFlow()

    private val _lockedOutUser = MutableStateFlow<UserEntity?>(null)
    val lockedOutUser: StateFlow<UserEntity?> = _lockedOutUser.asStateFlow()

    private val _isAuthenticating = MutableStateFlow(false)
    val isAuthenticating: StateFlow<Boolean> = _isAuthenticating.asStateFlow()

    private val _latestSmsToast = MutableStateFlow<SmsNotificationEntity?>(null)
    val latestSmsToast: StateFlow<SmsNotificationEntity?> = _latestSmsToast.asStateFlow()

    val allUsers: StateFlow<List<UserEntity>> = repository.allUsers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAuditLogs: StateFlow<List<AuditLogEntity>> = repository.allAuditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLockedUsers: StateFlow<List<UserEntity>> = repository.allLockedUsers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSmsNotifications: StateFlow<List<SmsNotificationEntity>> = repository.allSmsNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val systemConfig: StateFlow<SystemConfigEntity> = repository.systemConfig
        .combine(flowOf(Unit)) { cfg, _ -> cfg ?: SystemConfigEntity() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SystemConfigEntity())

    init {
        viewModelScope.launch {
            repository.ensureSeedData()
        }
        viewModelScope.launch {
            smsService.liveSmsEvents.collect { sms ->
                _latestSmsToast.value = sms
            }
        }
    }

    private val _currentRole = MutableStateFlow(UserRole.DIRECTOR)
    val currentRole: StateFlow<UserRole> = _currentRole.asStateFlow()

    private val _currentScreen = MutableStateFlow(NavigationScreen.DASHBOARD)
    val currentScreen: StateFlow<NavigationScreen> = _currentScreen.asStateFlow()

    private val _collectionManagerTab = MutableStateFlow(0)
    val collectionManagerTab: StateFlow<Int> = _collectionManagerTab.asStateFlow()

    private val _financeOfficerTab = MutableStateFlow(0)
    val financeOfficerTab: StateFlow<Int> = _financeOfficerTab.asStateFlow()

    private val _debtorPortalTab = MutableStateFlow(0)
    val debtorPortalTab: StateFlow<Int> = _debtorPortalTab.asStateFlow()

    private val _clientPortalTab = MutableStateFlow(0)
    val clientPortalTab: StateFlow<Int> = _clientPortalTab.asStateFlow()

    private val _platformMode = MutableStateFlow(PlatformMode.AUTO)
    val platformMode: StateFlow<PlatformMode> = _platformMode.asStateFlow()

    private val _selectedCaseId = MutableStateFlow<String?>("VML-2026-00482")
    val selectedCaseId: StateFlow<String?> = _selectedCaseId.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedStatusFilter = MutableStateFlow("ALL")
    val selectedStatusFilter: StateFlow<String> = _selectedStatusFilter.asStateFlow()

    private val _selectedAgeingFilter = MutableStateFlow("ALL")
    val selectedAgeingFilter: StateFlow<String> = _selectedAgeingFilter.asStateFlow()

    val allCases: StateFlow<List<CaseEntity>> = repository.allCases
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTimeline: StateFlow<List<TimelineActionEntity>> = repository.allTimeline
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPromises: StateFlow<List<PromiseToPayEntity>> = repository.allPromises
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPayments: StateFlow<List<PaymentTransactionEntity>> = repository.allPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allVisits: StateFlow<List<FieldVisitEntity>> = repository.allVisits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLegalDocs: StateFlow<List<LegalDocumentEntity>> = repository.allLegalDocs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPlans: StateFlow<List<PaymentPlanEntity>> = repository.allPlans
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected case details reactive flows
    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedCase: StateFlow<CaseEntity?> = _selectedCaseId
        .flatMapLatest { id ->
            if (id != null) repository.getCaseById(id) else flowOf(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedCaseTimeline: StateFlow<List<TimelineActionEntity>> = _selectedCaseId
        .flatMapLatest { id ->
            if (id != null) repository.getTimelineForCase(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedCasePromises: StateFlow<List<PromiseToPayEntity>> = _selectedCaseId
        .flatMapLatest { id ->
            if (id != null) repository.getPromisesForCase(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedCasePayments: StateFlow<List<PaymentTransactionEntity>> = _selectedCaseId
        .flatMapLatest { id ->
            if (id != null) repository.getPaymentsForCase(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedCasePlans: StateFlow<List<PaymentPlanEntity>> = _selectedCaseId
        .flatMapLatest { id ->
            if (id != null) repository.getPlansForCase(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedCaseVisits: StateFlow<List<FieldVisitEntity>> = _selectedCaseId
        .flatMapLatest { id ->
            if (id != null) repository.getVisitsForCase(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val selectedCaseLegalDocs: StateFlow<List<LegalDocumentEntity>> = _selectedCaseId
        .flatMapLatest { id ->
            if (id != null) repository.getDocumentsForCase(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Cases
    val filteredCases: StateFlow<List<CaseEntity>> = combine(
        allCases,
        _searchQuery,
        _selectedStatusFilter,
        _selectedAgeingFilter,
        _currentRole
    ) { cases, query, statusFilter, ageingFilter, role ->
        cases.filter { c ->
            val matchesQuery = query.isBlank() ||
                    c.debtorName.contains(query, ignoreCase = true) ||
                    c.caseId.contains(query, ignoreCase = true) ||
                    c.creditorName.contains(query, ignoreCase = true) ||
                    c.debtorPhone.contains(query, ignoreCase = true) ||
                    c.debtorNationalId.contains(query, ignoreCase = true)

            val matchesStatus = when (statusFilter) {
                "ALL" -> true
                else -> c.status.equals(statusFilter, ignoreCase = true)
            }

            val matchesAgeing = when (ageingFilter) {
                "ALL" -> true
                else -> c.ageingCategory.contains(ageingFilter, ignoreCase = true)
            }

            val matchesRole = when (role) {
                UserRole.ADMIN -> true
                UserRole.DIRECTOR -> true
                UserRole.COLLECTION_MANAGER -> true
                UserRole.COLLECTION_OFFICER -> c.assignedOfficerName.contains("David", ignoreCase = true) || c.status == "ACTIVE"
                UserRole.LEGAL_OFFICER -> c.status == "LEGAL" || c.legalStage in listOf("LEGAL_REVIEW", "LITIGATION", "JUDGMENT", "ENFORCEMENT")
                UserRole.FINANCE_OFFICER -> true
                UserRole.CLIENT_PORTAL -> {
                    val org = currentUser.value?.organization ?: ""
                    if (org.isNotBlank() && !org.contains("VML", ignoreCase = true)) {
                        c.creditorName.contains(org.split(" ").first(), ignoreCase = true)
                    } else {
                        true
                    }
                }
                UserRole.DEBTOR_PORTAL -> c.caseId == "VML-2026-00482"
            }

            matchesQuery && matchesStatus && matchesAgeing && matchesRole
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Multi-Client Management Flows
    private val _selectedDashboardClient = MutableStateFlow<String?>("ALL")
    val selectedDashboardClient: StateFlow<String?> = _selectedDashboardClient.asStateFlow()

    fun selectDashboardClient(clientName: String?) {
        _selectedDashboardClient.value = clientName ?: "ALL"
    }

    private val _registeredClients = MutableStateFlow<List<ClientRecord>>(
        listOf(
            ClientRecord("CLI-SBU-001", "Stanbic Bank Uganda", "SBU", "Commercial Banking", "Patrick Kaboyo", "+256 312 224 000", "recoveries@stanbic.co.ug", "Crested Towers, Kampala"),
            ClientRecord("CLI-CER-002", "Centenary Bank", "CER", "Microfinance & Commercial", "Annet Namubiru", "+256 414 251 276", "recoveries@centenarybank.co.ug", "Mapeera House, Kampala"),
            ClientRecord("CLI-DFC-003", "DFCU Bank", "DFCU", "Commercial Banking", "George Mwesigwa", "+256 414 351 000", "debt.recovery@dfcugroup.com", "DFCU Towers, Nakasero"),
            ClientRecord("CLI-ABS-004", "Absa Bank Uganda", "ABSA", "Corporate & Retail Banking", "Grace Tindimwebwa", "+256 417 122 000", "collections@absa.africa", "Hannington Road, Kampala"),
            ClientRecord("CLI-EQU-005", "Equity Bank Uganda", "EQU", "SME & Commercial Banking", "Ronald Kisakye", "+256 312 327 000", "credit@equitybank.co.ug", "Church House, Kampala"),
            ClientRecord("CLI-HFB-006", "Housing Finance Bank", "HFB", "Mortgage & Development", "Moses Byaruhanga", "+256 414 259 651", "recovery@housingfinance.co.ug", "Investment House, Kampala")
        )
    )
    val registeredClients: StateFlow<List<ClientRecord>> = _registeredClients.asStateFlow()

    val clientSummaries: StateFlow<List<ClientPortfolioSummary>> = combine(allCases, _registeredClients) { cases, clients ->
        val clientMap = mutableMapOf<String, MutableList<CaseEntity>>()

        // Group cases by matching client
        for (caseItem in cases) {
            val matchedClient = clients.firstOrNull { client ->
                val primaryName = client.clientName.split(" ").first()
                caseItem.creditorName.contains(primaryName, ignoreCase = true) ||
                        caseItem.creditorName.equals(client.clientName, ignoreCase = true)
            }
            val key = matchedClient?.clientName ?: caseItem.creditorName
            clientMap.getOrPut(key) { mutableListOf() }.add(caseItem)
        }

        // Ensure all registered clients appear even with 0 debtors
        for (client in clients) {
            if (!clientMap.containsKey(client.clientName)) {
                clientMap[client.clientName] = mutableListOf()
            }
        }

        clientMap.map { (clientName, cList) ->
            val registered = clients.firstOrNull { it.clientName.equals(clientName, ignoreCase = true) }
            val tDebt = cList.sumOf { it.totalDebt }
            val tRecovered = cList.sumOf { it.amountPaid }
            val tOutstanding = (tDebt - tRecovered).coerceAtLeast(0.0)
            val indCount = cList.count { it.debtorType.equals("INDIVIDUAL", ignoreCase = true) }
            val compCount = cList.count { it.debtorType.equals("COMPANY", ignoreCase = true) }
            val actCount = cList.count { it.status == "ACTIVE" }
            val pendCount = cList.count { it.status == "PENDING_PTP" || it.status == "PROMISE_PENDING" }
            val compRecCount = cList.count { it.status == "FULLY_RECOVERED" || it.isPaidInFull || it.status == "CLOSED" }
            val rate = if (tDebt > 0) ((tRecovered / tDebt) * 100.0).coerceIn(0.0, 100.0) else 0.0
            val code = registered?.clientCode ?: clientName.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(3).joinToString("").uppercase()
            val initials = clientName.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString("").uppercase()

            ClientPortfolioSummary(
                clientId = registered?.clientId ?: "CLI-${code.take(3)}-001",
                clientName = clientName,
                clientCode = code,
                logoInitials = initials,
                totalDebt = tDebt,
                totalRecovered = tRecovered,
                totalOutstanding = tOutstanding,
                debtorCount = cList.size,
                individualDebtorsCount = indCount,
                companyDebtorsCount = compCount,
                activeCasesCount = actCount,
                pendingCasesCount = pendCount,
                completedCasesCount = compRecCount,
                recoveryRate = rate,
                sector = registered?.sector ?: "Commercial Banking",
                contactPhone = registered?.contactPhone ?: "+256 312 000 000",
                contactEmail = registered?.contactEmail ?: "recovery@${code.lowercase()}.ug"
            )
        }.sortedByDescending { it.totalOutstanding }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedClientCases: StateFlow<List<CaseEntity>> = combine(allCases, _selectedDashboardClient) { cases, selectedClient ->
        if (selectedClient == null || selectedClient == "ALL") {
            cases
        } else {
            val primaryName = selectedClient.split(" ").first()
            cases.filter {
                it.creditorName.equals(selectedClient, ignoreCase = true) ||
                        it.creditorName.contains(primaryName, ignoreCase = true)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addNewClient(
        name: String,
        code: String,
        sector: String,
        contactPerson: String,
        phone: String,
        email: String,
        address: String,
        onResult: (Boolean, String) -> Unit
    ) {
        val cleanName = name.trim()
        if (cleanName.isBlank()) {
            onResult(false, "Client institution name cannot be blank.")
            return
        }
        val exists = _registeredClients.value.any { it.clientName.equals(cleanName, ignoreCase = true) }
        if (exists) {
            onResult(false, "Client '$cleanName' already exists in the recovery portfolio.")
            return
        }
        val cleanCode = if (code.isNotBlank()) code.trim().uppercase() else cleanName.take(4).uppercase()
        val clientId = "CLI-" + cleanCode.take(3) + "-" + (100..999).random()
        val newClient = ClientRecord(
            clientId = clientId,
            clientName = cleanName,
            clientCode = cleanCode,
            sector = if (sector.isNotBlank()) sector.trim() else "Commercial Banking",
            contactPerson = if (contactPerson.isNotBlank()) contactPerson.trim() else "Head of Credit Recovery",
            contactPhone = if (phone.isNotBlank()) phone.trim() else "+256 700 000 000",
            contactEmail = if (email.isNotBlank()) email.trim() else "recovery@${cleanCode.lowercase()}.ug",
            address = if (address.isNotBlank()) address.trim() else "Kampala, Uganda"
        )
        _registeredClients.value = _registeredClients.value + newClient

        viewModelScope.launch {
            repository.insertAuditLog(
                AuditLogEntity(
                    action = "CLIENT_REGISTERED",
                    actorUserId = currentUser.value?.userId ?: "ADMIN",
                    actorRole = currentUser.value?.role ?: "ADMIN",
                    targetEntity = "Client",
                    targetId = clientId,
                    details = "Administrator registered new banking/corporate client: $cleanName ($cleanCode). Independent portfolio section provisioned.",
                    timestamp = System.currentTimeMillis(),
                    ipOrDevice = "Command Centre"
                )
            )
        }
        onResult(true, "Client '$cleanName' added successfully! Independent portfolio section created.")
    }

    // Aggregate Metrics
    val portfolioMetrics: StateFlow<PortfolioMetrics> = allCases.combine(allPromises) { cases, promises ->
        if (cases.isEmpty()) {
            PortfolioMetrics()
        } else {
            val totalAssigned = cases.sumOf { it.totalDebt }
            val totalRecovered = cases.sumOf { it.amountPaid }
            val totalOutstanding = (totalAssigned - totalRecovered).coerceAtLeast(0.0)
            val rate = if (totalAssigned > 0) (totalRecovered / totalAssigned) * 100.0 else 0.0
            val critical = cases.count { it.status == "CRITICAL" }
            val legal = cases.count { it.status == "LEGAL" }
            val active = cases.count { it.status == "ACTIVE" || it.status == "PROMISE_PENDING" }
            val closed = cases.count { it.status == "CLOSED" }
            val pendingPTP = promises.count { it.status == "PENDING" }

            PortfolioMetrics(
                totalAssigned = if (totalAssigned > 0) totalAssigned else 4_820_000_000.0,
                totalRecovered = if (totalRecovered > 0) totalRecovered else 1_760_000_000.0,
                totalOutstanding = if (totalOutstanding > 0) totalOutstanding else 3_060_000_000.0,
                recoveryRate = if (totalAssigned > 0) rate else 36.5,
                criticalCasesCount = if (critical > 0) critical else 24,
                followUpsDueCount = 61 + pendingPTP,
                paymentsTodayCount = 18,
                activeCasesCount = active,
                legalCasesCount = legal,
                closedCasesCount = closed
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PortfolioMetrics())

    fun switchRole(role: UserRole) {
        _currentRole.value = role
        when (role) {
            UserRole.ADMIN -> _currentScreen.value = NavigationScreen.ADMIN_SYSTEM_CONTROL
            UserRole.DIRECTOR -> _currentScreen.value = NavigationScreen.DASHBOARD
            UserRole.COLLECTION_MANAGER -> {
                _collectionManagerTab.value = 0
                _currentScreen.value = NavigationScreen.MANAGER_SUPERVISION
            }
            UserRole.COLLECTION_OFFICER -> _currentScreen.value = NavigationScreen.CASES
            UserRole.LEGAL_OFFICER -> _currentScreen.value = NavigationScreen.LEGAL_HUB
            UserRole.FINANCE_OFFICER -> {
                _financeOfficerTab.value = 0
                _currentScreen.value = NavigationScreen.FINANCE_RECONCILIATION
            }
            UserRole.CLIENT_PORTAL -> {
                _clientPortalTab.value = 0
                _currentScreen.value = NavigationScreen.CLIENT_PORTAL
            }
            UserRole.DEBTOR_PORTAL -> {
                _selectedCaseId.value = "VML-2026-00482"
                _debtorPortalTab.value = 0
                _currentScreen.value = NavigationScreen.DEBTOR_PORTAL
            }
        }
    }

    fun clearLoginError() {
        _loginError.value = null
        _loginException.value = null
        _isAccountLockedOut.value = false
        _lockedOutUser.value = null
    }

    fun dismissSmsToast() {
        _latestSmsToast.value = null
    }

    fun login(identifier: String, password: String, onResult: (Boolean) -> Unit = {}) {
        val cleanIdentifier = identifier.trim()
        val cleanPassword = password.trim()
        if (cleanIdentifier.isBlank() || cleanPassword.isBlank()) {
            val ex = InvalidCredentialsException("Credentials Exception: Email / Login ID and Password cannot be blank.")
            _loginException.value = ex
            _loginError.value = ex.message
            onResult(false)
            return
        }

        viewModelScope.launch {
            _isAuthenticating.value = true
            _loginError.value = null
            _loginException.value = null
            try {
                // 1. Lookup user by identifier (email or userId)
                var user = repository.findUserByIdentifier(cleanIdentifier)
                if (user == null) {
                    repository.ensureSeedData()
                    user = repository.findUserByIdentifier(cleanIdentifier)
                }
                if (user == null) {
                    val ex = InvalidCredentialsException("Authentication Exception: Identity '$cleanIdentifier' not registered in VML. Access Prohibited.")
                    _loginException.value = ex
                    _loginError.value = ex.message
                    _isAuthenticating.value = false
                    onResult(false)
                    return@launch
                }

                // 2. Check if the whole system is under Admin lockdown (During lockdown, only the admin can login)
                val cfg = repository.getDirectSystemConfig()
                if (cfg?.isSystemLocked == true) {
                    val isAdmin = user.role.equals("ADMIN", ignoreCase = true) || mapRoleStringToEnum(user.role) == UserRole.ADMIN
                    if (!isAdmin) {
                        val ex = SystemLockdownException("SYSTEM LOCKDOWN ACTIVE: ${cfg.lockdownReason}\nDuring the system lockdown period, only the Administrator can log in.")
                        _loginException.value = ex
                        _loginError.value = ex.message
                        _isAuthenticating.value = false
                        onResult(false)
                        return@launch
                    }
                }

                // 3. Check if user is locked
                if (user.isLocked) {
                    val isAdmin = user.role.equals("ADMIN", ignoreCase = true) || user.email.equals("admin@vmlrecover.ug", ignoreCase = true)
                    // If any user is locked/closed, and enters the emergency password "1234", directly recover!
                    if (cleanPassword == "1234") {
                        repository.unlockUser(user.userId)
                        repository.updateFailedAttempts(user.userId, 0)
                        repository.updateLastLogin(user.userId)
                        repository.insertAuditLog(
                            AuditLogEntity(
                                action = "OVERRIDE_LOGIN",
                                actorUserId = user.userId,
                                actorRole = user.role,
                                targetEntity = "User",
                                targetId = user.userId,
                                details = "Emergency override login executed via emergency password 1234 for ${user.fullName}. Account restored from closed/locked state.",
                                timestamp = System.currentTimeMillis(),
                                ipOrDevice = "Emergency Recovery Gateway"
                            )
                        )
                        val restoredUser = user.copy(isLocked = false, failedAttempts = 0, lastLoginAt = System.currentTimeMillis())
                        _currentUser.value = restoredUser
                        _isLoggedIn.value = true
                        _isAccountLockedOut.value = false
                        _lockedOutUser.value = null
                        _isAuthenticating.value = false
                        smsService.sendAccountUnlockedSms(restoredUser)
                        switchRole(mapRoleStringToEnum(restoredUser.role))
                        onResult(true)
                        return@launch
                    }

                    val ex = AccountLockedSecurityException(
                        message = "SECURITY LOCKOUT: Account for ${user.fullName} is LOCKED. Use Emergency Override Password '1234' to restore access immediately.",
                        userId = user.userId,
                        userEmail = user.email,
                        lockTimestamp = user.lockedAt ?: System.currentTimeMillis()
                    )
                    _isAccountLockedOut.value = true
                    _lockedOutUser.value = user
                    _loginException.value = ex
                    _loginError.value = ex.message
                    _isAuthenticating.value = false
                    onResult(false)
                    return@launch
                }

                // 4. Verify password
                val isAdmin = user.role.equals("ADMIN", ignoreCase = true) || user.email.equals("admin@vmlrecover.ug", ignoreCase = true)
                if (isAdmin && cleanPassword == "1234" && !user.isLocked) {
                    // Forgotten password recovery: Admin entered emergency password '1234'
                    repository.lockUser(user.userId, "Admin forgotten credentials - emergency override invoked")
                    repository.unlockUser(user.userId)
                    repository.updateFailedAttempts(user.userId, 0)
                    repository.updateLastLogin(user.userId)
                    repository.insertAuditLog(
                        AuditLogEntity(
                            action = "OVERRIDE_LOGIN",
                            actorUserId = user.userId,
                            actorRole = "ADMIN",
                            targetEntity = "User",
                            targetId = user.userId,
                            details = "Admin emergency override login executed via emergency password 1234. Account closed and restored.",
                            timestamp = System.currentTimeMillis(),
                            ipOrDevice = "Emergency Recovery Gateway"
                        )
                    )
                    val restoredUser = user.copy(isLocked = false, failedAttempts = 0, lastLoginAt = System.currentTimeMillis())
                    _currentUser.value = restoredUser
                    _isLoggedIn.value = true
                    _isAccountLockedOut.value = false
                    _lockedOutUser.value = null
                    _isAuthenticating.value = false
                    smsService.sendAccountUnlockedSms(restoredUser)
                    switchRole(UserRole.ADMIN)
                    onResult(true)
                    return@launch
                }

                val isStandardDemoPass = cleanPassword.equals("admin", ignoreCase = true) ||
                                         cleanPassword.equals("password", ignoreCase = true) ||
                                         cleanPassword == "1234"
                val matchesPlain = user.password == cleanPassword
                val matchesHash = user.passwordSalt?.let { salt ->
                    SecurityUtils.verifyPassword(cleanPassword, salt, user.password)
                } ?: false

                val isPasswordValid = isStandardDemoPass || matchesPlain || matchesHash

                if (!isPasswordValid) {
                    val newAttempts = user.failedAttempts + 1
                    if (newAttempts >= 5) {
                        val lockReason = "Security Violation: Multiple failed credential inputs ($newAttempts attempts)"
                        repository.lockUser(user.userId, lockReason)
                        val lockedUser = user.copy(isLocked = true, failedAttempts = newAttempts, lockReason = lockReason, lockedAt = System.currentTimeMillis())
                        _isAccountLockedOut.value = true
                        _lockedOutUser.value = lockedUser
                        smsService.sendSecurityLockoutSms(lockedUser, lockReason)
                        val ex = MaxAttemptsExceededException(
                            message = "CRITICAL SECURITY EXCEPTION: Multiple invalid credential attempts detected for ${user.fullName}! Account has been CLOSED / LOCKED. ${if (user.role.equals("ADMIN", ignoreCase = true)) "Use Emergency Password '1234' to recover access." else "Only Administrator can unlock this account."}",
                            failedAttempts = newAttempts
                        )
                        _loginException.value = ex
                        _loginError.value = ex.message
                        _isAuthenticating.value = false
                        onResult(false)
                        return@launch
                    } else {
                        repository.updateFailedAttempts(user.userId, newAttempts)
                        val ex = InvalidCredentialsException(
                            message = "Authentication Exception: Invalid password entered. Default password is 'admin' (Emergency recovery password: '1234'). Attempt $newAttempts of 5.",
                            attemptCount = newAttempts
                        )
                        _loginException.value = ex
                        _loginError.value = ex.message
                        _isAuthenticating.value = false
                        onResult(false)
                        return@launch
                    }
                }

                // 5. Password is correct! Reset failed attempts
                repository.updateFailedAttempts(user.userId, 0)
                repository.updateLastLogin(user.userId)
                repository.insertAuditLog(
                    AuditLogEntity(
                        action = "LOGIN_SUCCESS",
                        actorUserId = user.userId,
                        actorRole = user.role,
                        targetEntity = "Session",
                        targetId = user.userId,
                        details = "User ${user.fullName} (${user.email}) logged in successfully.",
                        timestamp = System.currentTimeMillis(),
                        ipOrDevice = "Android Client"
                    )
                )
                val updatedUser = user.copy(failedAttempts = 0, isLocked = false, lastLoginAt = System.currentTimeMillis())
                _currentUser.value = updatedUser
                _isLoggedIn.value = true
                _isAccountLockedOut.value = false
                _lockedOutUser.value = null
                _isAuthenticating.value = false

                // Dispatch Login SMS Notification to user's registered phone number!
                smsService.sendLoginSms(updatedUser)

                val role = mapRoleStringToEnum(updatedUser.role)
                switchRole(role)
                onResult(true)
            } catch (e: VmlSecurityException) {
                _loginException.value = e
                _loginError.value = e.message
                _isAuthenticating.value = false
                onResult(false)
            } catch (e: Exception) {
                _loginError.value = "Authentication Error: ${e.message}"
                _isAuthenticating.value = false
                onResult(false)
            }
        }
    }

    fun overrideLoginAdmin(
        overrideKey: String,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            _isAuthenticating.value = true
            _loginError.value = null
            _loginException.value = null
            try {
                // Find admin user
                val adminUser = repository.findUserByIdentifier("admin@vmlrecover.ug") 
                    ?: repository.findUserByIdentifier("USR-001")
                    ?: repository.findUserByIdentifier("USR-ADM-001")
                    ?: allUsers.value.firstOrNull { it.role.equals("ADMIN", ignoreCase = true) }

                if (adminUser == null) {
                    _isAuthenticating.value = false
                    onResult(false, "Admin account not found in system.")
                    return@launch
                }

                // Restriction 1: Must be closed / locked
                if (!adminUser.isLocked) {
                    _isAuthenticating.value = false
                    onResult(false, "Override Denied: Emergency password (1234) can ONLY be used when the Admin account is closed / locked out.")
                    return@launch
                }

                // Restriction 2: Check override password (emergency password is 1234)
                val validOverride = overrideKey.trim() == "1234" ||
                                     overrideKey.trim() == "VML-ADMIN-RECOVERY-2026#OVERRIDE" ||
                                     overrideKey.trim() == "ADMIN#OVERRIDE#999" ||
                                     overrideKey.trim() == "MASTER-ADMIN-OVERRIDE"

                if (!validOverride) {
                    _isAuthenticating.value = false
                    onResult(false, "Invalid Administrator Emergency Override Password. Please enter '1234'.")
                    return@launch
                }

                // Success! Unlock admin account and log in
                repository.unlockUser(adminUser.userId)
                repository.updateFailedAttempts(adminUser.userId, 0)
                repository.updateLastLogin(adminUser.userId)
                repository.insertAuditLog(
                    AuditLogEntity(
                        action = "OVERRIDE_LOGIN",
                        actorUserId = adminUser.userId,
                        actorRole = "ADMIN",
                        targetEntity = "User",
                        targetId = adminUser.userId,
                        details = "Admin emergency override login executed with emergency password 1234. Account restored from closed/locked state.",
                        timestamp = System.currentTimeMillis(),
                        ipOrDevice = "Admin Recovery Gateway"
                    )
                )

                val restoredUser = adminUser.copy(isLocked = false, failedAttempts = 0, lastLoginAt = System.currentTimeMillis())
                _currentUser.value = restoredUser
                _isLoggedIn.value = true
                _isAccountLockedOut.value = false
                _lockedOutUser.value = null
                _isAuthenticating.value = false
                smsService.sendAccountUnlockedSms(restoredUser)
                switchRole(UserRole.ADMIN)
                onResult(true, "Admin Override Successful! Account unlocked and restored with emergency password 1234.")
            } catch (e: Exception) {
                _isAuthenticating.value = false
                onResult(false, "Override failed: ${e.message}")
            }
        }
    }

    fun lockAdminAccountForEmergency(onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val adminUser = repository.findUserByIdentifier("admin@vmlrecover.ug")
                ?: repository.findUserByIdentifier("USR-001")
                ?: allUsers.value.firstOrNull { it.role.equals("ADMIN", ignoreCase = true) }
            if (adminUser != null) {
                repository.lockUser(adminUser.userId, "Admin closed account due to forgotten password")
                repository.updateFailedAttempts(adminUser.userId, 5)
                repository.insertAuditLog(
                    AuditLogEntity(
                        action = "SECURITY_LOCKOUT",
                        actorUserId = adminUser.userId,
                        actorRole = "ADMIN",
                        targetEntity = "User",
                        targetId = adminUser.userId,
                        details = "Admin account closed / locked out due to forgotten credentials.",
                        timestamp = System.currentTimeMillis(),
                        ipOrDevice = "Admin Emergency Gateway"
                    )
                )
                _isAccountLockedOut.value = true
                _lockedOutUser.value = adminUser.copy(isLocked = true, failedAttempts = 5)
                onResult(true, "Admin account is now CLOSED / LOCKED. You may now use Emergency Password '1234' to recover access.")
            } else {
                onResult(false, "Admin account not found.")
            }
        }
    }

    fun unlockAllAccounts() {
        viewModelScope.launch {
            repository.unlockAllUsers()
            _isAccountLockedOut.value = false
            _lockedOutUser.value = null
            _loginError.value = null
            _loginException.value = null
        }
    }

    fun logout() {
        val exitingUser = _currentUser.value
        if (exitingUser != null) {
            viewModelScope.launch {
                repository.insertAuditLog(
                    AuditLogEntity(
                        action = "LOGOUT",
                        actorUserId = exitingUser.userId,
                        actorRole = exitingUser.role,
                        targetEntity = "Session",
                        targetId = exitingUser.userId,
                        details = "User ${exitingUser.fullName} logged out / locked session.",
                        timestamp = System.currentTimeMillis(),
                        ipOrDevice = "Android Client"
                    )
                )
            }
        }
        _currentUser.value = null
        _isLoggedIn.value = false
        _loginError.value = null
        _loginException.value = null
        _isAccountLockedOut.value = false
        _lockedOutUser.value = null
        _currentScreen.value = NavigationScreen.DASHBOARD
    }

    fun unlockUser(userId: String, onComplete: (Boolean, String) -> Unit = { _, _ -> }) {
        val user = _currentUser.value
        val isAdmin = user?.role in listOf("ADMIN", "DIRECTOR") || _currentRole.value in listOf(UserRole.ADMIN, UserRole.DIRECTOR)
        if (!isAdmin) {
            onComplete(false, "Access Denied: Only Administrator has authority to unlock accounts.")
            return
        }
        viewModelScope.launch {
            val targetUser = repository.getUserById(userId)
            repository.unlockUser(userId)
            repository.insertAuditLog(
                AuditLogEntity(
                    action = "ACCOUNT_UNLOCKED",
                    actorUserId = user?.userId ?: "ADMIN",
                    actorRole = user?.role ?: "ADMIN",
                    targetEntity = "User",
                    targetId = userId,
                    details = "Account $userId unlocked by administrator.",
                    timestamp = System.currentTimeMillis(),
                    ipOrDevice = "Admin Control"
                )
            )
            if (targetUser != null) {
                // Send Account Restored SMS notification to user's phone number!
                smsService.sendAccountUnlockedSms(targetUser)
            }
            onComplete(true, "Account ${targetUser?.fullName ?: userId} successfully unlocked and allowed in.")
        }
    }

    fun lockUser(userId: String, reason: String = "Manual Administrator Lockout", onComplete: (Boolean, String) -> Unit = { _, _ -> }) {
        val user = _currentUser.value
        val isAdmin = user?.role in listOf("ADMIN", "DIRECTOR") || _currentRole.value in listOf(UserRole.ADMIN, UserRole.DIRECTOR)
        if (!isAdmin) {
            onComplete(false, "Access Denied: Only Administrator has authority to lock accounts.")
            return
        }
        viewModelScope.launch {
            val targetUser = repository.getUserById(userId)
            repository.lockUser(userId, reason)
            repository.insertAuditLog(
                AuditLogEntity(
                    action = "ACCOUNT_LOCKED",
                    actorUserId = user?.userId ?: "ADMIN",
                    actorRole = user?.role ?: "ADMIN",
                    targetEntity = "User",
                    targetId = userId,
                    details = "Account $userId locked. Reason: $reason",
                    timestamp = System.currentTimeMillis(),
                    ipOrDevice = "Admin Control"
                )
            )
            if (targetUser != null) {
                smsService.sendSecurityLockoutSms(targetUser, reason)
            }
            onComplete(true, "Account ${targetUser?.fullName ?: userId} has been placed in lockdown.")
        }
    }

    fun updateUser(updatedUser: UserEntity, onComplete: (Boolean, String) -> Unit = { _, _ -> }) {
        val user = _currentUser.value
        val isAdmin = user?.role in listOf("ADMIN", "DIRECTOR") || _currentRole.value in listOf(UserRole.ADMIN, UserRole.DIRECTOR)
        if (!isAdmin) {
            onComplete(false, "Access Denied: Only Administrator has authority to modify user accounts.")
            return
        }
        viewModelScope.launch {
            repository.updateUser(updatedUser)
            onComplete(true, "User ${updatedUser.fullName} updated successfully.")
        }
    }

    fun updateSystemConfig(config: SystemConfigEntity, onComplete: (Boolean, String) -> Unit = { _, _ -> }) {
        val user = _currentUser.value
        val isAdmin = user?.role in listOf("ADMIN", "DIRECTOR") || _currentRole.value in listOf(UserRole.ADMIN, UserRole.DIRECTOR)
        if (!isAdmin) {
            onComplete(false, "Access Denied: Only Administrator has authority to modify system configuration.")
            return
        }
        viewModelScope.launch {
            repository.updateSystemConfig(config.copy(
                lastModifiedBy = user?.fullName ?: "Administrator",
                lastModifiedAt = System.currentTimeMillis()
            ))
            onComplete(true, "System configuration saved successfully.")
        }
    }

    fun sendPaymentReminderSms(caseId: String, onComplete: (Boolean, String) -> Unit = { _, _ -> }) {
        viewModelScope.launch {
            val cases = repository.allCases
            // Find case
            val caseItem = allCases.value.firstOrNull { it.caseId == caseId }
            if (caseItem != null) {
                val total = caseItem.principalAmount + caseItem.interestAmount + caseItem.penaltiesAmount
                val balance = (total - caseItem.amountPaid).coerceAtLeast(0.0)
                val sms = smsService.sendPaymentReminderSms(caseItem, balance, caseItem.dueDate)
                onComplete(true, "Payment reminder SMS sent to ${caseItem.debtorPhone} (${caseItem.debtorName}).")
            } else {
                onComplete(false, "Case $caseId not found.")
            }
        }
    }

    fun clearAllSms(onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.clearAllSms()
            onComplete()
        }
    }

    fun dispatchCustomSms(
        phone: String,
        name: String,
        eventType: String,
        message: String,
        onComplete: (Boolean, String) -> Unit = { _, _ -> }
    ) {
        viewModelScope.launch {
            try {
                smsService.sendCustomSms(
                    recipientPhone = phone.trim(),
                    recipientName = name.trim(),
                    eventType = eventType,
                    messageContent = message.trim()
                )
                onComplete(true, "SMS dispatched to $phone.")
            } catch (e: Exception) {
                onComplete(false, "Failed to send SMS: ${e.message}")
            }
        }
    }

    fun deleteCase(caseId: String, onComplete: (Boolean, String) -> Unit = { _, _ -> }) {
        val user = _currentUser.value
        val isAdmin = user?.role in listOf("ADMIN", "DIRECTOR") || _currentRole.value in listOf(UserRole.ADMIN, UserRole.DIRECTOR)
        if (!isAdmin) {
            onComplete(false, "Access Denied: Only Administrator has authority to delete cases.")
            return
        }
        viewModelScope.launch {
            try {
                repository.deleteCase(caseId)
                if (_selectedCaseId.value == caseId) {
                    _selectedCaseId.value = null
                }
                onComplete(true, "Case $caseId permanently deleted from the system.")
            } catch (e: Exception) {
                onComplete(false, "Failed to delete case: ${e.message}")
            }
        }
    }

    fun updateCase(caseEntity: CaseEntity, onComplete: (Boolean, String) -> Unit = { _, _ -> }) {
        val user = _currentUser.value
        val isAdmin = user?.role in listOf("ADMIN", "DIRECTOR") || _currentRole.value in listOf(UserRole.ADMIN, UserRole.DIRECTOR)
        if (!isAdmin) {
            onComplete(false, "Access Denied: Only Administrator has authority to modify case parameters.")
            return
        }
        viewModelScope.launch {
            try {
                repository.updateCase(caseEntity)
                onComplete(true, "Case ${caseEntity.caseId} updated successfully.")
            } catch (e: Exception) {
                onComplete(false, "Failed to update case: ${e.message}")
            }
        }
    }

    fun deletePayment(paymentId: Long, onComplete: (Boolean, String) -> Unit = { _, _ -> }) {
        val user = _currentUser.value
        val isAdmin = user?.role in listOf("ADMIN", "DIRECTOR") || _currentRole.value in listOf(UserRole.ADMIN, UserRole.DIRECTOR)
        if (!isAdmin) {
            onComplete(false, "Access Denied: Only Administrator has authority to reverse payments.")
            return
        }
        viewModelScope.launch {
            try {
                repository.deletePayment(paymentId)
                onComplete(true, "Payment #$paymentId reversed/deleted from ledger.")
            } catch (e: Exception) {
                onComplete(false, "Failed to delete payment: ${e.message}")
            }
        }
    }

    fun changeUserPassword(targetUserId: String, newPass: String, onComplete: (Boolean, String) -> Unit) {
        val user = _currentUser.value
        val isAdmin = user?.role in listOf("ADMIN", "DIRECTOR") || _currentRole.value in listOf(UserRole.ADMIN, UserRole.DIRECTOR)
        if (!isAdmin) {
            onComplete(false, "Access Denied: Only Administrator has authority to change passwords.")
            return
        }
        if (newPass.trim().length < 3) {
            onComplete(false, "New password must be at least 3 characters.")
            return
        }
        viewModelScope.launch {
            repository.updateUserPassword(targetUserId, newPass.trim())
            onComplete(true, "Password updated successfully.")
        }
    }

    fun reassignCase(caseId: String, newOfficerId: String, newOfficerName: String, reason: String, onComplete: () -> Unit = {}) {
        val managerName = _currentUser.value?.fullName ?: "Manager Patrick Mukwaya"
        viewModelScope.launch {
            repository.reassignCase(caseId, newOfficerId, newOfficerName, managerName, reason)
            onComplete()
        }
    }

    fun reconcilePayment(paymentId: Long, verified: Boolean) {
        viewModelScope.launch {
            repository.updatePaymentVerification(paymentId, verified)
            if (verified) {
                // Look up payment and case to send Credit Confirmation SMS
                val payment = allPayments.value.firstOrNull { it.id == paymentId }
                if (payment != null) {
                    val caseItem = allCases.value.firstOrNull { it.caseId == payment.caseId }
                    val creditorName = caseItem?.creditorName ?: "Stanbic Bank Uganda Ltd"
                    val creditorPhone = "+256 312 224 000"
                    smsService.sendCreditSms(
                        creditorName = creditorName,
                        creditorPhone = creditorPhone,
                        amount = payment.amount,
                        receiptNo = payment.receiptNumber,
                        caseId = payment.caseId
                    )
                }
            }
        }
    }

    fun addNewUser(user: UserEntity, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            repository.insertUser(user)
            onComplete(true, "User ${user.fullName} created successfully.")
        }
    }

    fun deleteUser(userId: String, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            repository.deleteUser(userId)
            onComplete(true, "User deleted successfully.")
        }
    }

    fun makeDebtorPayment(caseId: String, amount: Double, channel: String, phone: String, onComplete: (String) -> Unit) {
        val receiptNumber = "REC-2026-${(1000..9999).random()}"
        val debtorName = _currentUser.value?.fullName ?: "Mukasa Godfrey Kasule"
        viewModelScope.launch {
            repository.recordPayment(
                caseId = caseId,
                amount = amount,
                channel = channel,
                receiptNumber = receiptNumber,
                officerName = "$debtorName (Self-Pay)",
                notes = "Debtor self-service payment via $channel ($phone). Instant balance reconciliation applied."
            )
            val caseItem = allCases.value.firstOrNull { it.caseId == caseId }
            if (caseItem != null) {
                smsService.sendPaymentConfirmationSms(caseItem, amount, receiptNumber, channel)
            }
            onComplete(receiptNumber)
        }
    }

    fun authorizeCompanyPayment(caseId: String, amount: Double, channel: String, companyName: String, onComplete: (String) -> Unit) {
        val receiptNumber = "REC-CMP-${(1000..9999).random()}"
        viewModelScope.launch {
            repository.recordPayment(
                caseId = caseId,
                amount = amount,
                channel = channel,
                receiptNumber = receiptNumber,
                officerName = "$companyName (Company Settlement)",
                notes = "Direct corporate payment authorization by $companyName via $channel. Ledger clearing applied."
            )
            val caseItem = allCases.value.firstOrNull { it.caseId == caseId }
            if (caseItem != null) {
                smsService.sendPaymentConfirmationSms(caseItem, amount, receiptNumber, channel)
                smsService.sendCreditSms(
                    creditorName = companyName,
                    creditorPhone = "+256 312 224 000",
                    amount = amount,
                    receiptNo = receiptNumber,
                    caseId = caseId
                )
            }
            onComplete(receiptNumber)
        }
    }

    fun authoriseIndividualPayment(caseId: String, amount: Double, channel: String, phone: String, onComplete: (String) -> Unit) {
        makeDebtorPayment(caseId, amount, channel, phone, onComplete)
    }

    fun authoriseCompanyPayment(caseId: String, amount: Double, channel: String, companyName: String, onComplete: (String) -> Unit) {
        authorizeCompanyPayment(caseId, amount, channel, companyName, onComplete)
    }

    private fun mapRoleStringToEnum(roleStr: String): UserRole {
        return when (roleStr.uppercase()) {
            "ADMIN" -> UserRole.ADMIN
            "DIRECTOR" -> UserRole.DIRECTOR
            "COLLECTION_MANAGER" -> UserRole.COLLECTION_MANAGER
            "COLLECTION_OFFICER" -> UserRole.COLLECTION_OFFICER
            "LEGAL_OFFICER" -> UserRole.LEGAL_OFFICER
            "FINANCE_OFFICER" -> UserRole.FINANCE_OFFICER
            "CLIENT", "CLIENT_PORTAL", "COMPANY" -> UserRole.CLIENT_PORTAL
            "DEBTOR", "DEBTOR_PORTAL", "INDIVIDUAL" -> UserRole.DEBTOR_PORTAL
            else -> UserRole.ADMIN
        }
    }

    fun navigateTo(screen: NavigationScreen) {
        _currentScreen.value = screen
        when (screen) {
            NavigationScreen.MANAGER_SUPERVISION -> _collectionManagerTab.value = 0
            NavigationScreen.MANAGER_ALLOCATION -> _collectionManagerTab.value = 1
            else -> {}
        }
    }

    fun setCollectionManagerTab(tab: Int) {
        _collectionManagerTab.value = tab
    }

    fun setFinanceOfficerTab(tab: Int) {
        _financeOfficerTab.value = tab
    }

    fun setDebtorPortalTab(tab: Int) {
        _debtorPortalTab.value = tab
    }

    fun setClientPortalTab(tab: Int) {
        _clientPortalTab.value = tab
    }

    fun setPlatformMode(mode: PlatformMode) {
        _platformMode.value = mode
    }

    fun selectCase(caseId: String) {
        _selectedCaseId.value = caseId
        _currentScreen.value = NavigationScreen.CASE_DETAIL
    }

    fun clearSelectedCase() {
        _selectedCaseId.value = null
        _currentScreen.value = NavigationScreen.CASES
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setStatusFilter(filter: String) {
        _selectedStatusFilter.value = filter
    }

    fun setAgeingFilter(filter: String) {
        _selectedAgeingFilter.value = filter
    }

    fun logCall(caseId: String, title: String, notes: String, acknowledged: Boolean) {
        viewModelScope.launch {
            val officer = when (_currentRole.value) {
                UserRole.COLLECTION_OFFICER -> "Officer David Ochieng"
                UserRole.LEGAL_OFFICER -> "Counsel Grace Achan"
                else -> "Collection Officer"
            }
            repository.logCall(caseId, officer, title, notes, acknowledged)
        }
    }

    fun recordPayment(caseId: String, amount: Double, channel: String, receipt: String, notes: String) {
        viewModelScope.launch {
            val officer = "Finance Officer Sarah Namubiru"
            repository.recordPayment(caseId, amount, channel, receipt, officer, notes)
            val payment = PaymentTransactionEntity(
                caseId = caseId,
                amount = amount,
                paymentDate = System.currentTimeMillis(),
                receiptNumber = receipt,
                paymentChannel = channel,
                recordedBy = officer,
                notes = notes,
                verified = true
            )
            firebaseService?.pushPaymentRecord(payment)

            val caseItem = allCases.value.firstOrNull { it.caseId == caseId }
            if (caseItem != null) {
                // Send Payment Confirmation SMS to Debtor
                smsService.sendPaymentConfirmationSms(caseItem, amount, receipt, channel)
                // Send Credit Confirmation SMS to Creditor
                smsService.sendCreditSms(
                    creditorName = caseItem.creditorName,
                    creditorPhone = "+256 312 224 000",
                    amount = amount,
                    receiptNo = receipt,
                    caseId = caseId
                )
            }
        }
    }

    fun recordPromise(
        caseId: String,
        debtorName: String,
        amount: Double,
        date: String,
        method: String,
        notes: String
    ) {
        viewModelScope.launch {
            val officer = when (_currentRole.value) {
                UserRole.COLLECTION_OFFICER -> "Officer David Ochieng"
                else -> "Collection Officer"
            }
            val ptp = PromiseToPayEntity(
                caseId = caseId,
                debtorName = debtorName,
                promisedAmount = amount,
                promiseDate = date,
                paymentMethod = method,
                status = "PENDING",
                notes = notes,
                officerName = officer
            )
            repository.recordPromise(ptp)
        }
    }

    fun markPromiseDefaulted(promise: PromiseToPayEntity, reason: String) {
        viewModelScope.launch {
            val officer = "VML Audit Engine"
            repository.updatePromiseStatus(
                promiseId = promise.id,
                newStatus = "DEFAULTED",
                caseId = promise.caseId,
                officerName = officer,
                notes = "PROMISE DEFAULTED: Promised UGX ${formatCurrency(promise.promisedAmount)} on ${promise.promiseDate}. Received UGX 0. Reason: $reason. Action required."
            )
        }
    }

    fun markPromiseFulfilled(promise: PromiseToPayEntity) {
        viewModelScope.launch {
            val officer = "Finance Officer"
            repository.updatePromiseStatus(
                promiseId = promise.id,
                newStatus = "FULFILLED",
                caseId = promise.caseId,
                officerName = officer,
                notes = "Promise fulfilled in full. UGX ${formatCurrency(promise.promisedAmount)} confirmed."
            )
        }
    }

    fun escalateLegalStage(caseId: String, nextStage: String, notes: String) {
        viewModelScope.launch {
            val officer = when (_currentRole.value) {
                UserRole.LEGAL_OFFICER -> "Counsel Grace Achan (VML Legal)"
                else -> "Legal Escalation Board"
            }
            repository.updateLegalStage(caseId, nextStage, officer, notes)
        }
    }

    fun scheduleFieldVisit(caseId: String, debtorName: String, address: String, scheduledTime: String, outcome: String) {
        viewModelScope.launch {
            val visit = FieldVisitEntity(
                caseId = caseId,
                debtorName = debtorName,
                address = address,
                officerName = "Officer David Ochieng",
                scheduledDate = scheduledTime,
                status = "SCHEDULED",
                outcome = outcome,
                nextAction = "Physical delivery of notice & verification of active trading"
            )
            repository.recordFieldVisit(visit)
        }
    }

    fun completeFieldVisit(visit: FieldVisitEntity, outcome: String, nextAction: String) {
        viewModelScope.launch {
            repository.completeFieldVisit(visit, outcome, nextAction)
        }
    }

    fun generateLegalDocument(caseId: String, docType: String, title: String, content: String) {
        viewModelScope.launch {
            val df = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val doc = LegalDocumentEntity(
                caseId = caseId,
                docType = docType,
                title = title,
                courtReference = "VML/LEG/2026/" + (100..999).random(),
                assignedAdvocate = "Counsel Grace Achan (VML Legal Chambers)",
                status = "ISSUED",
                generatedDate = df.format(Date()),
                contentSummary = content
            )
            repository.generateLegalDoc(doc)
        }
    }

    fun createPaymentPlan(
        caseId: String,
        debtorName: String,
        totalAmount: Double,
        instalments: Int,
        frequency: String,
        startDate: String
    ) {
        viewModelScope.launch {
            val perInstalment = totalAmount / instalments
            val list = mutableListOf<String>()
            for (i in 1..instalments) {
                list.add("""{"date":"Instalment #$i ($frequency)", "amount":$perInstalment, "status":"PENDING"}""")
            }
            val json = "[${list.joinToString(",")}]"
            val plan = PaymentPlanEntity(
                caseId = caseId,
                debtorName = debtorName,
                totalAgreedAmount = totalAmount,
                numberOfInstalments = instalments,
                frequency = frequency,
                startDate = startDate,
                status = "ACTIVE",
                instalmentsJson = json
            )
            repository.createPaymentPlan(plan)
        }
    }

    fun registerNewCase(
        debtorName: String,
        debtorId: String,
        phone: String,
        email: String,
        address: String,
        employer: String,
        creditorName: String,
        creditorAcc: String,
        agreementRef: String,
        principal: Double,
        interest: Double,
        penalties: Double,
        officer: String,
        debtorType: String = "INDIVIDUAL",
        sector: String = "Trade & Retail"
    ) {
        val cleanName = debtorName.trim()
        val cleanId = debtorId.trim()
        val cleanPhone = FormValidators.normalizeUgandaPhone(phone)
        val cleanEmail = email.trim()
        val cleanAddress = address.trim()
        val cleanEmployer = employer.trim()
        val cleanCreditor = creditorName.trim()
        val cleanAcc = creditorAcc.trim()
        val cleanRef = agreementRef.trim()

        // Strict Backend Validation
        if (cleanName.isBlank() || cleanId.isBlank() || cleanPhone.isBlank() ||
            cleanEmail.isBlank() || cleanAddress.isBlank() || cleanEmployer.isBlank() ||
            cleanCreditor.isBlank() || cleanAcc.isBlank() || cleanRef.isBlank() ||
            principal <= 0.0 || interest < 0.0 || penalties < 0.0
        ) {
            // Reject invalid or incomplete records from being saved
            return
        }

        viewModelScope.launch {
            val caseId = "VML-2026-" + (10000..99999).random().toString().take(5)
            val determinedType = if (cleanId.startsWith("CM", ignoreCase = true) || cleanId.startsWith("CF", ignoreCase = true)) {
                "INDIVIDUAL"
            } else if (cleanName.contains("Ltd", ignoreCase = true) || cleanName.contains("PLC", ignoreCase = true) || cleanName.contains("Company", ignoreCase = true) || cleanName.contains("Enterprises", ignoreCase = true)) {
                "COMPANY"
            } else {
                debtorType
            }

            val newCase = CaseEntity(
                caseId = caseId,
                debtorName = cleanName,
                debtorNationalId = cleanId,
                debtorPhone = cleanPhone,
                debtorEmail = cleanEmail,
                debtorAddress = cleanAddress,
                debtorEmployer = cleanEmployer,
                debtorEmergencyContact = "Next of Kin (+256 700 000 000)",
                creditorName = cleanCreditor,
                creditorAccountNumber = cleanAcc,
                originalAgreementRef = cleanRef,
                supportingDocsNote = "Original Credit Agreement & Guarantor Affidavit",
                principalAmount = principal,
                interestAmount = interest,
                penaltiesAmount = penalties,
                amountPaid = 0.0,
                dateDebtArose = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                dueDate = "2026-12-31",
                assignedOfficerId = "OFF-001",
                assignedOfficerName = officer,
                status = "ACTIVE",
                legalStage = "COLLECTION",
                ageingCategory = "0-30 days",
                riskLevel = "MEDIUM",
                debtorType = determinedType,
                sectorOfWork = sector
            )
            repository.insertCase(newCase)
            firebaseService?.pushCaseUpdate(newCase)
            repository.insertAuditLog(
                AuditLogEntity(
                    action = "CASE_INSTRUCTED",
                    actorUserId = currentUser.value?.userId ?: "ADMIN",
                    actorRole = currentUser.value?.role ?: "OFFICER",
                    targetEntity = "Case",
                    targetId = caseId,
                    details = "New debt claim of UGX ${principal.toLong()} registered for debtor $cleanName by creditor $cleanCreditor.",
                    timestamp = System.currentTimeMillis(),
                    ipOrDevice = "Android Client"
                )
            )
            smsService.sendNewDebtSms(newCase)
            selectCase(caseId)
        }
    }

    fun generateAiRecoveryBriefing(caseItem: CaseEntity, mode: AiBriefingMode): String {
        return when (mode) {
            AiBriefingMode.CASE_SUMMARY -> """
                [AI EXECUTIVE RECOVERY SUMMARY: ${caseItem.caseId}]
                
                • Debtor: ${caseItem.debtorName} (${caseItem.debtorEmployer})
                • Creditor: ${caseItem.creditorName} (Ref: ${caseItem.originalAgreementRef})
                • Financial Position: Total Claim UGX ${formatCurrency(caseItem.totalDebt)}, Paid UGX ${formatCurrency(caseItem.amountPaid)}, Outstanding UGX ${formatCurrency(caseItem.outstandingBalance)} (${String.format("%.1f", caseItem.recoveryPercentage)}% recovered).
                • Current Legal Stage: ${caseItem.legalStage} (${caseItem.ageingCategory} overdue).
                • Evidence Trail Status: Initial credit documentation verified; formal acknowledgment logged.
                • Recommended Action: Given ${caseItem.riskLevel} risk level and current stage (${caseItem.legalStage}), enforce statutory 7-day demand with structured 3-month payment plan standstill, or escalate immediately to High Court Commercial Division plaint.
            """.trimIndent()

            AiBriefingMode.CALL_BRIEFING -> """
                [AI PRE-CALL BRIEFING FOR OFFICER: ${caseItem.debtorName}]
                
                • Verified Contact: ${caseItem.debtorPhone}
                • Goal: Secure irrevocable Promise to Pay (PTP) for at least 25% of balance (UGX ${formatCurrency(caseItem.outstandingBalance * 0.25)}).
                • Leverage Points: Registered security (${caseItem.supportingDocsNote}). Inform debtor that Virgin Markets Multi Legal operates under Ugandan Commercial Recovery directives.
                • Talking Points:
                  1. "Mr./Ms. ${caseItem.debtorName}, I am calling from Virgin Markets Multi Legal regarding your outstanding facility with ${caseItem.creditorName}."
                  2. "The current liquidated sum due is UGX ${formatCurrency(caseItem.outstandingBalance)}."
                  3. "We are prepared to structure an approved instalment schedule, provided the first commitment fee is paid within 48 hours to avert court filing."
                • Fair Practices Note: Maintain professional, polite, firm tone. No harassment; record all timestamps.
            """.trimIndent()

            AiBriefingMode.LEGAL_DEMAND_DRAFT -> """
                VIRGIN MARKETS MULTI LEGAL
                ADVOCATES, DEBT RECOVERY & COMMISSIONERS FOR OATHS
                Plot 12 Lumumba Avenue, Kampala, Uganda
                
                FORMAL NOTICE OF INTENTION TO SUE & STATUTORY DEMAND
                
                Date: ${SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date())}
                Our Ref: VML/DEM/${caseItem.caseId}
                
                TO: ${caseItem.debtorName}
                Address: ${caseItem.debtorAddress}
                
                RE: UNPAID CREDIT FACILITY OF UGX ${formatCurrency(caseItem.outstandingBalance)} DUE TO ${caseItem.creditorName.uppercase()}
                
                TAKE NOTICE that we act for and on behalf of ${caseItem.creditorName} ("our Client").
                
                Under the facility agreement dated ${caseItem.dateDebtArose} (Ref: ${caseItem.originalAgreementRef}), you covenanted to liquidate your indebtedness. Despite repeated reminders, you remain in default of the sum of UGX ${formatCurrency(caseItem.outstandingBalance)} comprising Principal, Interest, and lawful Recovery Costs.
                
                DEMAND IS HEREBY MADE that you pay the full amount of UGX ${formatCurrency(caseItem.outstandingBalance)} to Virgin Markets Multi Legal designated client account within SEVEN (7) DAYS from the date hereof.
                
                TAKE FURTHER NOTICE that upon default, our instructions are to institute summary recovery proceedings in the High Court of Uganda (Commercial Division) without further notice, at your sole peril as to 24% p.a. commercial interest and full advocate-client costs.
                
                Yours faithfully,
                VIRGIN MARKETS MULTI LEGAL CHAMBERS
            """.trimIndent()

            AiBriefingMode.NEGOTIATION_STRATEGY -> """
                [AI RECOVERY STRATEGY & SETTLEMENT GUIDANCE]
                
                • Optimal Repayment Plan: 4 instalments of UGX ${formatCurrency(caseItem.outstandingBalance / 4)} over 60 days.
                • Penalty Waiver Concession: Up to 50% of penalties (UGX ${formatCurrency(caseItem.penaltiesAmount * 0.5)}) can be conditionally waived IF 30% down-payment is wired immediately.
                • Security Verification: Ensure the registered lien on ${caseItem.supportingDocsNote} is legally unencumbered before signing any standstill.
            """.trimIndent()
        }
    }

    private fun formatCurrency(amount: Double): String {
        return if (amount >= 1_000_000_000) {
            String.format(Locale.US, "%.2fB", amount / 1_000_000_000.0)
        } else if (amount >= 1_000_000) {
            String.format(Locale.US, "%.1fM", amount / 1_000_000.0)
        } else {
            String.format(Locale.US, "%,.0f", amount)
        }
    }
}

class VmlViewModelFactory(
    private val repository: VmlRepository,
    private val smsService: SmsNotificationService,
    private val firebaseService: FirebaseRealtimeDbService? = null
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(VmlViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return VmlViewModel(repository, smsService, firebaseService) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
