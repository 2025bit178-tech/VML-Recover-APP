package com.example.repository

import com.example.data.AppDatabase
import com.example.data.SampleDataProvider
import com.example.data.model.AuditLogEntity

import com.example.data.model.CaseEntity
import com.example.data.model.FieldVisitEntity
import com.example.data.model.LegalDocumentEntity
import com.example.data.model.PaymentPlanEntity
import com.example.data.model.PaymentTransactionEntity
import com.example.data.model.PromiseToPayEntity
import com.example.data.model.SmsNotificationEntity
import com.example.data.model.SystemConfigEntity
import com.example.data.model.TimelineActionEntity
import com.example.data.model.UserEntity
import kotlinx.coroutines.flow.Flow

class VmlRepository(private val database: AppDatabase) {

    val allCases: Flow<List<CaseEntity>> = database.caseDao().getAllCasesFlow()
    val allTimeline: Flow<List<TimelineActionEntity>> = database.timelineDao().getAllRecentTimeline()
    val allPromises: Flow<List<PromiseToPayEntity>> = database.promiseDao().getAllPromisesFlow()
    val allPayments: Flow<List<PaymentTransactionEntity>> = database.paymentDao().getAllPaymentsFlow()
    val allVisits: Flow<List<FieldVisitEntity>> = database.fieldVisitDao().getAllVisitsFlow()
    val allLegalDocs: Flow<List<LegalDocumentEntity>> = database.legalDocDao().getAllDocumentsFlow()
    val allPlans: Flow<List<PaymentPlanEntity>> = database.paymentPlanDao().getAllPlans()
    val allUsers: Flow<List<UserEntity>> = database.userDao().getAllUsersFlow()
    val allLockedUsers: Flow<List<UserEntity>> = database.userDao().getLockedUsers()
    val allSmsNotifications: Flow<List<SmsNotificationEntity>> = database.smsNotificationDao().getAllSmsFlow()
    val systemConfig: Flow<SystemConfigEntity?> = database.systemConfigDao().getConfigFlow()
    val allAuditLogs: Flow<List<AuditLogEntity>> = database.auditLogDao().getRecentAuditLogsFlow(250)

    suspend fun insertAuditLog(log: AuditLogEntity) {
        database.auditLogDao().insertLog(log)
    }

    suspend fun authenticateUser(identifier: String, password: String): UserEntity? {
        val user = database.userDao().authenticate(identifier.trim(), password.trim())
        if (user != null) {
            database.userDao().recordSuccessfulLogin(user.userId, System.currentTimeMillis())
        }
        return user
    }

    suspend fun updateLastLogin(userId: String) {
        database.userDao().updateLastLogin(userId, System.currentTimeMillis())
    }

    suspend fun getUserByEmail(email: String): UserEntity? =
        database.userDao().getUserByEmail(email.trim())

    suspend fun updateUserPassword(userId: String, newPass: String) {
        database.userDao().updatePassword(userId, newPass)
    }

    fun getCaseById(caseId: String): Flow<CaseEntity?> = database.caseDao().getCaseByIdFlow(caseId)

    fun getTimelineForCase(caseId: String): Flow<List<TimelineActionEntity>> =
        database.timelineDao().getTimelineForCaseFlow(caseId)

    fun getPromisesForCase(caseId: String): Flow<List<PromiseToPayEntity>> =
        database.promiseDao().getPromisesForCaseFlow(caseId)

    fun getPaymentsForCase(caseId: String): Flow<List<PaymentTransactionEntity>> =
        database.paymentDao().getPaymentsForCaseFlow(caseId)

    fun getPlansForCase(caseId: String): Flow<List<PaymentPlanEntity>> =
        database.paymentPlanDao().getPlansForCase(caseId)

    fun getVisitsForCase(caseId: String): Flow<List<FieldVisitEntity>> =
        database.fieldVisitDao().getVisitsForCaseFlow(caseId)

    fun getDocumentsForCase(caseId: String): Flow<List<LegalDocumentEntity>> =
        database.legalDocDao().getDocumentsForCaseFlow(caseId)

    suspend fun insertCase(caseEntity: CaseEntity) {
        database.caseDao().insertCase(caseEntity)
        database.timelineDao().insertAction(
            TimelineActionEntity(
                caseId = caseEntity.caseId,
                officerName = caseEntity.assignedOfficerName,
                actionType = "CASE_CREATED",
                title = "Case Registered with VML Recover",
                description = "Account ${caseEntity.debtorName} assigned from ${caseEntity.creditorName} for claimed debt UGX ${formatUgx(caseEntity.totalDebt)}.",
                amount = caseEntity.principalAmount
            )
        )
    }

    suspend fun logCall(caseId: String, callerName: String, callTitle: String, callNotes: String, acknowledged: Boolean) {
        database.timelineDao().insertAction(
            TimelineActionEntity(
                caseId = caseId,
                officerName = callerName,
                actionType = "CALL",
                title = callTitle,
                description = "$callNotes. Debtor acknowledged obligation: ${if (acknowledged) "YES" else "DISPUTED"}.",
                tag = if (acknowledged) "ACKNOWLEDGED" else "DISPUTED"
            )
        )
    }

    suspend fun updateLegalStage(caseId: String, newStage: String, officerName: String, reason: String) {
        database.caseDao().updateLegalStage(caseId, newStage)
        database.timelineDao().insertAction(
            TimelineActionEntity(
                caseId = caseId,
                officerName = officerName,
                actionType = "LEGAL_ESCALATION",
                title = "Stage Escalated to: $newStage",
                description = "Advocate action: $reason. Fair debt collection notice generated.",
                tag = newStage
            )
        )
    }

    suspend fun recordPayment(
        caseId: String,
        amount: Double,
        channel: String,
        receiptNumber: String,
        notes: String,
        officerName: String
    ) {
        val payment = PaymentTransactionEntity(
            caseId = caseId,
            amount = amount,
            receiptNumber = receiptNumber,
            receiptNo = receiptNumber,
            paymentChannel = channel,
            recordedBy = officerName,
            notes = notes
        )
        database.paymentDao().insertPayment(payment)
        database.caseDao().incrementAmountPaid(caseId, amount)

        // Check if case is now fully settled
        val currentCase = database.caseDao().getCaseDirect(caseId)
        if (currentCase != null && currentCase.outstandingBalance <= 0) {
            database.caseDao().updateCaseStatus(caseId, "CLOSED")
            database.caseDao().updateLegalStage(caseId, "CLOSURE")
        }

        database.timelineDao().insertAction(
            TimelineActionEntity(
                caseId = caseId,
                officerName = officerName,
                actionType = "PAYMENT_RECEIVED",
                title = "Payment received: UGX ${formatUgx(amount)}",
                description = "Receipt $receiptNumber via $channel. $notes",
                amount = amount,
                tag = receiptNumber
            )
        )
    }

    suspend fun recordPromise(promise: PromiseToPayEntity) {
        database.promiseDao().insertPromise(promise)
        database.timelineDao().insertAction(
            TimelineActionEntity(
                caseId = promise.caseId,
                officerName = promise.officerName,
                actionType = "PROMISE_MADE",
                title = "Promise to pay UGX ${formatUgx(promise.promisedAmount)} on ${promise.promiseDate}",
                description = "Agreed payment method: ${promise.paymentMethod}. ${promise.notes}",
                amount = promise.promisedAmount
            )
        )
    }

    suspend fun updatePromiseStatus(promiseId: Long, newStatus: String, caseId: String, officerName: String, notes: String) {
        database.promiseDao().updatePromiseStatus(promiseId, newStatus)
        database.timelineDao().insertAction(
            TimelineActionEntity(
                caseId = caseId,
                officerName = officerName,
                actionType = if (newStatus == "DEFAULTED") "NOTE" else "PAYMENT_RECEIVED",
                title = if (newStatus == "DEFAULTED") "PROMISE DEFAULTED" else "Promise Marked: $newStatus",
                description = notes,
                tag = if (newStatus == "DEFAULTED") "DEFAULTED" else newStatus
            )
        )
        if (newStatus == "DEFAULTED") {
            database.caseDao().updateCaseStatus(caseId, "CRITICAL")
        }
    }

    suspend fun createPaymentPlan(plan: PaymentPlanEntity) {
        database.paymentPlanDao().insertPlan(plan)
        database.timelineDao().insertAction(
            TimelineActionEntity(
                caseId = plan.caseId,
                officerName = "Collection Officer",
                actionType = "NOTE",
                title = "Repayment Plan Structured (${plan.numberOfInstalments} Instalments)",
                description = "Total agreed sum of UGX ${formatUgx(plan.totalAgreedAmount)} payable on a ${plan.frequency} basis starting ${plan.startDate}."
            )
        )
    }

    suspend fun recordFieldVisit(visit: FieldVisitEntity) {
        database.fieldVisitDao().insertVisit(visit)
        database.timelineDao().insertAction(
            TimelineActionEntity(
                caseId = visit.caseId,
                officerName = visit.officerName,
                actionType = "VISIT",
                title = "Field Visit Scheduled: ${visit.address}",
                description = "Purpose: ${visit.outcome}"
            )
        )
    }

    suspend fun completeFieldVisit(visit: FieldVisitEntity, outcome: String, nextAction: String) {
        val updated = visit.copy(
            status = "COMPLETED",
            outcome = outcome,
            nextAction = nextAction,
            checkedInAt = System.currentTimeMillis()
        )
        database.fieldVisitDao().updateVisit(updated)
        database.timelineDao().insertAction(
            TimelineActionEntity(
                caseId = visit.caseId,
                officerName = visit.officerName,
                actionType = "VISIT",
                title = "Field Visit Completed: ${visit.debtorName}",
                description = "Outcome: $outcome. Next Action: $nextAction. Fair collection compliance verified."
            )
        )
    }

    suspend fun generateLegalDoc(doc: LegalDocumentEntity) {
        database.legalDocDao().insertDoc(doc)
        database.timelineDao().insertAction(
            TimelineActionEntity(
                caseId = doc.caseId,
                officerName = doc.assignedAdvocate,
                actionType = "DEMAND_LETTER",
                title = "Legal Document Generated: ${doc.title}",
                description = doc.contentSummary,
                tag = doc.courtReference
            )
        )
    }

    suspend fun reassignCase(caseId: String, newOfficerId: String, newOfficerName: String, managerName: String, reason: String) {
        database.caseDao().reassignOfficer(caseId, newOfficerId, newOfficerName)
        database.timelineDao().insertAction(
            TimelineActionEntity(
                caseId = caseId,
                officerName = managerName,
                actionType = "NOTE",
                title = "Case Reallocated to: $newOfficerName",
                description = "Managerial reallocation by $managerName. Reason: $reason",
                tag = "ALLOCATION"
            )
        )
    }

    suspend fun updatePaymentVerification(paymentId: Long, verified: Boolean) {
        database.paymentDao().updatePaymentVerification(paymentId, verified)
    }

    suspend fun insertUser(user: UserEntity) {
        database.userDao().insertUser(user)
    }

    suspend fun updateUser(user: UserEntity) {
        database.userDao().updateUser(user)
    }

    suspend fun getUserById(userId: String): UserEntity? {
        return database.userDao().getUserById(userId)
    }

    suspend fun ensureSeedData() {
        val existingAdmin = database.userDao().getUserById("USR-001")
        if (existingAdmin == null) {
            SampleDataProvider.populateInitialData(database)
        }
    }

    suspend fun findUserByIdentifier(identifier: String): UserEntity? {
        val clean = identifier.trim()
        val direct = database.userDao().findByIdentifier(clean)
        if (direct != null) return direct

        // Flexible matching for client login variations
        if (clean.equals("client@stanbic.co.ug", ignoreCase = true) ||
            clean.equals("client@stanbic.co", ignoreCase = true) ||
            clean.equals("client", ignoreCase = true)
        ) {
            return database.userDao().getUserByEmail("client@stanbic.co.ug")
                ?: database.userDao().getUserByEmail("client@stanbic.co")
                ?: database.userDao().getUserById("USR-007")
        }

        // Flexible matching for admin login variations
        if (clean.equals("admin", ignoreCase = true) || clean.equals("administrator", ignoreCase = true)) {
            return database.userDao().getUserByEmail("admin@vmlrecover.ug")
                ?: database.userDao().getUserById("USR-001")
        }

        if (clean.equals("director", ignoreCase = true)) {
            return database.userDao().getUserByEmail("director@vmlrecover.ug")
                ?: database.userDao().getUserById("USR-002")
        }

        if (clean.equals("manager", ignoreCase = true)) {
            return database.userDao().getUserByEmail("manager@vmlrecover.ug")
                ?: database.userDao().getUserById("USR-003")
        }

        if (clean.equals("collector", ignoreCase = true) || clean.equals("officer", ignoreCase = true)) {
            return database.userDao().getUserByEmail("collector@vmlrecover.ug")
                ?: database.userDao().getUserById("USR-004")
        }

        if (clean.equals("legal", ignoreCase = true)) {
            return database.userDao().getUserByEmail("legal@vmlrecover.ug")
                ?: database.userDao().getUserById("USR-005")
        }

        if (clean.equals("finance", ignoreCase = true)) {
            return database.userDao().getUserByEmail("finance@vmlrecover.ug")
                ?: database.userDao().getUserById("USR-006")
        }

        return database.userDao().getUserByEmail(clean.lowercase())
    }

    suspend fun unlockAllUsers() {
        database.userDao().unlockAllUsers()
    }

    suspend fun unlockUser(userId: String) {
        database.userDao().unlockUser(userId)
    }

    suspend fun lockUser(userId: String, reason: String) {
        database.userDao().lockUser(userId, reason, System.currentTimeMillis())
    }

    suspend fun updateFailedAttempts(userId: String, attempts: Int) {
        database.userDao().updateFailedAttempts(userId, attempts)
    }

    suspend fun deleteUser(userId: String) {
        database.userDao().deleteUser(userId)
    }

    suspend fun getDirectSystemConfig(): SystemConfigEntity? {
        return database.systemConfigDao().getDirectConfig()
    }

    suspend fun updateSystemConfig(config: SystemConfigEntity) {
        database.systemConfigDao().insertOrUpdateConfig(config)
    }

    suspend fun clearAllSms() {
        database.smsNotificationDao().clearAllSms()
    }

    suspend fun deleteSms(id: Long) {
        database.smsNotificationDao().deleteSms(id)
    }

    suspend fun deleteCase(caseId: String) {
        database.caseDao().deleteCaseById(caseId)
        database.timelineDao().insertAction(
            TimelineActionEntity(
                caseId = caseId,
                officerName = "System Administrator",
                actionType = "SYSTEM_DELETION",
                title = "Case Expunged from Registry",
                description = "Case $caseId permanently removed from system database by Administrator."
            )
        )
    }

    suspend fun updateCase(caseEntity: CaseEntity) {
        database.caseDao().updateCase(caseEntity)
        database.timelineDao().insertAction(
            TimelineActionEntity(
                caseId = caseEntity.caseId,
                officerName = "System Administrator",
                actionType = "ADMIN_UPDATE",
                title = "Case Modified by Administrator",
                description = "Parameters and obligation balances updated in central registry."
            )
        )
    }

    suspend fun deletePayment(paymentId: Long) {
        database.paymentDao().deletePayment(paymentId)
    }

    private fun formatUgx(amount: Double): String {
        return if (amount >= 1_000_000_000) {
            String.format("%.2fB", amount / 1_000_000_000.0)
        } else if (amount >= 1_000_000) {
            String.format("%.1fM", amount / 1_000_000.0)
        } else {
            String.format("%,.0f", amount)
        }
    }
}
