package com.example.ui.components

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import com.example.data.model.AuditLogEntity
import com.example.data.model.CaseEntity
import com.example.data.model.LegalDocumentEntity
import com.example.data.model.PaymentTransactionEntity
import com.example.data.model.UserEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PrintUtils {

    fun printDocument(context: Context, docTitle: String, htmlContent: String) {
        try {
            val webView = WebView(context)
            webView.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
                    if (printManager != null && view != null) {
                        val printAdapter = view.createPrintDocumentAdapter(docTitle)
                        val printAttributes = PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setResolution(PrintAttributes.Resolution("id", "print", 300, 300))
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .build()
                        printManager.print(docTitle, printAdapter, printAttributes)
                    } else {
                        Toast.makeText(context, "Printing service unavailable on this device", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            webView.loadDataWithBaseURL(null, htmlContent, "text/html", "UTF-8", null)
        } catch (e: Exception) {
            Toast.makeText(context, "Print error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun generateLegalNoticeHtml(doc: LegalDocumentEntity, caseItem: CaseEntity?): String {
        val today = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date())
        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8"/>
                <style>
                    body { font-family: 'Times New Roman', serif; margin: 40px; color: #111; line-height: 1.6; }
                    .header { text-align: center; border-bottom: 2px solid #222; padding-bottom: 12px; margin-bottom: 24px; }
                    .header h1 { margin: 0; font-size: 20pt; text-transform: uppercase; letter-spacing: 2px; }
                    .header p { margin: 4px 0 0; font-size: 10pt; color: #555; }
                    .ref-box { display: flex; justify-content: space-between; margin-bottom: 20px; font-size: 11pt; font-weight: bold; }
                    .doc-title { text-align: center; font-size: 15pt; font-weight: bold; text-decoration: underline; margin: 24px 0 16px; text-transform: uppercase; }
                    .debtor-block { background: #f8f9fa; border: 1px solid #ddd; padding: 12px; margin-bottom: 20px; border-radius: 4px; }
                    .debtor-block h3 { margin: 0 0 8px; font-size: 12pt; }
                    .content { font-size: 11.5pt; text-align: justify; margin-bottom: 30px; }
                    .seal-section { margin-top: 40px; display: flex; justify-content: space-between; }
                    .signature-box { border-top: 1px solid #333; width: 220px; text-align: center; padding-top: 6px; font-size: 10pt; }
                    .stamp { border: 2px dashed #b91c1c; color: #b91c1c; padding: 8px 16px; display: inline-block; font-weight: bold; font-size: 11pt; text-transform: uppercase; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>VIRGIN MARKETS MULTI LEGAL</h1>
                    <p>Debt Recovery Specialists • Litigation Chambers • Kampala, Uganda</p>
                    <p>Official Statutory Notice Registry</p>
                </div>
                <div class="ref-box">
                    <div><strong>Case Ref:</strong> ${doc.caseId}</div>
                    <div><strong>Court Suit:</strong> ${doc.courtReference.ifBlank { "PENDING REGISTRATION" }}</div>
                    <div><strong>Date:</strong> $today</div>
                </div>
                <div class="doc-title">${doc.title}</div>
                <div class="debtor-block">
                    <h3>Debtor / Respondent Details</h3>
                    <div><strong>Name:</strong> ${caseItem?.debtorName ?: "Designated Respondent"}</div>
                    <div><strong>National ID / Reg No:</strong> ${caseItem?.debtorNationalId ?: "N/A"}</div>
                    <div><strong>Telephone:</strong> ${caseItem?.debtorPhone ?: "N/A"}</div>
                    <div><strong>Creditor Entity:</strong> ${caseItem?.creditorName ?: "Stanbic Bank Uganda Ltd"}</div>
                    <div><strong>Total Claim Amount:</strong> UGX ${String.format("%,.0f", caseItem?.totalDebt ?: 0.0)}</div>
                </div>
                <div class="content">
                    <p><strong>SUMMARY OF PROCEEDING / DEMAND:</strong></p>
                    <p>${doc.contentSummary}</p>
                    <p>TAKE NOTICE that upon service or issuance of this formal notice, failure to discharge the obligation or enter appearance within statutory timelines will immediately trigger attachment of movable/immovable assets, salary garnishee proceedings, or court decree enforcement without further indulgence.</p>
                </div>
                <div class="seal-section">
                    <div>
                        <span class="stamp">OFFICIAL REGISTRATION: ${doc.status}</span>
                        <div style="font-size: 9pt; color: #666; margin-top: 4px;">Advocate in Charge: ${doc.assignedAdvocate}</div>
                    </div>
                    <div class="signature-box">
                        <br/><br/>
                        <strong>Authorized Legal Signatory</strong><br/>
                        For VML Legal Chambers
                    </div>
                </div>
            </body>
            </html>
        """.trimIndent()
    }

    fun generateAccountStatementHtml(caseItem: CaseEntity, payments: List<PaymentTransactionEntity>): String {
        val today = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date())
        val paymentsRows = if (payments.isEmpty()) {
            "<tr><td colspan='4' style='text-align:center; padding:12px; color:#666;'>No payments receipted yet</td></tr>"
        } else {
            payments.joinToString("\n") { p ->
                val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(p.paymentDate))
                "<tr><td>$dateStr</td><td>${p.receiptNumber}</td><td>${p.paymentChannel}</td><td style='text-align:right; font-weight:bold;'>UGX ${String.format("%,.0f", p.amount)}</td></tr>"
            }
        }

        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8"/>
                <style>
                    body { font-family: 'Helvetica Neue', Arial, sans-serif; margin: 30px; color: #1e293b; line-height: 1.5; }
                    .header { display: flex; justify-content: space-between; border-bottom: 3px solid #1e3a8a; padding-bottom: 12px; margin-bottom: 20px; }
                    .header h1 { margin: 0; color: #1e3a8a; font-size: 18pt; }
                    .table-summary { width: 100%; border-collapse: collapse; margin-bottom: 24px; }
                    .table-summary td { padding: 8px 12px; border: 1px solid #cbd5e1; }
                    .table-summary td.label { background: #f1f5f9; font-weight: bold; width: 30%; }
                    .table-payments { width: 100%; border-collapse: collapse; margin-top: 12px; }
                    .table-payments th { background: #1e293b; color: white; padding: 8px; text-align: left; }
                    .table-payments td { padding: 8px; border-bottom: 1px solid #e2e8f0; font-size: 10pt; }
                    .badge { display: inline-block; padding: 4px 8px; border-radius: 4px; font-weight: bold; font-size: 9pt; background: #e0f2fe; color: #0369a1; }
                </style>
            </head>
            <body>
                <div class="header">
                    <div>
                        <h1>VML RECOVER</h1>
                        <div style="font-size: 10pt; color: #64748b;">Client & Debtor Portfolio Statement • Generated $today</div>
                    </div>
                    <div style="text-align:right;">
                        <span class="badge">${caseItem.status}</span>
                        <div style="font-size: 11pt; font-weight:bold; margin-top:4px;">${caseItem.caseId}</div>
                    </div>
                </div>
                <table class="table-summary">
                    <tr><td class="label">Debtor Entity</td><td><strong>${caseItem.debtorName}</strong> (${caseItem.debtorType})</td></tr>
                    <tr><td class="label">Creditor Institution</td><td>${caseItem.creditorName} (Acc: ${caseItem.creditorAccountNumber})</td></tr>
                    <tr><td class="label">Sector of Work</td><td>${caseItem.sectorOfWork}</td></tr>
                    <tr><td class="label">Legal Case Level</td><td>${caseItem.legalStage}</td></tr>
                    <tr><td class="label">Loan Ageing Tier</td><td>${caseItem.ageingCategory}</td></tr>
                    <tr><td class="label">Principal Amount</td><td>UGX ${String.format("%,.0f", caseItem.principalAmount)}</td></tr>
                    <tr><td class="label">Interest & Penalties</td><td>UGX ${String.format("%,.0f", caseItem.interestAmount + caseItem.penaltiesAmount)}</td></tr>
                    <tr><td class="label">Total Claimed Obligation</td><td><strong>UGX ${String.format("%,.0f", caseItem.totalDebt)}</strong></td></tr>
                    <tr><td class="label">Total Amount Paid</td><td style="color:#16a34a; font-weight:bold;">UGX ${String.format("%,.0f", caseItem.amountPaid)}</td></tr>
                    <tr><td class="label">Outstanding Balance</td><td style="color:#dc2626; font-size:12pt; font-weight:bold;">UGX ${String.format("%,.0f", caseItem.outstandingBalance)}</td></tr>
                </table>
                <h3>Payment Ledger History</h3>
                <table class="table-payments">
                    <thead><tr><th>Date</th><th>Receipt #</th><th>Channel</th><th style="text-align:right;">Amount</th></tr></thead>
                    <tbody>$paymentsRows</tbody>
                </table>
            </body>
            </html>
        """.trimIndent()
    }

    fun generateClientPortfolioReportHtml(clientName: String, clientCases: List<CaseEntity>): String {
        val today = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date())
        val totalPrincipal = clientCases.sumOf { it.principalAmount }
        val totalClaims = clientCases.sumOf { it.totalDebt }
        val totalRecovered = clientCases.sumOf { it.amountPaid }
        val totalOutstanding = (totalClaims - totalRecovered).coerceAtLeast(0.0)
        val rate = if (totalClaims > 0) (totalRecovered / totalClaims) * 100.0 else 0.0

        val casesRows = if (clientCases.isEmpty()) {
            "<tr><td colspan='6' style='text-align:center; padding:12px; color:#666;'>No debtors registered under this institution</td></tr>"
        } else {
            clientCases.joinToString("\n") { c ->
                "<tr><td><strong>${c.caseId}</strong></td><td>${c.debtorName}<br/><span style='font-size:8pt; color:#666;'>${c.debtorType} • ${c.sectorOfWork}</span></td><td>${c.legalStage}</td><td style='text-align:right;'>UGX ${String.format("%,.0f", c.totalDebt)}</td><td style='text-align:right; color:#16a34a;'>UGX ${String.format("%,.0f", c.amountPaid)}</td><td style='text-align:right; color:#dc2626; font-weight:bold;'>UGX ${String.format("%,.0f", c.outstandingBalance)}</td></tr>"
            }
        }

        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8"/>
                <style>
                    body { font-family: 'Helvetica Neue', Arial, sans-serif; margin: 30px; color: #0f172a; line-height: 1.4; }
                    .header { border-bottom: 2px solid #0f172a; padding-bottom: 10px; margin-bottom: 16px; display:flex; justify-content:space-between; align-items:flex-end; }
                    .stats { display: flex; gap: 16px; margin-bottom: 20px; }
                    .stat-box { flex: 1; background: #f8fafc; border: 1px solid #e2e8f0; padding: 12px; border-radius: 6px; }
                    .stat-box .title { font-size: 8pt; color: #64748b; font-weight: bold; text-transform: uppercase; }
                    .stat-box .val { font-size: 14pt; font-weight: bold; margin-top: 4px; }
                    table { width: 100%; border-collapse: collapse; font-size: 9.5pt; margin-top: 10px; }
                    th { background: #1e293b; color: white; padding: 8px; text-align: left; }
                    td { padding: 8px; border-bottom: 1px solid #e2e8f0; }
                </style>
            </head>
            <body>
                <div class="header">
                    <div>
                        <h1 style="margin:0; font-size:18pt; color:#1e3a8a;">CLIENT INSTITUTION RECOVERY AUDIT</h1>
                        <div style="font-size:11pt; font-weight:bold; color:#334155;">Client Entity: $clientName</div>
                    </div>
                    <div style="text-align:right; font-size:9pt; color:#64748b;">Generated: $today<br/>VML Recover Enterprise System</div>
                </div>
                <div class="stats">
                    <div class="stat-box"><div class="title">Total Assigned Claim</div><div class="val">UGX ${String.format("%,.0f", totalClaims)}</div></div>
                    <div class="stat-box"><div class="title">Recovered Cash</div><div class="val" style="color:#16a34a;">UGX ${String.format("%,.0f", totalRecovered)}</div></div>
                    <div class="stat-box"><div class="title">Net Outstanding</div><div class="val" style="color:#dc2626;">UGX ${String.format("%,.0f", totalOutstanding)}</div></div>
                    <div class="stat-box"><div class="title">Recovery Rate</div><div class="val" style="color:#2563eb;">${String.format("%.1f", rate)}%</div></div>
                </div>
                <h3>Assigned Debtor Registry (${clientCases.size} Accounts)</h3>
                <table>
                    <thead><tr><th>Case ID</th><th>Debtor Name & Sector</th><th>Legal Stage</th><th style="text-align:right;">Claim Amount</th><th style="text-align:right;">Paid</th><th style="text-align:right;">Outstanding</th></tr></thead>
                    <tbody>$casesRows</tbody>
                </table>
            </body>
            </html>
        """.trimIndent()
    }

    fun generateEmployeeAuditReportHtml(employee: UserEntity, logs: List<AuditLogEntity>): String {
        val today = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date())
        val empLogs = logs.filter { it.actorUserId == employee.userId || it.actorUserId == employee.email || it.targetId == employee.userId }
        val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.getDefault())

        val logRows = if (empLogs.isEmpty()) {
            "<tr><td colspan='4' style='text-align:center; padding:12px; color:#666;'>No audit trail activity recorded for this employee</td></tr>"
        } else {
            empLogs.joinToString("\n") { l ->
                val timeStr = sdf.format(Date(l.timestamp))
                val badgeColor = when (l.action) {
                    "LOGIN_SUCCESS" -> "#16a34a"
                    "LOGOUT" -> "#64748b"
                    "OVERRIDE_LOGIN" -> "#dc2626"
                    "LOGIN_FAILED" -> "#b91c1c"
                    "ACCOUNT_LOCKED" -> "#ea580c"
                    else -> "#2563eb"
                }
                "<tr><td>$timeStr</td><td><span style='background:${badgeColor}20; color:$badgeColor; padding:3px 6px; border-radius:3px; font-weight:bold;'>${l.action}</span></td><td><strong>${l.targetEntity}</strong> (${l.targetId})</td><td>${l.details}<br/><span style='font-size:8pt; color:#64748b;'>Device: ${l.ipOrDevice}</span></td></tr>"
            }
        }

        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8"/>
                <style>
                    body { font-family: 'Helvetica Neue', Arial, sans-serif; margin: 30px; color: #0f172a; line-height: 1.4; }
                    .header { border-bottom: 2px solid #0f172a; padding-bottom: 10px; margin-bottom: 16px; display:flex; justify-content:space-between; }
                    .profile { background: #f8fafc; border: 1px solid #e2e8f0; padding: 14px; border-radius: 6px; margin-bottom: 20px; }
                    table { width: 100%; border-collapse: collapse; font-size: 9.5pt; margin-top: 10px; }
                    th { background: #1e293b; color: white; padding: 8px; text-align: left; }
                    td { padding: 8px; border-bottom: 1px solid #e2e8f0; vertical-align: top; }
                </style>
            </head>
            <body>
                <div class="header">
                    <div>
                        <h1 style="margin:0; font-size:18pt; color:#1e3a8a;">EMPLOYEE AUDIT TRAIL & ACTIVITY REPORT</h1>
                        <div style="font-size:10pt; color:#64748b;">Enterprise Access Security & Activity Tracking</div>
                    </div>
                    <div style="text-align:right; font-size:9pt; color:#64748b;">Generated: $today<br/>VML Recover Security</div>
                </div>
                <div class="profile">
                    <div style="font-size:13pt; font-weight:bold;">${employee.fullName}</div>
                    <div style="font-size:10pt; color:#475569;">Email: ${employee.email} • ID: ${employee.userId} • Role: <strong>${employee.role}</strong></div>
                    <div style="font-size:10pt; color:#475569;">Department: ${employee.department} • Phone: ${employee.phoneNumber} • Org: ${employee.organization}</div>
                    <div style="font-size:10pt; margin-top:4px;">Status: <strong>${if (employee.isLocked) "LOCKED / CLOSED" else "ACTIVE"}</strong> • Last Login: ${if (employee.lastLoginAt > 0) sdf.format(Date(employee.lastLoginAt)) else "Never"}</div>
                </div>
                <h3>Authentication & Activity Trail (${empLogs.size} Events)</h3>
                <table>
                    <thead><tr><th style="width:160px;">Timestamp</th><th style="width:130px;">Action</th><th style="width:140px;">Target</th><th>Audit Trail Details & Information</th></tr></thead>
                    <tbody>$logRows</tbody>
                </table>
            </body>
            </html>
        """.trimIndent()
    }
}
