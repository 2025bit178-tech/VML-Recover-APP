package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.formatUgxShort
import com.example.ui.theme.VmlAmber
import com.example.ui.theme.VmlAmberContainer
import com.example.ui.theme.VmlBlue
import com.example.ui.theme.VmlBlueContainer
import com.example.ui.theme.VmlGold
import com.example.ui.theme.VmlGoldDim
import com.example.ui.theme.VmlGoldLight
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlGreenContainer
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlRedContainer
import com.example.ui.theme.VmlSlate
import com.example.ui.theme.VmlTextPrimary
import com.example.viewmodel.VmlViewModel

@Composable
fun AdminAnalyticsScreen(
    viewModel: VmlViewModel,
    modifier: Modifier = Modifier
) {
    val cases by viewModel.allCases.collectAsState()
    val metrics by viewModel.portfolioMetrics.collectAsState()
    val allPromises by viewModel.allPromises.collectAsState()
    val allPlans by viewModel.allPlans.collectAsState()

    var activeFilter by remember { mutableStateOf("ALL") }

    val filterOptions = listOf(
        "ALL" to "All 10 Metrics",
        "RECOVERIES" to "Officer / Client / Region",
        "AGEING_LEGAL" to "Ageing & Pipeline",
        "COLLECTIONS" to "Daily & Monthly",
        "PERFORMANCE" to "Productivity & Default"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(VmlNavyDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Executive Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(VmlGoldDim),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Leaderboard,
                                    contentDescription = null,
                                    tint = VmlGoldLight,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "EXECUTIVE MANAGEMENT INTELLIGENCE",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = VmlGoldLight,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "Comprehensive Recovery Analytics & Audits",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VmlTextPrimary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Total Portfolio", fontSize = 10.sp, color = VmlSlate)
                            Text(text = formatUgxShort(metrics.totalAssigned), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "Total Recovered", fontSize = 10.sp, color = VmlSlate)
                            Text(text = formatUgxShort(metrics.totalRecovered), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = VmlGreen)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Recovery Rate", fontSize = 10.sp, color = VmlSlate)
                            Text(text = "${String.format("%.1f", metrics.recoveryRate)}%", fontSize = 14.sp, fontWeight = FontWeight.Black, color = VmlGoldLight)
                        }
                    }
                }
            }
        }

        // Section Filters Bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                filterOptions.forEach { (key, label) ->
                    val isSelected = activeFilter == key
                    FilterChip(
                        selected = isSelected,
                        onClick = { activeFilter = key },
                        label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = VmlGold,
                            selectedLabelColor = VmlNavyDark,
                            containerColor = VmlNavySurface,
                            labelColor = VmlSlate
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) VmlGold else VmlNavyBorder
                        )
                    )
                }
            }
        }

        // 1. RECOVERY BY OFFICER
        if (activeFilter == "ALL" || activeFilter == "RECOVERIES") {
            item {
                AnalyticsSectionCard(
                    title = "1. RECOVERY BY OFFICER",
                    subtitle = "Individual officer portfolio allocation and recovery conversion",
                    icon = Icons.Default.People
                ) {
                    OfficerPerformanceRow("Officer David Ochieng", "Kampala Central", 1_420_000_000.0, 580_000_000.0, 40.8f, "Rank #1")
                    OfficerPerformanceRow("Officer Ronald Ssenyonga", "Entebbe / Industrial", 1_180_000_000.0, 440_000_000.0, 37.3f, "Rank #2")
                    OfficerPerformanceRow("Officer Beatrice Alupo", "Jinja / Eastern Zone", 980_000_000.0, 350_000_000.0, 35.7f, "Rank #3")
                    OfficerPerformanceRow("Officer Moses Kiggundu", "Mbarara / Western Belt", 1_240_000_000.0, 390_000_000.0, 31.5f, "Rank #4")
                }
            }
        }

        // 2. RECOVERY BY CLIENT
        if (activeFilter == "ALL" || activeFilter == "RECOVERIES") {
            item {
                AnalyticsSectionCard(
                    title = "2. RECOVERY BY CLIENT",
                    subtitle = "Institutional creditor recovery performance and resolution rate",
                    icon = Icons.Default.AccountBalance
                ) {
                    ClientRecoveryRow("Stanbic Bank Uganda Ltd", 2_150_000_000.0, 890_000_000.0, 41.4f)
                    ClientRecoveryRow("Centenary SACCO Federation", 1_120_000_000.0, 420_000_000.0, 37.5f)
                    ClientRecoveryRow("QuickLoans Corporate Capital", 850_000_000.0, 260_000_000.0, 30.6f)
                    ClientRecoveryRow("Equity Bank Uganda", 460_000_000.0, 130_000_000.0, 28.3f)
                    ClientRecoveryRow("DFCU Bank Commercial", 240_000_000.0, 60_000_000.0, 25.0f)
                }
            }
        }

        // 3. RECOVERY BY REGION
        if (activeFilter == "ALL" || activeFilter == "RECOVERIES") {
            item {
                AnalyticsSectionCard(
                    title = "3. RECOVERY BY REGION",
                    subtitle = "Ugandan commercial territory distribution and enforcement yield",
                    icon = Icons.Default.LocationOn
                ) {
                    RegionRecoveryRow("Kampala Central Business District", 2_350_000_000.0, 940_000_000.0, 40.0f, "98 Active Cases")
                    RegionRecoveryRow("Wakiso & Entebbe Corridor", 1_050_000_000.0, 380_000_000.0, 36.2f, "42 Active Cases")
                    RegionRecoveryRow("Jinja & Eastern Industrial Hub", 620_000_000.0, 220_000_000.0, 35.5f, "28 Active Cases")
                    RegionRecoveryRow("Mbarara & Western Trade Belt", 540_000_000.0, 150_000_000.0, 27.8f, "24 Active Cases")
                    RegionRecoveryRow("Gulu & Northern Agricultural Hub", 260_000_000.0, 70_000_000.0, 26.9f, "12 Active Cases")
                }
            }
        }

        // 4. AGEING OF DATES / DEBTS
        if (activeFilter == "ALL" || activeFilter == "AGEING_LEGAL") {
            item {
                AnalyticsSectionCard(
                    title = "4. AGEING OF DEBTS (AGEING OF DATES)",
                    subtitle = "Delinquency breakdown and associated judicial recovery probabilities",
                    icon = Icons.Default.DateRange
                ) {
                    AgeingRow("0–30 Days", "UGX 640M", 85, VmlGreen, "Early Amicable Outreach")
                    AgeingRow("31–60 Days", "UGX 890M", 65, VmlBlue, "Formal Notice Dispatched")
                    AgeingRow("61–90 Days", "UGX 720M", 50, VmlAmber, "Field Visit & Standstill")
                    AgeingRow("91–180 Days", "UGX 1.15B", 35, VmlRed, "Legal Plaint Drafting")
                    AgeingRow("181–365 Days", "UGX 980M", 20, VmlRed, "Commercial Court Litigation")
                    AgeingRow("1+ Year", "UGX 440M", 12, Color(0xFF991B1B), "Decree & Asset Execution")
                }
            }
        }

        // 5. LEGAL PIPELINE
        if (activeFilter == "ALL" || activeFilter == "AGEING_LEGAL") {
            item {
                AnalyticsSectionCard(
                    title = "5. LEGAL PIPELINE (JUDICIAL ENFORCEMENT)",
                    subtitle = "Case counts and monetary exposure across the 9 recovery stages",
                    icon = Icons.Default.Gavel
                ) {
                    LegalPipelineRow("Stage 1: Collection", 58, 1_120_000_000.0, VmlGreen)
                    LegalPipelineRow("Stage 2: Statutory Demand", 34, 780_000_000.0, VmlAmber)
                    LegalPipelineRow("Stage 3: Negotiation", 26, 640_000_000.0, VmlBlue)
                    LegalPipelineRow("Stage 4: Legal Review", 19, 520_000_000.0, VmlGoldLight)
                    LegalPipelineRow("Stage 5: High Court Litigation", 18, 790_000_000.0, VmlRed)
                    LegalPipelineRow("Stage 6: Judgment", 8, 380_000_000.0, VmlGold)
                    LegalPipelineRow("Stage 7: Enforcement & Attachment", 12, 410_000_000.0, VmlRed)
                    LegalPipelineRow("Stage 8: Recovery Settlement & Payout", 14, 180_000_000.0, VmlGreen)
                    LegalPipelineRow("Stage 9: File Closure", 89, 1_760_000_000.0, Color(0xFF94A3B8))
                }
            }
        }

        // 6. DAILY COLLECTIONS
        if (activeFilter == "ALL" || activeFilter == "COLLECTIONS") {
            item {
                AnalyticsSectionCard(
                    title = "6. DAILY COLLECTIONS",
                    subtitle = "Real-time daily collection volume and channel clearing breakdown",
                    icon = Icons.Default.Receipt
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DailyMetricBox("Today", "UGX 48.5M", "18 Receipts", VmlGreen)
                        DailyMetricBox("Yesterday", "UGX 62.0M", "24 Receipts", VmlBlue)
                        DailyMetricBox("7-Day Avg", "UGX 54.2M / day", "Consistent", VmlGoldLight)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Today's Clearing Channels:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                    Spacer(modifier = Modifier.height(4.dp))
                    ChannelShareRow("Stanbic Bank EFT / Direct Wire", "UGX 31.5M", 0.65f, VmlGreen)
                    ChannelShareRow("MTN Mobile Money Collections", "UGX 12.0M", 0.25f, VmlAmber)
                    ChannelShareRow("Airtel Money Commercial", "UGX 5.0M", 0.10f, VmlRed)
                }
            }
        }

        // 7. MONTHLY COLLECTIONS
        if (activeFilter == "ALL" || activeFilter == "COLLECTIONS") {
            item {
                AnalyticsSectionCard(
                    title = "7. MONTHLY COLLECTIONS",
                    subtitle = "Monthly trajectory and historical performance against target",
                    icon = Icons.Default.CalendarToday
                ) {
                    MonthlyRow("October 2026 (MTD)", 185_000_000.0, 320_000_000.0, VmlGoldLight)
                    MonthlyRow("September 2026", 240_000_000.0, 220_000_000.0, VmlGreen)
                    MonthlyRow("August 2026", 210_000_000.0, 200_000_000.0, VmlGreen)
                    MonthlyRow("July 2026", 195_000_000.0, 190_000_000.0, VmlGreen)
                    MonthlyRow("June 2026", 170_000_000.0, 180_000_000.0, VmlAmber)
                }
            }
        }

        // 8. OFFICER PRODUCTIVITY
        if (activeFilter == "ALL" || activeFilter == "PERFORMANCE") {
            item {
                AnalyticsSectionCard(
                    title = "8. OFFICER PRODUCTIVITY",
                    subtitle = "Daily activity volume, calls, premise visits & Fair Code compliance",
                    icon = Icons.Default.Assessment
                ) {
                    ProductivityRow("Officer David Ochieng", calls = 34, visits = 4, ptps = 7, compliance = "100%", score = 96)
                    ProductivityRow("Officer Ronald Ssenyonga", calls = 28, visits = 3, ptps = 5, compliance = "100%", score = 89)
                    ProductivityRow("Officer Beatrice Alupo", calls = 25, visits = 4, ptps = 4, compliance = "100%", score = 86)
                    ProductivityRow("Officer Moses Kiggundu", calls = 22, visits = 2, ptps = 4, compliance = "98%", score = 82)
                }
            }
        }

        // 9. DEFAULT RATES
        if (activeFilter == "ALL" || activeFilter == "PERFORMANCE") {
            item {
                AnalyticsSectionCard(
                    title = "9. DEFAULT RATES & RISK EXPOSURE",
                    subtitle = "Default ratio on promises to pay and structured payment plans",
                    icon = Icons.Default.TrendingDown
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DefaultRateBox("PTP Default Rate", "14.8%", "18 Missed / 122", VmlAmber)
                        DefaultRateBox("Plan Default Rate", "11.2%", "5 Defaulted / 45", VmlBlue)
                        DefaultRateBox("Critical Risk %", "16.9%", "24 High Alert Files", VmlRed)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Primary Default Drivers:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "• 54% Supplier payment delays (UNRA / Gov contracts)", fontSize = 10.sp, color = VmlSlate)
                    Text(text = "• 28% Temporary trade cash flow compression", fontSize = 10.sp, color = VmlSlate)
                    Text(text = "• 18% Contested penalty interest calculation", fontSize = 10.sp, color = VmlSlate)
                }
            }
        }

        // 10. PAYMENT PLAN PERFORMANCE
        if (activeFilter == "ALL" || activeFilter == "PERFORMANCE") {
            item {
                AnalyticsSectionCard(
                    title = "10. PAYMENT PLAN PERFORMANCE",
                    subtitle = "Repayment plan completion rates, milestones and settlement integrity",
                    icon = Icons.Default.PieChart
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        PlanMetricBox("Active Plans", "42 Plans", "UGX 1.15B Value", VmlGoldLight)
                        PlanMetricBox("On-Schedule", "81.2%", "34 Accounts", VmlGreen)
                        PlanMetricBox("Restructured", "18.8%", "8 Accounts", VmlAmber)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Instalment Adherence:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                    Spacer(modifier = Modifier.height(4.dp))
                    PlanProgressBar("Instalment 1 (Upfront Commitment)", 0.94f, VmlGreen)
                    PlanProgressBar("Instalment 2 (Mid-Term Payment)", 0.88f, VmlBlue)
                    PlanProgressBar("Instalment 3 (Final Recovery Tranche)", 0.79f, VmlAmber)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
fun AnalyticsSectionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(VmlGoldDim),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(16.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VmlGoldLight, letterSpacing = 0.5.sp)
                    Text(text = subtitle, fontSize = 10.sp, color = VmlSlate)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
fun OfficerPerformanceRow(
    name: String,
    region: String,
    assigned: Double,
    recovered: Double,
    ratePercent: Float,
    rank: String
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                Text(text = "$region • Assigned: ${formatUgxShort(assigned)}", fontSize = 10.sp, color = VmlSlate)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(text = "${formatUgxShort(recovered)} (${String.format("%.1f", ratePercent)}%)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VmlGreen)
                Text(text = rank, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VmlGoldLight)
            }
        }
        Spacer(modifier = Modifier.height(3.dp))
        LinearProgressIndicator(
            progress = { (ratePercent / 100f).coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp)),
            color = VmlGreen,
            trackColor = VmlNavyDark
        )
    }
}

@Composable
fun ClientRecoveryRow(
    client: String,
    assigned: Double,
    recovered: Double,
    ratePercent: Float
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = client, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
            Text(text = "Claim: ${formatUgxShort(assigned)}", fontSize = 9.sp, color = VmlSlate)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = formatUgxShort(recovered), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlGreen)
            Spacer(modifier = Modifier.width(6.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(VmlGoldDim)
                    .padding(horizontal = 5.dp, vertical = 2.dp)
            ) {
                Text(text = "${String.format("%.0f", ratePercent)}%", fontSize = 9.sp, color = VmlGoldLight, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun RegionRecoveryRow(
    region: String,
    assigned: Double,
    recovered: Double,
    ratePercent: Float,
    casesCount: String
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = region, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = VmlTextPrimary)
            Text(text = "${formatUgxShort(recovered)} (${String.format("%.1f", ratePercent)}%)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlGreen)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = casesCount, fontSize = 9.sp, color = VmlSlate)
            Text(text = "Assigned: ${formatUgxShort(assigned)}", fontSize = 9.sp, color = VmlSlate)
        }
    }
}

@Composable
fun AgeingRow(
    bucket: String,
    amount: String,
    probability: Int,
    color: Color,
    action: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = bucket, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
            Text(text = action, fontSize = 9.sp, color = VmlSlate)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(text = amount, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
            Text(text = "Yield: $probability%", fontSize = 9.sp, color = color)
        }
    }
}

@Composable
fun LegalPipelineRow(
    stage: String,
    count: Int,
    amount: Double,
    color: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = stage, fontSize = 11.sp, color = VmlTextPrimary)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "$count Files", fontSize = 10.sp, color = VmlSlate)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = formatUgxShort(amount), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
fun DailyMetricBox(title: String, amount: String, count: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(VmlNavyDark)
            .border(1.dp, VmlNavyBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Column {
            Text(text = title, fontSize = 10.sp, color = VmlSlate)
            Text(text = amount, fontSize = 13.sp, fontWeight = FontWeight.Black, color = color)
            Text(text = count, fontSize = 9.sp, color = VmlSlate)
        }
    }
}

@Composable
fun ChannelShareRow(channel: String, amount: String, fraction: Float, color: Color) {
    Column(modifier = Modifier.padding(vertical = 2.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = channel, fontSize = 10.sp, color = VmlTextPrimary)
            Text(text = amount, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = color)
        }
        Spacer(modifier = Modifier.height(2.dp))
        LinearProgressIndicator(
            progress = { fraction },
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .clip(RoundedCornerShape(2.dp)),
            color = color,
            trackColor = VmlNavyDark
        )
    }
}

@Composable
fun MonthlyRow(month: String, collected: Double, target: Double, color: Color) {
    val fraction = (collected / target).toFloat().coerceIn(0f, 1f)
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = month, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
            Text(text = "${formatUgxShort(collected)} / ${formatUgxShort(target)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
        }
        Spacer(modifier = Modifier.height(2.dp))
        LinearProgressIndicator(
            progress = { fraction },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp)),
            color = color,
            trackColor = VmlNavyDark
        )
    }
}

@Composable
fun ProductivityRow(
    officer: String,
    calls: Int,
    visits: Int,
    ptps: Int,
    compliance: String,
    score: Int
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = officer, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                Text(text = "$calls Calls • $visits Visits • $ptps PTPs • Code: $compliance", fontSize = 9.sp, color = VmlSlate)
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (score >= 90) VmlGreenContainer else VmlBlueContainer)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(text = "Score: $score", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (score >= 90) VmlGreen else VmlBlue)
            }
        }
    }
}

@Composable
fun DefaultRateBox(label: String, rate: String, count: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(VmlNavyDark)
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Column {
            Text(text = label, fontSize = 9.sp, color = VmlSlate)
            Text(text = rate, fontSize = 15.sp, fontWeight = FontWeight.Black, color = color)
            Text(text = count, fontSize = 8.sp, color = VmlSlate)
        }
    }
}

@Composable
fun PlanMetricBox(title: String, mainVal: String, subVal: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(VmlNavyDark)
            .border(1.dp, VmlNavyBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Column {
            Text(text = title, fontSize = 9.sp, color = VmlSlate)
            Text(text = mainVal, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color)
            Text(text = subVal, fontSize = 8.sp, color = VmlSlate)
        }
    }
}

@Composable
fun PlanProgressBar(label: String, progress: Float, color: Color) {
    Column(modifier = Modifier.padding(vertical = 3.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, fontSize = 10.sp, color = VmlTextPrimary)
            Text(text = "${(progress * 100).toInt()}% Adherence", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = color)
        }
        Spacer(modifier = Modifier.height(2.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp)),
            color = color,
            trackColor = VmlNavyDark
        )
    }
}
