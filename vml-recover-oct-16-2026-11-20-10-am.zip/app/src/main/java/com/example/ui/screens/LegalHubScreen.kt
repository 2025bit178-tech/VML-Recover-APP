package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Print
import androidx.compose.ui.platform.LocalContext
import com.example.ui.components.PrintUtils
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LegalDocumentEntity
import com.example.ui.components.formatUgxShort
import com.example.ui.theme.VmlAmber
import com.example.ui.theme.VmlAmberContainer
import com.example.ui.theme.VmlBlue
import com.example.ui.theme.VmlBlueContainer
import com.example.ui.theme.VmlGold
import com.example.ui.theme.VmlGoldDim
import com.example.ui.theme.VmlGoldLight
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlGreenContainer
import com.example.ui.theme.VmlNavy
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlRedContainer
import com.example.ui.theme.VmlSlate
import com.example.ui.theme.VmlTextPrimary
import com.example.ui.theme.VmlTextSecondary
import com.example.viewmodel.VmlViewModel

@Composable
fun LegalHubScreen(
    viewModel: VmlViewModel,
    onNavigateToCase: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val legalDocs by viewModel.allLegalDocs.collectAsState()
    val cases by viewModel.allCases.collectAsState()

    val legalCases = cases.filter {
        it.status == "LEGAL" || it.legalStage in listOf("LEGAL_REVIEW", "LITIGATION", "JUDGMENT", "ENFORCEMENT")
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(VmlNavyDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Legal Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(VmlGoldDim),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Gavel, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "LEGAL CHAMBERS & LITIGATION",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Black,
                                    color = VmlGoldLight,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "Virgin Markets Multi Legal Judicial Division",
                                    fontSize = 11.sp,
                                    color = VmlSlate
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Active Litigations", fontSize = 11.sp, color = VmlSlate)
                            Text(text = "${legalCases.size} High Court Suits", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Total Judicial Claim", fontSize = 11.sp, color = VmlSlate)
                            Text(
                                text = formatUgxShort(legalCases.sumOf { it.outstandingBalance }),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = VmlRed
                            )
                        }
                    }
                }
            }
        }

        // Legal Escalation Stages Breakdown
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "JUDICIAL ENFORCEMENT PIPELINE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGoldLight,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    LegalPipelineStageRow("1. Statutory Demand (7-Day Notice)", cases.count { it.legalStage == "DEMAND" }, VmlAmber)
                    LegalPipelineStageRow("2. Legal Review & Plaint Draft", cases.count { it.legalStage == "LEGAL_REVIEW" }, VmlBlue)
                    LegalPipelineStageRow("3. Commercial High Court Litigation", cases.count { it.legalStage == "LITIGATION" }, VmlGoldLight)
                    LegalPipelineStageRow("4. Judgment & Decree Extraction", cases.count { it.legalStage == "JUDGMENT" }, VmlGold)
                    LegalPipelineStageRow("5. Enforcement & Asset Attachment", cases.count { it.legalStage == "ENFORCEMENT" }, VmlRed)
                }
            }
        }

        // Active Court Pleadings & Demand Notices
        item {
            Text(
                text = "ISSUED STATUTORY PLEADINGS & NOTICES (${legalDocs.size})",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = VmlGoldLight,
                letterSpacing = 1.sp
            )
        }

        items(legalDocs) { doc ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToCase(doc.caseId) },
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = doc.caseId,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlGoldLight
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(VmlGoldDim)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = doc.status, fontSize = 10.sp, color = VmlGoldLight, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = doc.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)

                    if (doc.courtReference != null) {
                        Text(text = "Suit: ${doc.courtReference}", fontSize = 11.sp, color = VmlSlate)
                    }

                    if (doc.courtDate != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DateRange, contentDescription = null, tint = VmlAmber, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Hearing Date: ${doc.courtDate}", fontSize = 11.sp, color = VmlAmber, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = doc.contentSummary, fontSize = 11.sp, color = VmlTextSecondary, lineHeight = 15.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        val matchingCase = cases.firstOrNull { it.caseId == doc.caseId }
                        Button(
                            onClick = {
                                val html = PrintUtils.generateLegalNoticeHtml(doc, matchingCase)
                                PrintUtils.printDocument(context, "LegalDoc_${doc.caseId}", html)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Icon(Icons.Default.Print, contentDescription = "Print", tint = VmlNavyDark, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Print Document", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlNavyDark)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LegalPipelineStageRow(stage: String, count: Int, color: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = stage, fontSize = 12.sp, color = VmlTextPrimary)
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(VmlNavyDark)
                .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
            Text(text = "$count Cases", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}
