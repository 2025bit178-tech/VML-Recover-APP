package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.model.CaseEntity
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatUgxShort
import com.example.ui.theme.VmlAmber
import com.example.ui.theme.VmlAmberContainer
import com.example.ui.theme.VmlBlue
import com.example.ui.theme.VmlBlueContainer
import com.example.ui.theme.VmlGold
import com.example.ui.theme.VmlGoldDim
import com.example.ui.theme.VmlGoldLight
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlGreenContainer
import com.example.ui.theme.VmlNavy
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlRedContainer
import com.example.ui.theme.VmlSlate
import com.example.ui.theme.VmlTextPrimary
import com.example.viewmodel.ClientPortfolioSummary
import com.example.viewmodel.UserRole
import com.example.viewmodel.VmlViewModel

@Composable
fun DashboardScreen(
    viewModel: VmlViewModel,
    onNavigateToCases: () -> Unit,
    onNavigateToCaseDetail: (String) -> Unit,
    onNavigateToLegal: () -> Unit,
    onNavigateToPromises: () -> Unit,
    onNavigateToVisits: () -> Unit,
    onOpenNewCaseDialog: () -> Unit,
    onOpenPaymentDialog: () -> Unit,
    onOpenPromiseDialog: () -> Unit,
    onNavigateToAnalytics: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val metrics by viewModel.portfolioMetrics.collectAsState()
    val cases by viewModel.allCases.collectAsState()
    val role by viewModel.currentRole.collectAsState()
    val clientSummaries by viewModel.clientSummaries.collectAsState()
    val selectedDashboardClient by viewModel.selectedDashboardClient.collectAsState()

    var showAddClientDialog by remember { mutableStateOf(false) }

    // Client debtor search and filter states
    var debtorSearchQuery by remember { mutableStateOf("") }
    var selectedDebtorTypeFilter by remember { mutableStateOf("ALL") } // ALL, INDIVIDUAL, COMPANY
    var selectedStatusFilter by remember { mutableStateOf("ALL") }

    val isAllClientsSelected = selectedDashboardClient == null || selectedDashboardClient == "ALL"
    val activeClientSummary = clientSummaries.firstOrNull { it.clientName.equals(selectedDashboardClient, ignoreCase = true) }

    // Debtors belonging strictly to the selected client
    val clientDebtors = remember(cases, selectedDashboardClient, debtorSearchQuery, selectedDebtorTypeFilter, selectedStatusFilter) {
        if (isAllClientsSelected) {
            emptyList()
        } else {
            val primaryName = selectedDashboardClient!!.split(" ").first()
            cases.filter { caseItem ->
                val matchesClient = caseItem.creditorName.equals(selectedDashboardClient, ignoreCase = true) ||
                        caseItem.creditorName.contains(primaryName, ignoreCase = true)

                val matchesSearch = if (debtorSearchQuery.isBlank()) true else {
                    caseItem.debtorName.contains(debtorSearchQuery, ignoreCase = true) ||
                            caseItem.debtorPhone.contains(debtorSearchQuery, ignoreCase = true) ||
                            caseItem.caseId.contains(debtorSearchQuery, ignoreCase = true) ||
                            caseItem.creditorAccountNumber.contains(debtorSearchQuery, ignoreCase = true)
                }

                val matchesType = if (selectedDebtorTypeFilter == "ALL") true else {
                    caseItem.debtorType.equals(selectedDebtorTypeFilter, ignoreCase = true)
                }

                val matchesStatus = if (selectedStatusFilter == "ALL") true else {
                    caseItem.status.equals(selectedStatusFilter, ignoreCase = true)
                }

                matchesClient && matchesSearch && matchesType && matchesStatus
            }
        }
    }

    if (showAddClientDialog) {
        AddClientDialog(
            onDismiss = { showAddClientDialog = false },
            onAddClient = { name, code, sector, contactPerson, phone, email, address ->
                viewModel.addNewClient(
                    name = name,
                    code = code,
                    sector = sector,
                    contactPerson = contactPerson,
                    phone = phone,
                    email = email,
                    address = address
                ) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                    if (success) {
                        showAddClientDialog = false
                    }
                }
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(VmlNavyDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Director Analytics Shortcut (if applicable)
        if (role == UserRole.DIRECTOR && onNavigateToAnalytics != null) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToAnalytics() },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(VmlGoldDim),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.TrendingUp, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(16.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "EXECUTIVE RECOVERY ANALYTICS",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VmlGoldLight,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "Portfolio • Client • Region • Ageing • Pipeline",
                                    fontSize = 10.sp,
                                    color = VmlSlate
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(VmlGold)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(text = "View", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlNavyDark)
                        }
                    }
                }
            }
        }

        // 2. Hero Visual Banner (Professional VML Command Centre, No Stanbic branding)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold.copy(alpha = 0.5f))
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.vml_hero),
                        contentDescription = "VML Legal Banner",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    listOf(
                                        VmlNavyDark.copy(alpha = 0.95f),
                                        VmlNavyDark.copy(alpha = 0.70f),
                                        Color.Transparent
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = "Security",
                                tint = VmlGoldLight,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "VIRGIN MARKETS MULTI LEGAL",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlGoldLight,
                                letterSpacing = 1.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Executive Recovery Command Centre",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = VmlTextPrimary
                        )
                        Text(
                            text = "Auditable Multi-Client Debt Collection & Judicial Enforcement",
                            fontSize = 11.sp,
                            color = VmlSlate
                        )
                    }
                }
            }
        }

        // 3. Client & Debtor Database Switcher / Selector
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "CLIENT & DEBTOR DATABASE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlGoldLight,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = if (isAllClientsSelected) "Multi-Client Portfolio Overview" else "Active Client: ${selectedDashboardClient}",
                                fontSize = 11.sp,
                                color = VmlSlate
                            )
                        }

                        Button(
                            onClick = { showAddClientDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("btn_add_client_quick")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = VmlNavyDark, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Client", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlNavyDark)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Horizontal Client Selector Chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            FilterChip(
                                selected = isAllClientsSelected,
                                onClick = { viewModel.selectDashboardClient("ALL") },
                                label = { Text("All Clients Overview", fontSize = 11.sp) },
                                leadingIcon = {
                                    Icon(Icons.Default.AccountBalance, contentDescription = null, modifier = Modifier.size(14.dp))
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = VmlGold,
                                    selectedLabelColor = VmlNavyDark,
                                    selectedLeadingIconColor = VmlNavyDark,
                                    containerColor = VmlNavyDark,
                                    labelColor = VmlSlate
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    borderColor = if (isAllClientsSelected) VmlGold else VmlNavyBorder,
                                    enabled = true,
                                    selected = isAllClientsSelected
                                )
                            )
                        }

                        items(clientSummaries) { client ->
                            val isSelected = selectedDashboardClient.equals(client.clientName, ignoreCase = true)
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.selectDashboardClient(client.clientName) },
                                label = { Text("${client.clientName} (${client.debtorCount})", fontSize = 11.sp) },
                                leadingIcon = {
                                    Box(
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clip(CircleShape)
                                            .background(if (isSelected) VmlNavyDark else VmlGoldDim),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = client.logoInitials,
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) VmlGoldLight else VmlGold
                                        )
                                    }
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = VmlGold,
                                    selectedLabelColor = VmlNavyDark,
                                    selectedLeadingIconColor = VmlNavyDark,
                                    containerColor = VmlNavyDark,
                                    labelColor = VmlTextPrimary
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    borderColor = if (isSelected) VmlGold else VmlNavyBorder,
                                    enabled = true,
                                    selected = isSelected
                                )
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // VIEW 1: ALL CLIENTS OVERVIEW & SECTIONS
        // ==========================================
        if (isAllClientsSelected) {
            // Aggregate Executive Portfolio Overview Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("portfolio_overview_card"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "PORTFOLIO RECOVERY PERFORMANCE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlGoldLight,
                                letterSpacing = 1.sp
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(VmlGreenContainer)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "${String.format("%.1f", metrics.recoveryRate)}% RECOVERED",
                                    color = VmlGreen,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = formatUgxShort(metrics.totalAssigned),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = VmlTextPrimary
                        )
                        Text(
                            text = "Total Recoverable Across ${clientSummaries.size} Banking Partners",
                            fontSize = 11.sp,
                            color = VmlSlate
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        LinearProgressIndicator(
                            progress = { (metrics.recoveryRate / 100.0).toFloat().coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = VmlGreen,
                            trackColor = VmlNavyDark
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "Recovered Cash", fontSize = 10.sp, color = VmlSlate)
                                Text(
                                    text = formatUgxShort(metrics.totalRecovered),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VmlGreen
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "Net Outstanding", fontSize = 10.sp, color = VmlSlate)
                                Text(
                                    text = formatUgxShort(metrics.totalOutstanding),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VmlRed
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(VmlNavyBorder)
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        // 4 Pipeline Sub-metrics
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            MetricPill("Active Cases", "${metrics.activeCasesCount}", VmlBlue)
                            MetricPill("Critical", "${metrics.criticalCasesCount}", VmlRed)
                            MetricPill("Legal Litigation", "${metrics.legalCasesCount}", VmlGoldLight)
                            MetricPill("Closed", "${metrics.closedCasesCount}", VmlGreen)
                        }
                    }
                }
            }

            // Client Portfolios Section Title
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "REGISTERED CLIENT PORTFOLIOS (${clientSummaries.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGoldLight,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Independent Records",
                        fontSize = 10.sp,
                        color = VmlSlate
                    )
                }
            }

            // Every client has their own independent section / card
            items(clientSummaries) { client ->
                ClientPortfolioSectionCard(
                    client = client,
                    onViewPortfolio = {
                        viewModel.selectDashboardClient(client.clientName)
                    }
                )
            }

            // Quick Actions & Deadlines
            item {
                Column {
                    Text(
                        text = "TODAY'S ACTIONS & DEADLINES",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGoldLight,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ActionCard(
                            title = "Critical Cases",
                            value = "${metrics.criticalCasesCount}",
                            label = "Immediate Action",
                            icon = Icons.Default.Warning,
                            color = VmlRed,
                            bgColor = VmlRedContainer,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onNavigateToCases() }
                        )
                        ActionCard(
                            title = "Follow-ups Due",
                            value = "${metrics.followUpsDueCount}",
                            label = "Calls & Notices",
                            icon = Icons.Default.Phone,
                            color = VmlAmber,
                            bgColor = VmlAmberContainer,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onNavigateToCases() }
                        )
                        ActionCard(
                            title = "Payments Today",
                            value = "${metrics.paymentsTodayCount}",
                            label = "Reconciled",
                            icon = Icons.Default.Receipt,
                            color = VmlGreen,
                            bgColor = VmlGreenContainer,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onNavigateToCases() }
                        )
                    }
                }
            }

            // Operational Quick Actions
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "COMMAND ACTIONS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlSlate,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = onOpenNewCaseDialog,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_register_new_case"),
                                colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = VmlNavyDark, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("New Case", fontSize = 11.sp, color = VmlNavyDark, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = onOpenPaymentDialog,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_log_payment"),
                                colors = ButtonDefaults.buttonColors(containerColor = VmlGreen),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.AttachMoney, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Log Pay", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = onOpenPromiseDialog,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_record_ptp"),
                                colors = ButtonDefaults.buttonColors(containerColor = VmlBlue),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Schedule, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("New PTP", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Portfolio Ageing Analysis
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "PORTFOLIO AGEING ANALYSIS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlGoldLight,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Ugandan Judicial Escalation",
                                fontSize = 10.sp,
                                color = VmlSlate
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))

                        AgeingBarItem("0–30 Days", "UGX 640M", 0.85f, VmlGreen, "Early Amicable Calls")
                        AgeingBarItem("31–60 Days", "UGX 890M", 0.65f, VmlBlue, "Demand Letters Dispatched")
                        AgeingBarItem("61–90 Days", "UGX 720M", 0.50f, VmlAmber, "Field Visits & Standstill")
                        AgeingBarItem("91–180 Days", "UGX 1.15B", 0.35f, VmlRed, "Legal Review & Plaint Draft")
                        AgeingBarItem("181–365 Days", "UGX 980M", 0.20f, VmlRed, "High Court Litigation")
                        AgeingBarItem("1+ Year", "UGX 440M", 0.12f, Color(0xFF991B1B), "Decree & Asset Attachment")
                    }
                }
            }

            // Priority Cases Awaiting Action
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PRIORITY CASES FOR ACTION",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGoldLight,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "View All (${cases.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGold,
                        modifier = Modifier.clickable { onNavigateToCases() }
                    )
                }
            }

            items(cases.take(3)) { caseItem ->
                PriorityCaseCard(
                    caseItem = caseItem,
                    onClick = { onNavigateToCaseDetail(caseItem.caseId) }
                )
            }
        }

        // ==========================================
        // VIEW 2: INDIVIDUAL CLIENT DEDICATED PORTFOLIO
        // ==========================================
        else {
            if (activeClientSummary != null) {
                // Client Dedicated Portfolio Header Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, VmlGold)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(VmlGoldDim)
                                            .border(1.dp, VmlGold, RoundedCornerShape(8.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = activeClientSummary.logoInitials,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Black,
                                            color = VmlGoldLight
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = activeClientSummary.clientName,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = VmlTextPrimary
                                        )
                                        Text(
                                            text = "${activeClientSummary.clientId} • ${activeClientSummary.sector}",
                                            fontSize = 10.sp,
                                            color = VmlSlate
                                        )
                                    }
                                }

                                TextButton(
                                    onClick = { viewModel.selectDashboardClient("ALL") },
                                    colors = ButtonDefaults.textButtonColors(contentColor = VmlGold)
                                ) {
                                    Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("All Clients", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Contact info
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Phone, contentDescription = null, tint = VmlSlate, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = activeClientSummary.contactPhone, fontSize = 10.sp, color = VmlSlate)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Email, contentDescription = null, tint = VmlSlate, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = activeClientSummary.contactEmail, fontSize = 10.sp, color = VmlSlate)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Financial Highlights
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(text = "Total Instructed", fontSize = 10.sp, color = VmlSlate)
                                    Text(text = formatUgxShort(activeClientSummary.totalDebt), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = "Recovered Cash", fontSize = 10.sp, color = VmlSlate)
                                    Text(text = formatUgxShort(activeClientSummary.totalRecovered), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlGreen)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = "Net Outstanding", fontSize = 10.sp, color = VmlSlate)
                                    Text(text = formatUgxShort(activeClientSummary.totalOutstanding), fontSize = 14.sp, fontWeight = FontWeight.Black, color = VmlRed)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Recovery Progress
                            LinearProgressIndicator(
                                progress = { (activeClientSummary.recoveryRate / 100.0).toFloat().coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(5.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = VmlGreen,
                                trackColor = VmlNavyDark
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Debtor Type & Case Status Counts
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                MetricPill("Assigned Debtors", "${activeClientSummary.debtorCount}", VmlGoldLight)
                                MetricPill("Individual", "${activeClientSummary.individualDebtorsCount}", VmlBlue)
                                MetricPill("Company", "${activeClientSummary.companyDebtorsCount}", VmlAmber)
                                MetricPill("Active Cases", "${activeClientSummary.activeCasesCount}", VmlRed)
                                MetricPill("Fully Recovered", "${activeClientSummary.completedCasesCount}", VmlGreen)
                            }
                        }
                    }
                }

                // Search & Filter Bar for this client's debtors
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            OutlinedTextField(
                                value = debtorSearchQuery,
                                onValueChange = { debtorSearchQuery = it },
                                label = { Text("Search ${activeClientSummary.clientName} debtors...", color = VmlSlate, fontSize = 11.sp) },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = VmlGoldLight) },
                                trailingIcon = {
                                    if (debtorSearchQuery.isNotEmpty()) {
                                        IconButton(onClick = { debtorSearchQuery = "" }) {
                                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = VmlSlate)
                                        }
                                    }
                                },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = VmlGold,
                                    unfocusedBorderColor = VmlNavyBorder,
                                    focusedContainerColor = VmlNavyDark,
                                    unfocusedContainerColor = VmlNavyDark,
                                    focusedTextColor = VmlTextPrimary,
                                    unfocusedTextColor = VmlTextPrimary
                                )
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Filter Chips Row (Debtor Type & Status)
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                item {
                                    FilterChip(
                                        selected = selectedDebtorTypeFilter == "ALL",
                                        onClick = { selectedDebtorTypeFilter = "ALL" },
                                        label = { Text("All Debtors", fontSize = 10.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = VmlGold,
                                            selectedLabelColor = VmlNavyDark
                                        )
                                    )
                                }
                                item {
                                    FilterChip(
                                        selected = selectedDebtorTypeFilter == "INDIVIDUAL",
                                        onClick = { selectedDebtorTypeFilter = "INDIVIDUAL" },
                                        label = { Text("Individuals Only", fontSize = 10.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = VmlBlue,
                                            selectedLabelColor = Color.White
                                        )
                                    )
                                }
                                item {
                                    FilterChip(
                                        selected = selectedDebtorTypeFilter == "COMPANY",
                                        onClick = { selectedDebtorTypeFilter = "COMPANY" },
                                        label = { Text("Companies Only", fontSize = 10.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = VmlAmber,
                                            selectedLabelColor = VmlNavyDark
                                        )
                                    )
                                }
                                item {
                                    FilterChip(
                                        selected = selectedStatusFilter == "ACTIVE",
                                        onClick = { selectedStatusFilter = if (selectedStatusFilter == "ACTIVE") "ALL" else "ACTIVE" },
                                        label = { Text("Active Status", fontSize = 10.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = VmlRed,
                                            selectedLabelColor = Color.White
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                // Debtors List Header
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${activeClientSummary.clientName} DEBTORS (${clientDebtors.size})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlGoldLight,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Linked to Client ID: ${activeClientSummary.clientId}",
                            fontSize = 10.sp,
                            color = VmlSlate
                        )
                    }
                }

                if (clientDebtors.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Default.Search, contentDescription = null, tint = VmlSlate, modifier = Modifier.size(32.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "No debtors match the current filter criteria.",
                                    fontSize = 12.sp,
                                    color = VmlSlate
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = onOpenNewCaseDialog,
                                    colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text("Register New Debtor for ${activeClientSummary.clientName}", fontSize = 11.sp, color = VmlNavyDark, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                } else {
                    items(clientDebtors) { debtor ->
                        ClientDebtorRecordCard(
                            caseItem = debtor,
                            onClick = { onNavigateToCaseDetail(debtor.caseId) }
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

// ==========================================
// CLIENT PORTFOLIO CARD COMPONENT
// ==========================================

@Composable
fun ClientPortfolioSectionCard(
    client: ClientPortfolioSummary,
    onViewPortfolio: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("client_portfolio_${client.clientCode.lowercase()}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header Row: Bank Logo/Initials, Name, Code, and View Portfolio Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(VmlGoldDim)
                            .border(1.dp, VmlGold, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = client.logoInitials,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            color = VmlGoldLight
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = client.clientName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlTextPrimary
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = client.clientId,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = VmlGoldLight
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "• ${client.sector}",
                                fontSize = 9.sp,
                                color = VmlSlate
                            )
                        }
                    }
                }

                Button(
                    onClick = onViewPortfolio,
                    colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("btn_view_portfolio_${client.clientCode.lowercase()}")
                ) {
                    Text("View Portfolio", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VmlNavyDark)
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = VmlNavyDark, modifier = Modifier.size(12.dp))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Debt Totals Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Outstanding Debt", fontSize = 9.sp, color = VmlSlate)
                    Text(
                        text = formatUgxShort(client.totalOutstanding),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        color = VmlRed
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "Assigned Debtors", fontSize = 9.sp, color = VmlSlate)
                    Text(
                        text = "${client.debtorCount}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlTextPrimary
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "Recovery Rate", fontSize = 9.sp, color = VmlSlate)
                    Text(
                        text = "${String.format("%.1f", client.recoveryRate)}%",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGreen
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Recovery Progress Bar
            LinearProgressIndicator(
                progress = { (client.recoveryRate / 100.0).toFloat().coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = VmlGreen,
                trackColor = VmlNavyDark
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Debtors Breakdown & Case Statuses (Pills)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    DebtorTypePill("Ind: ${client.individualDebtorsCount}", VmlBlue)
                    DebtorTypePill("Comp: ${client.companyDebtorsCount}", VmlAmber)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    DebtorTypePill("Active: ${client.activeCasesCount}", VmlRed)
                    DebtorTypePill("Pending: ${client.pendingCasesCount}", VmlAmber)
                    DebtorTypePill("Done: ${client.completedCasesCount}", VmlGreen)
                }
            }
        }
    }
}

// ==========================================
// INDIVIDUAL CLIENT DEBTOR RECORD CARD
// ==========================================

@Composable
fun ClientDebtorRecordCard(
    caseItem: CaseEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("debtor_item_${caseItem.caseId}"),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Debtor Name, Type Badge, and Balance
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = caseItem.debtorName,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlTextPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (caseItem.debtorType.equals("COMPANY", ignoreCase = true)) VmlAmberContainer else VmlBlueContainer)
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = caseItem.debtorType,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (caseItem.debtorType.equals("COMPANY", ignoreCase = true)) VmlAmber else VmlBlue
                        )
                    }
                }

                Text(
                    text = formatUgxShort(caseItem.outstandingBalance),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = VmlRed
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Contact Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${caseItem.debtorPhone} • ${caseItem.debtorEmail.ifBlank { "No email" }}",
                    fontSize = 10.sp,
                    color = VmlSlate
                )
                Text(
                    text = "Ref: ${caseItem.creditorAccountNumber.ifBlank { caseItem.caseId }}",
                    fontSize = 10.sp,
                    color = VmlGoldLight,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Sector and Assigned Officer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Sector: ${caseItem.sectorOfWork}",
                    fontSize = 10.sp,
                    color = VmlTextPrimary
                )
                Text(
                    text = "Officer: ${caseItem.assignedOfficerName.ifBlank { "Unassigned" }}",
                    fontSize = 10.sp,
                    color = VmlGoldLight
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Legal Status & Last Follow-up Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusBadge(caseItem.status)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Stage: ${caseItem.legalStage.replace("_", " ")}",
                        fontSize = 10.sp,
                        color = VmlSlate
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Due: ${caseItem.dueDate.ifBlank { "Follow-up due" }}",
                        fontSize = 10.sp,
                        color = VmlSlate
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Details",
                        tint = VmlSlate,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun DebtorTypePill(text: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(color.copy(alpha = 0.15f))
            .border(0.5.dp, color.copy(alpha = 0.5f), RoundedCornerShape(3.dp))
            .padding(horizontal = 5.dp, vertical = 2.dp)
    ) {
        Text(text = text, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

// ==========================================
// ADD CLIENT DIALOG
// ==========================================

@Composable
fun AddClientDialog(
    onDismiss: () -> Unit,
    onAddClient: (name: String, code: String, sector: String, contactPerson: String, phone: String, email: String, address: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var sector by remember { mutableStateOf("Commercial Banking") }
    var contactPerson by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("+256 ") }
    var email by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }

    var errorMsg by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, VmlGold)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(VmlGoldDim),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Business, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Add Banking / Corporate Client",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlTextPrimary
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = VmlSlate)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Creates an independent portfolio section and links assigned debtors, balances, and reports.",
                    fontSize = 10.sp,
                    color = VmlSlate,
                    lineHeight = 14.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errorMsg = null },
                    label = { Text("Client Institution Name (e.g. Centenary Bank) *", fontSize = 10.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it; errorMsg = null },
                        label = { Text("Code (e.g. CER) *", fontSize = 10.sp) },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = sector,
                        onValueChange = { sector = it; errorMsg = null },
                        label = { Text("Sector *", fontSize = 10.sp) },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = contactPerson,
                    onValueChange = { contactPerson = it; errorMsg = null },
                    label = { Text("Contact Person / Manager", fontSize = 10.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it; errorMsg = null },
                        label = { Text("Phone (+256...) *", fontSize = 10.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it; errorMsg = null },
                        label = { Text("Email *", fontSize = 10.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it; errorMsg = null },
                    label = { Text("Headquarters Address", fontSize = 10.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMsg != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = errorMsg!!, color = VmlRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("Cancel", color = VmlSlate, fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.trim().isBlank()) {
                                errorMsg = "Institution name cannot be blank."
                                return@Button
                            }
                            onAddClient(name, code, sector, contactPerson, phone, email, address)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                    ) {
                        Text("Create Client Section", color = VmlNavyDark, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

// ==========================================
// SHARED HELPER COMPOSABLES
// ==========================================

@Composable
fun MetricPill(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, fontSize = 14.sp, fontWeight = FontWeight.Black, color = color)
        Text(text = label, fontSize = 9.sp, color = VmlSlate)
    }
}

@Composable
fun ActionCard(
    title: String,
    value: String,
    label: String,
    icon: ImageVector,
    color: Color,
    bgColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = VmlNavySurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(bgColor),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(13.dp)
                    )
                }
                Text(
                    text = value,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = color
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = VmlTextPrimary
            )
            Text(
                text = label,
                fontSize = 9.sp,
                color = VmlSlate
            )
        }
    }
}

@Composable
fun AgeingBarItem(
    bucket: String,
    amount: String,
    recoveryProbability: Float,
    barColor: Color,
    strategy: String
) {
    Column(modifier = Modifier.padding(vertical = 3.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = bucket,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = VmlTextPrimary
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "• $strategy",
                    fontSize = 9.sp,
                    color = VmlSlate
                )
            }
            Text(
                text = amount,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = barColor
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        LinearProgressIndicator(
            progress = { recoveryProbability },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp)),
            color = barColor,
            trackColor = VmlNavyDark
        )
    }
}

@Composable
fun PriorityCaseCard(
    caseItem: CaseEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("case_item_${caseItem.caseId}"),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = caseItem.caseId,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGoldLight
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    StatusBadge(caseItem.status)
                }

                Text(
                    text = formatUgxShort(caseItem.outstandingBalance),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = VmlRed
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = caseItem.debtorName,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = VmlTextPrimary
            )

            Text(
                text = "${caseItem.creditorName} • ${caseItem.debtorEmployer}",
                fontSize = 10.sp,
                color = VmlSlate
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Gavel,
                        contentDescription = null,
                        tint = VmlGold,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Stage: ${caseItem.legalStage.replace("_", " ")}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = VmlGoldLight
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${String.format("%.0f", caseItem.recoveryPercentage)}% paid",
                        fontSize = 10.sp,
                        color = VmlGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Details",
                        tint = VmlSlate,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
