package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Virgin Markets Multi Legal — Harmonious Creamish-Grey & Executive Bronze Theme

// 1. Primary Creamish-Grey Canvas & Surfaces
val VmlCreamGreyBackground = Color(0xFFEBE6DF) // Primary canvas: Elegant warm creamish grey
val VmlCreamGreySurface = Color(0xFFFFFFFF)    // Card containers: Crisp white for optimal contrast
val VmlCreamGreyElevated = Color(0xFFFAF8F5)   // Elevated cards / panels: Soft warm white
val VmlCreamGreyBorder = Color(0xFFD2CBC0)     // Defined stone borders around every card & container
val VmlCreamGreyDivider = Color(0xFFDFD9CE)    // Subtle section dividers
val VmlCreamGreyBar = Color(0xFFE3DED6)        // App bars and navigation bars background

// 2. Mapped Aliases for app-wide layout bindings
val VmlNavy = Color(0xFFE3DED6)
val VmlNavyDark = Color(0xFFEBE6DF)    // Primary background: Creamish grey canvas
val VmlNavySurface = Color(0xFFFFFFFF) // Primary card surface: Crisp white for high readability
val VmlNavyBorder = Color(0xFFD2CBC0)  // Primary card border: Sharp warm stone outline

// 3. Ultra High-Contrast Typography for Creamish-Grey & White (WCAG AAA compliant)
val VmlTextPrimary = Color(0xFF14110F)   // Deepest espresso charcoal: 100% visible & readable everywhere
val VmlTextSecondary = Color(0xFF453E38) // Crisp slate charcoal for descriptions & secondary text
val VmlSlate = Color(0xFF5A524A)         // Subtitles, metadata & timestamp labels
val VmlSlateLight = Color(0xFF70675E)    // Tertiary subtle text
val VmlWhite = Color(0xFFFFFFFF)
val VmlBackgroundLight = Color(0xFFEBE6DF)
val VmlSurfaceLight = Color(0xFFFFFFFF)
val VmlTextDark = Color(0xFF14110F)

// 4. Judicial & Legal Accents (Rich Executive Cognac Gold & Warm Bronze)
val VmlGold = Color(0xFF8F5312)       // Rich legal bronze gold accent for buttons & active states
val VmlGoldLight = Color(0xFF75430B)  // High-contrast deep bronze-gold for text, badges & icons
val VmlGoldDim = Color(0xFFF6EBDD)    // Warm cream-bronze badge container

// 5. Functional Status Indicators (High-contrast on Creamish-Grey & White)
val VmlGreen = Color(0xFF146C36)          // Recovered / Settled: Deep forest green
val VmlGreenContainer = Color(0xFFDCFCE7)  // Soft green badge background
val VmlRed = Color(0xFFB91C1C)            // Critical / Defaulted: Crimson red
val VmlRedContainer = Color(0xFFFEE2E2)    // Soft red badge background
val VmlAmber = Color(0xFF92400E)          // PTP / Warning: Deep warm amber
val VmlAmberContainer = Color(0xFFFEF3C7)  // Soft amber badge background
val VmlBlue = Color(0xFF1D4ED8)           // Active / Litigation: Deep cobalt blue
val VmlBlueContainer = Color(0xFFDBEAFE)   // Soft blue badge background
