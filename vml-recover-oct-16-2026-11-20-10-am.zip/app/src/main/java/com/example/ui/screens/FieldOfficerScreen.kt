package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FieldVisitEntity
import com.example.ui.components.formatUgxShort
import com.example.ui.theme.VmlBlue
import com.example.ui.theme.VmlBlueContainer
import com.example.ui.theme.VmlGold
import com.example.ui.theme.VmlGoldDim
import com.example.ui.theme.VmlGoldLight
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlGreenContainer
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlSlate
import com.example.ui.theme.VmlTextPrimary
import com.example.ui.theme.VmlTextSecondary
import com.example.viewmodel.VmlViewModel

@Composable
fun FieldOfficerScreen(
    viewModel: VmlViewModel,
    onNavigateToCase: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val visits by viewModel.allVisits.collectAsState()
    val cases by viewModel.allCases.collectAsState()

    val myAssignedCases = cases.filter { it.assignedOfficerName.contains("David", ignoreCase = true) || it.status == "ACTIVE" }
    val assignedDebt = myAssignedCases.sumOf { it.totalDebt }
    val recoveredDebt = myAssignedCases.sumOf { it.amountPaid }

    var selectedVisitForCheckIn by remember { mutableStateOf<FieldVisitEntity?>(null) }
    var checkInOutcome by remember { mutableStateOf("") }
    var checkInNextAction by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(VmlNavyDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Officer Performance Badge
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(VmlGoldDim),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "OFFICER DAVID OCHIENG",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Black,
                                    color = VmlTextPrimary
                                )
                                Text(
                                    text = "ID: OFF-001 • Kampala Central Operations",
                                    fontSize = 10.sp,
                                    color = VmlSlate
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Assigned Portfolio", fontSize = 11.sp, color = VmlSlate)
                            Text(text = formatUgxShort(assignedDebt), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "Recovered", fontSize = 11.sp, color = VmlSlate)
                            Text(text = formatUgxShort(recoveredDebt), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = VmlGreen)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Active Cases", fontSize = 11.sp, color = VmlSlate)
                            Text(text = "${myAssignedCases.size} Accounts", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = VmlGoldLight)
                        }
                    }
                }
            }
        }

        // Compliance Guarantee Box
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(VmlGreenContainer)
                    .border(1.dp, VmlGreen, RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = VmlGreen, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "FAIR COLLECTION CODE ENFORCED",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlGreen
                        )
                        Text(
                            text = "Every physical visit records GPS timestamp and verified lawful evidence. Abusive practices strictly prohibited.",
                            fontSize = 10.sp,
                            color = Color(0xFFD1FAE5)
                        )
                    }
                }
            }
        }

        // Field Visit Route Section
        item {
            Text(
                text = "SCHEDULED FIELD VISITS & PREMISES INSPECTION",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = VmlGoldLight,
                letterSpacing = 1.sp
            )
        }

        items(visits) { visit ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToCase(visit.caseId) },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = visit.caseId,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlGoldLight
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "• ${visit.scheduledDate}",
                                fontSize = 11.sp,
                                color = VmlSlate
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (visit.status == "COMPLETED") VmlGreenContainer else VmlBlueContainer)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = visit.status,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (visit.status == "COMPLETED") VmlGreen else VmlBlue
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = visit.debtorName, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = VmlSlate, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = visit.address, fontSize = 11.sp, color = VmlSlate)
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Objective: ${visit.outcome}", fontSize = 11.sp, color = VmlTextSecondary)

                    if (visit.status != "COMPLETED") {
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                selectedVisitForCheckIn = visit
                                checkInOutcome = "Premises visited. Debtor representative present. Trading books confirmed."
                                checkInNextAction = "Obtain formal settlement deed within 48h."
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = VmlGreen),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Check-In & Complete Visit", fontSize = 11.sp, color = Color.White)
                        }
                    }
                }
            }
        }

        // Inline Check-in Dialog/Form if selected
        if (selectedVisitForCheckIn != null) {
            val visit = selectedVisitForCheckIn!!
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlGreen)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "CHECK-IN AT PREMISES: ${visit.debtorName}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlGreen
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = checkInOutcome,
                            onValueChange = { checkInOutcome = it },
                            label = { Text("Visit Outcome / Debtor Statement") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = VmlGreen,
                                unfocusedBorderColor = VmlNavyBorder,
                                focusedTextColor = VmlTextPrimary,
                                unfocusedTextColor = VmlTextPrimary
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = checkInNextAction,
                            onValueChange = { checkInNextAction = it },
                            label = { Text("Next Action / Recommendation") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = VmlGreen,
                                unfocusedBorderColor = VmlNavyBorder,
                                focusedTextColor = VmlTextPrimary,
                                unfocusedTextColor = VmlTextPrimary
                            )
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Button(
                                onClick = { selectedVisitForCheckIn = null },
                                colors = ButtonDefaults.buttonColors(containerColor = VmlNavySurface)
                            ) {
                                Text("Cancel", color = VmlSlate)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    viewModel.completeFieldVisit(visit, checkInOutcome, checkInNextAction)
                                    selectedVisitForCheckIn = null
                                    Toast.makeText(context, "Visit checked in and logged to audit trail!", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = VmlGreen)
                            ) {
                                Text("Submit Verified Outcome", color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}
