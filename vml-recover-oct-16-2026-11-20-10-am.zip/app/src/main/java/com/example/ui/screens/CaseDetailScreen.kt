package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Print
import com.example.ui.components.PrintUtils
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CaseEntity
import com.example.data.model.FieldVisitEntity
import com.example.data.model.LegalDocumentEntity
import com.example.data.model.PaymentPlanEntity
import com.example.data.model.PaymentTransactionEntity
import com.example.data.model.PromiseToPayEntity
import com.example.ui.components.AuditTimelineItem
import com.example.ui.components.LegalStageStepper
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatUgxShort
import com.example.ui.theme.VmlAmber
import com.example.ui.theme.VmlAmberContainer
import com.example.ui.theme.VmlBlue
import com.example.ui.theme.VmlBlueContainer
import com.example.ui.theme.VmlCreamGreyElevated
import com.example.ui.theme.VmlGold
import com.example.ui.theme.VmlGoldDim
import com.example.ui.theme.VmlGoldLight
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlGreenContainer
import com.example.ui.theme.VmlNavy
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlRedContainer
import com.example.ui.theme.VmlSlate
import com.example.ui.theme.VmlTextPrimary
import com.example.ui.theme.VmlTextSecondary
import com.example.viewmodel.AiBriefingMode
import com.example.viewmodel.VmlViewModel
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CaseDetailScreen(
    viewModel: VmlViewModel,
    onBack: () -> Unit,
    onOpenCallDialog: (String) -> Unit,
    onOpenPaymentDialog: (String) -> Unit,
    onOpenPromiseDialog: (String, String) -> Unit,
    onOpenEscalateDialog: (String, String) -> Unit,
    onOpenPlanDialog: (String, String, Double) -> Unit,
    onOpenVisitDialog: (String, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    val caseItem by viewModel.selectedCase.collectAsState()
    val timeline by viewModel.selectedCaseTimeline.collectAsState()
    val promises by viewModel.selectedCasePromises.collectAsState()
    val payments by viewModel.selectedCasePayments.collectAsState()
    val plans by viewModel.selectedCasePlans.collectAsState()
    val visits by viewModel.selectedCaseVisits.collectAsState()
    val legalDocs by viewModel.selectedCaseLegalDocs.collectAsState()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("Timeline", "PTP Promises", "Payment Plan", "Payments", "Legal & Court", "Field Visits", "AI Assistant")

    if (caseItem == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(VmlNavyDark),
            contentAlignment = Alignment.Center
        ) {
            Text(text = "Case not found or loading...", color = Color.White)
        }
        return
    }

    val item = caseItem!!

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(VmlNavyDark)
    ) {
        // Top Navigation Bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("btn_case_detail_back")) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = VmlGoldLight
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = item.caseId,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = VmlGoldLight
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        StatusBadge(item.status)
                    }
                    Text(
                        text = "Instructed by ${item.creditorName}",
                        fontSize = 11.sp,
                        color = VmlSlate
                    )
                }
            }
        }

        // Debt Financial Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column {
                            Text(
                                text = "OUTSTANDING BALANCE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlSlate,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = formatUgxShort(item.outstandingBalance),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = VmlRed
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "TOTAL CLAIM",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlSlate,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = formatUgxShort(item.totalDebt),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlTextPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { (item.recoveryPercentage / 100.0).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = VmlGreen,
                        trackColor = VmlNavyDark
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Breakdown Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        FinancialMiniPill("Principal", formatUgxShort(item.principalAmount), VmlTextPrimary)
                        FinancialMiniPill("Interest", formatUgxShort(item.interestAmount), VmlGoldLight)
                        FinancialMiniPill("Penalties", formatUgxShort(item.penaltiesAmount), VmlAmber)
                        FinancialMiniPill("Paid", formatUgxShort(item.amountPaid), VmlGreen)
                    }
                }
            }
        }

        // Legal Escalation Stage Stepper
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    LegalStageStepper(
                        currentStage = item.legalStage,
                        onStageClick = { nextStage ->
                            onOpenEscalateDialog(item.caseId, nextStage)
                        }
                    )
                }
            }
        }

        // Debtor & Creditor Information Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "DEBTOR PROFILE & EVIDENCE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlGoldLight,
                            letterSpacing = 1.sp
                        )
                        Row {
                            // Quick Call Button
                            IconButton(
                                onClick = {
                                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${item.debtorPhone}"))
                                    context.startActivity(intent)
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Phone, contentDescription = "Call", tint = VmlGreen, modifier = Modifier.size(18.dp))
                            }
                            // Quick SMS Button
                            IconButton(
                                onClick = {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("sms:${item.debtorPhone}"))
                                    context.startActivity(intent)
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Message, contentDescription = "SMS", tint = VmlBlue, modifier = Modifier.size(18.dp))
                            }
                        }
                    }

                    Text(
                        text = item.debtorName,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlTextPrimary
                    )
                    Text(
                        text = "National ID / Reg: ${item.debtorNationalId}",
                        fontSize = 11.sp,
                        color = VmlSlate
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    ProfileRow("Employer / Trade", item.debtorEmployer)
                    ProfileRow("Business Address", item.debtorAddress)
                    ProfileRow("Primary Contact", item.debtorPhone)
                    ProfileRow("Email", item.debtorEmail)
                    ProfileRow("Emergency Contact", item.debtorEmergencyContact)

                    Spacer(modifier = Modifier.height(10.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(VmlNavyBorder))
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "CREDITOR INSTRUCTION",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGoldLight,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    ProfileRow("Creditor Institution", item.creditorName)
                    ProfileRow("Account / Ref #", item.creditorAccountNumber)
                    ProfileRow("Original Agreement", item.originalAgreementRef)
                    ProfileRow("Supporting Security", item.supportingDocsNote)
                    ProfileRow("Assigned Officer", item.assignedOfficerName)
                }
            }
        }

        // Action Toolbar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { onOpenCallDialog(item.caseId) },
                    colors = ButtonDefaults.buttonColors(containerColor = VmlBlue),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("btn_log_call")
                ) {
                    Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Log Call", fontSize = 11.sp)
                }

                Button(
                    onClick = { onOpenPaymentDialog(item.caseId) },
                    colors = ButtonDefaults.buttonColors(containerColor = VmlGreen),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("btn_record_payment_case")
                ) {
                    Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Record Payment", fontSize = 11.sp)
                }

                Button(
                    onClick = { onOpenPromiseDialog(item.caseId, item.debtorName) },
                    colors = ButtonDefaults.buttonColors(containerColor = VmlAmber),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("btn_record_promise_case")
                ) {
                    Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Black)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add PTP", fontSize = 11.sp, color = Color.Black)
                }

                Button(
                    onClick = { onOpenEscalateDialog(item.caseId, item.legalStage) },
                    colors = ButtonDefaults.buttonColors(containerColor = VmlGoldDim),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
                ) {
                    Icon(Icons.Default.Gavel, contentDescription = null, modifier = Modifier.size(14.dp), tint = VmlGoldLight)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Escalate Stage", fontSize = 11.sp, color = VmlGoldLight)
                }

                Button(
                    onClick = { onOpenVisitDialog(item.caseId, item.debtorName, item.debtorAddress) },
                    colors = ButtonDefaults.buttonColors(containerColor = VmlNavySurface),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                ) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(14.dp), tint = VmlSlate)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Schedule Visit", fontSize = 11.sp, color = Color.White)
                }
            }
        }

        // Tab Navigation
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = VmlNavyDark,
                contentColor = VmlGoldLight,
                edgePadding = 16.dp,
                indicator = { tabPositions ->
                    SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = VmlGoldLight
                    )
                }
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 12.sp,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTabIndex == index) VmlGoldLight else VmlSlate
                            )
                        }
                    )
                }
            }
        }

        // Tab Content
        when (selectedTabIndex) {
            0 -> {
                // Timeline / Audit Trail
                item {
                    Text(
                        text = "CHRONOLOGICAL AUDIT TRAIL (${timeline.size} ENTRIES)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGoldLight,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                    )
                }
                if (timeline.isEmpty()) {
                    item {
                        Text(
                            text = "No audit actions recorded yet.",
                            fontSize = 12.sp,
                            color = VmlSlate,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                } else {
                    items(timeline) { action ->
                        Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                            AuditTimelineItem(action = action)
                        }
                    }
                }
            }
            1 -> {
                // Promises to Pay (PTP)
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PROMISE TO PAY (PTP) SYSTEM",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlGoldLight,
                            letterSpacing = 1.sp
                        )
                        Button(
                            onClick = { onOpenPromiseDialog(item.caseId, item.debtorName) },
                            colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("New Promise", fontSize = 10.sp, color = VmlNavyDark, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (promises.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("No promises recorded yet.", color = VmlSlate, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = { onOpenPromiseDialog(item.caseId, item.debtorName) },
                                    colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                                ) {
                                    Text("Record First Promise", color = VmlNavyDark)
                                }
                            }
                        }
                    }
                } else {
                    items(promises) { promise ->
                        PromiseCardItem(
                            promise = promise,
                            onDefaultClick = {
                                viewModel.markPromiseDefaulted(promise, "Debtor failed to pay agreed funds by deadline.")
                            },
                            onFulfillClick = {
                                viewModel.markPromiseFulfilled(promise)
                            }
                        )
                    }
                }
            }
            2 -> {
                // Payment Plan Engine
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "STRUCTURED PAYMENT PLANS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlGoldLight,
                            letterSpacing = 1.sp
                        )
                        Button(
                            onClick = { onOpenPlanDialog(item.caseId, item.debtorName, item.outstandingBalance) },
                            colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("Generate Plan", fontSize = 10.sp, color = VmlNavyDark, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (plans.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("No payment plan currently structured for this case.", color = VmlSlate, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = { onOpenPlanDialog(item.caseId, item.debtorName, item.outstandingBalance) },
                                    colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                                ) {
                                    Text("Structure 4-Instalment Repayment Plan", color = VmlNavyDark, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                } else {
                    items(plans) { plan ->
                        PaymentPlanCardItem(plan = plan)
                    }
                }
            }
            3 -> {
                // Payments History
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "RECEIPTED PAYMENTS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlGoldLight,
                            letterSpacing = 1.sp
                        )
                        Button(
                            onClick = { onOpenPaymentDialog(item.caseId) },
                            colors = ButtonDefaults.buttonColors(containerColor = VmlGreen),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("Log Payment", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (payments.isEmpty()) {
                    item {
                        Text(
                            text = "No payments logged on this case yet.",
                            fontSize = 12.sp,
                            color = VmlSlate,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                } else {
                    items(payments) { payment ->
                        PaymentTransactionCardItem(payment = payment)
                    }
                }
            }
            4 -> {
                // Legal & Court Documents
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LEGAL DOCUMENTS & COURT PROCEEDINGS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlGoldLight,
                            letterSpacing = 1.sp
                        )
                    }
                }
                if (legalDocs.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "No formal legal pleadings or demand notices filed yet.",
                                    color = VmlSlate,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        viewModel.generateLegalDocument(
                                            caseId = item.caseId,
                                            docType = "DEMAND_LETTER",
                                            title = "Statutory 7-Day Demand Notice for UGX ${formatUgxShort(item.outstandingBalance)}",
                                            content = "Formal notice demanding settlement within 7 days under Ugandan Commercial Court practice directives."
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                                ) {
                                    Text("Issue Statutory Demand Letter", color = VmlNavyDark, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                } else {
                    items(legalDocs) { doc ->
                        LegalDocCardItem(doc = doc, caseItem = item)
                    }
                }
            }
            5 -> {
                // Field Visits
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "FIELD OFFICER VISITS & INSPECTIONS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlGoldLight,
                            letterSpacing = 1.sp
                        )
                        Button(
                            onClick = { onOpenVisitDialog(item.caseId, item.debtorName, item.debtorAddress) },
                            colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("Schedule Visit", fontSize = 10.sp, color = VmlNavyDark, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (visits.isEmpty()) {
                    item {
                        Text(
                            text = "No field visits scheduled for this debtor.",
                            fontSize = 12.sp,
                            color = VmlSlate,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                } else {
                    items(visits) { visit ->
                        FieldVisitCardItem(
                            visit = visit,
                            onComplete = { outcome, next ->
                                viewModel.completeFieldVisit(visit, outcome, next)
                            }
                        )
                    }
                }
            }
            6 -> {
                // AI Recovery Assistant
                item {
                    AiAssistantTabContent(caseItem = item, viewModel = viewModel)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
fun ProfileRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 11.sp, color = VmlSlate, modifier = Modifier.weight(1f))
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = VmlTextPrimary,
            modifier = Modifier.weight(1.4f)
        )
    }
}

@Composable
fun FinancialMiniPill(label: String, amount: String, color: Color) {
    Column {
        Text(text = label, fontSize = 9.sp, color = VmlSlate)
        Text(text = amount, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
fun PromiseCardItem(
    promise: PromiseToPayEntity,
    onDefaultClick: () -> Unit,
    onFulfillClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (promise.status == "DEFAULTED") VmlRed else VmlNavyBorder
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "PROMISED: ${formatUgxShort(promise.promisedAmount)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = VmlTextPrimary
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            when (promise.status) {
                                "PENDING" -> VmlAmberContainer
                                "FULFILLED" -> VmlGreenContainer
                                "DEFAULTED" -> VmlRedContainer
                                else -> VmlNavyDark
                            }
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = promise.status,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (promise.status) {
                            "PENDING" -> VmlAmber
                            "FULFILLED" -> VmlGreen
                            "DEFAULTED" -> VmlRed
                            else -> VmlSlate
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Target Date: ${promise.promiseDate} • Via ${promise.paymentMethod}", fontSize = 11.sp, color = VmlGoldLight)
            Text(text = "Officer: ${promise.officerName}", fontSize = 10.sp, color = VmlSlate)

            if (promise.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = promise.notes, fontSize = 11.sp, color = Color(0xFFCBD5E1))
            }

            if (promise.status == "PENDING") {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = onDefaultClick,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = VmlRed),
                        border = androidx.compose.foundation.BorderStroke(1.dp, VmlRed),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("Mark Defaulted", fontSize = 10.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onFulfillClick,
                        colors = ButtonDefaults.buttonColors(containerColor = VmlGreen),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("Mark Fulfilled", fontSize = 10.sp, color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun PaymentPlanCardItem(plan: PaymentPlanEntity) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AGREED SUM: ${formatUgxShort(plan.totalAgreedAmount)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = VmlGoldLight
                )
                Text(
                    text = "${plan.numberOfInstalments} Instalments (${plan.frequency})",
                    fontSize = 11.sp,
                    color = VmlSlate
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Parse Instalments JSON
            val instalments = remember(plan.instalmentsJson) {
                val list = mutableListOf<Triple<String, Double, String>>()
                try {
                    val array = JSONArray(plan.instalmentsJson)
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        list.add(
                            Triple(
                                obj.optString("date", "Instalment #${i + 1}"),
                                obj.optDouble("amount", 0.0),
                                obj.optString("status", "PENDING")
                            )
                        )
                    }
                } catch (e: Exception) {
                    list.add(Triple(plan.startDate, plan.totalAgreedAmount, "ACTIVE"))
                }
                list
            }

            // Table header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(VmlNavyDark)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Date", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VmlSlate, modifier = Modifier.weight(1f))
                Text("Instalment", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VmlSlate, modifier = Modifier.weight(1f))
                Text("Status", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VmlSlate, modifier = Modifier.weight(0.8f))
            }

            instalments.forEach { (date, amount, status) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(date, fontSize = 11.sp, color = VmlTextPrimary, modifier = Modifier.weight(1f))
                    Text(formatUgxShort(amount), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary, modifier = Modifier.weight(1f))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (status == "PAID") VmlGreenContainer else VmlAmberContainer)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = status,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (status == "PAID") VmlGreen else VmlAmber
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PaymentTransactionCardItem(payment: PaymentTransactionEntity) {
    val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
    val dateStr = sdf.format(Date(payment.paymentDate))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, VmlGreen.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Receipt, contentDescription = null, tint = VmlGreen, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = payment.receiptNumber,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGoldLight
                    )
                }
                Text(
                    text = formatUgxShort(payment.amount),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = VmlGreen
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Channel: ${payment.paymentChannel} • Recorded by ${payment.recordedBy}", fontSize = 11.sp, color = VmlSlate)
            Text(text = dateStr, fontSize = 10.sp, color = VmlSlate)
            if (payment.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = payment.notes, fontSize = 11.sp, color = VmlTextSecondary)
            }
        }
    }
}

@Composable
fun LegalDocCardItem(doc: LegalDocumentEntity, caseItem: CaseEntity? = null) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, VmlGoldDim)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Gavel, contentDescription = null, tint = VmlGold, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = doc.docType.replace("_", " "),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGoldLight
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(VmlGoldDim)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(text = doc.status, fontSize = 10.sp, color = VmlGoldLight, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(text = doc.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)

            if (doc.courtReference != null) {
                Text(text = "Ref / Suit: ${doc.courtReference}", fontSize = 11.sp, color = VmlSlate)
            }
            if (doc.courtDate != null) {
                Text(text = "Court Date: ${doc.courtDate}", fontSize = 11.sp, color = VmlAmber, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(10.dp))
            val ctx = LocalContext.current
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Button(
                    onClick = {
                        val html = PrintUtils.generateLegalNoticeHtml(doc, caseItem)
                        PrintUtils.printDocument(ctx, "LegalNotice_${doc.caseId}", html)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Default.Print, contentDescription = "Print Document", tint = VmlNavyDark, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Print Document", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlNavyDark)
                }
            }
            Text(text = "Advocate: ${doc.assignedAdvocate} • Issued: ${doc.generatedDate}", fontSize = 10.sp, color = VmlSlate)

            Spacer(modifier = Modifier.height(6.dp))
            Text(text = doc.contentSummary, fontSize = 11.sp, color = VmlTextSecondary, lineHeight = 15.sp)
        }
    }
}

@Composable
fun FieldVisitCardItem(
    visit: FieldVisitEntity,
    onComplete: (outcome: String, nextAction: String) -> Unit
) {
    var outcomeInput by remember { mutableStateOf("") }
    var showCompleteBox by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = VmlGold, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = visit.scheduledDate, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (visit.status == "COMPLETED") VmlGreenContainer else VmlBlueContainer)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = visit.status,
                        fontSize = 10.sp,
                        color = if (visit.status == "COMPLETED") VmlGreen else VmlBlue,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "Premises: ${visit.address}", fontSize = 12.sp, color = VmlTextPrimary)
            Text(text = "Officer: ${visit.officerName}", fontSize = 11.sp, color = VmlSlate)
            Text(text = "Outcome: ${visit.outcome}", fontSize = 11.sp, color = VmlGoldLight)

            if (visit.status != "COMPLETED") {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        onComplete(
                            "Physical inspection conducted. Debtor verified trading at premises.",
                            "Follow up on signed acknowledgment within 48 hours."
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VmlGreen),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("Check In & Complete Visit", fontSize = 11.sp, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun AiAssistantTabContent(
    caseItem: CaseEntity,
    viewModel: VmlViewModel
) {
    var generatedText by remember {
        mutableStateOf(viewModel.generateAiRecoveryBriefing(caseItem, AiBriefingMode.CASE_SUMMARY))
    }
    var activeMode by remember { mutableStateOf(AiBriefingMode.CASE_SUMMARY) }

    Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = VmlGold, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "AI RECOVERY ASSISTANT",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = VmlGoldLight
                )
                Text(
                    text = "Case intelligence, pre-call briefs, and statutory pleadings",
                    fontSize = 10.sp,
                    color = VmlSlate
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Mode Selector Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    activeMode = AiBriefingMode.CASE_SUMMARY
                    generatedText = viewModel.generateAiRecoveryBriefing(caseItem, AiBriefingMode.CASE_SUMMARY)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeMode == AiBriefingMode.CASE_SUMMARY) VmlGold else VmlCreamGreyElevated
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (activeMode == AiBriefingMode.CASE_SUMMARY) VmlGold else VmlNavyBorder),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    "Case Summary",
                    fontSize = 11.sp,
                    color = if (activeMode == AiBriefingMode.CASE_SUMMARY) Color.White else VmlTextPrimary
                )
            }

            Button(
                onClick = {
                    activeMode = AiBriefingMode.CALL_BRIEFING
                    generatedText = viewModel.generateAiRecoveryBriefing(caseItem, AiBriefingMode.CALL_BRIEFING)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeMode == AiBriefingMode.CALL_BRIEFING) VmlGold else VmlCreamGreyElevated
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (activeMode == AiBriefingMode.CALL_BRIEFING) VmlGold else VmlNavyBorder),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    "Call Briefing",
                    fontSize = 11.sp,
                    color = if (activeMode == AiBriefingMode.CALL_BRIEFING) Color.White else VmlTextPrimary
                )
            }

            Button(
                onClick = {
                    activeMode = AiBriefingMode.LEGAL_DEMAND_DRAFT
                    generatedText = viewModel.generateAiRecoveryBriefing(caseItem, AiBriefingMode.LEGAL_DEMAND_DRAFT)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeMode == AiBriefingMode.LEGAL_DEMAND_DRAFT) VmlGold else VmlCreamGreyElevated
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (activeMode == AiBriefingMode.LEGAL_DEMAND_DRAFT) VmlGold else VmlNavyBorder),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    "Demand Letter",
                    fontSize = 11.sp,
                    color = if (activeMode == AiBriefingMode.LEGAL_DEMAND_DRAFT) Color.White else VmlTextPrimary
                )
            }

            Button(
                onClick = {
                    activeMode = AiBriefingMode.NEGOTIATION_STRATEGY
                    generatedText = viewModel.generateAiRecoveryBriefing(caseItem, AiBriefingMode.NEGOTIATION_STRATEGY)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeMode == AiBriefingMode.NEGOTIATION_STRATEGY) VmlGold else VmlCreamGreyElevated
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (activeMode == AiBriefingMode.NEGOTIATION_STRATEGY) VmlGold else VmlNavyBorder),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    "Negotiation Strategy",
                    fontSize = 11.sp,
                    color = if (activeMode == AiBriefingMode.NEGOTIATION_STRATEGY) Color.White else VmlTextPrimary
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Display AI Generated Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, VmlGoldDim)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = generatedText,
                    fontSize = 12.sp,
                    color = VmlTextPrimary,
                    lineHeight = 18.sp,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                )
            }
        }
    }
}
