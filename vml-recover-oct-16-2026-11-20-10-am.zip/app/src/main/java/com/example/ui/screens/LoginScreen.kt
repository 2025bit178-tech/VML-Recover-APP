package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.AccountLockedSecurityException
import com.example.data.model.InvalidCredentialsException
import com.example.data.model.MaxAttemptsExceededException
import com.example.data.model.SystemLockdownException
import com.example.data.model.UserEntity
import com.example.data.model.VmlSecurityException
import com.example.ui.theme.VmlAmber
import com.example.ui.theme.VmlAmberContainer
import com.example.ui.theme.VmlBlue
import com.example.ui.theme.VmlBlueContainer
import com.example.ui.theme.VmlCreamGreyElevated
import com.example.ui.theme.VmlGold
import com.example.ui.theme.VmlGoldDim
import com.example.ui.theme.VmlGoldLight
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlGreenContainer
import com.example.ui.theme.VmlNavy
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlRedContainer
import com.example.ui.theme.VmlSlate
import com.example.ui.theme.VmlSlateLight
import com.example.ui.theme.VmlTextPrimary
import com.example.viewmodel.VmlViewModel

data class DemoRoleCredential(
    val title: String,
    val roleBadge: String,
    val email: String,
    val description: String,
    val badgeColor: Color,
    val badgeBg: Color
)

@Composable
fun LoginScreen(
    viewModel: VmlViewModel,
    modifier: Modifier = Modifier
) {
    val loginError by viewModel.loginError.collectAsState()
    val loginException by viewModel.loginException.collectAsState()
    val isAccountLockedOut by viewModel.isAccountLockedOut.collectAsState()
    val lockedOutUser by viewModel.lockedOutUser.collectAsState()
    val isAuthenticating by viewModel.isAuthenticating.collectAsState()
    val latestSmsToast by viewModel.latestSmsToast.collectAsState()
    val systemConfig by viewModel.systemConfig.collectAsState()
    val focusManager = LocalFocusManager.current

    var identifier by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var showOverrideDialog by remember { mutableStateOf(false) }
    var overridePasswordInput by remember { mutableStateOf("") }
    var overrideErrorMsg by remember { mutableStateOf<String?>(null) }

    // Critical Security Lockdown Dialog
    if (isAccountLockedOut) {
        Dialog(onDismissRequest = { viewModel.clearLoginError() }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, VmlRed)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(VmlRedContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Security Lockdown",
                            tint = VmlRed,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "ACCOUNT LOCKED ITSELF",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        color = VmlRed,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Exception: MaxAttemptsExceededException",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGoldLight
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(VmlNavySurface)
                            .border(1.dp, VmlRed.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(
                                text = loginError ?: "Multiple invalid credentials input attempts detected. Security threshold triggered.",
                                fontSize = 12.sp,
                                color = VmlTextPrimary,
                                lineHeight = 16.sp
                            )
                            if (lockedOutUser != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Target Account: ${lockedOutUser!!.fullName} (${lockedOutUser!!.email})",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VmlGoldLight
                                )
                                Text(
                                    text = "SMS Security Alert sent to: ${lockedOutUser!!.phoneNumber}",
                                    fontSize = 10.sp,
                                    color = VmlGreen
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "SECURITY POLICY:\nOnly the System Administrator logged into the Admin Level can unlock your account and allow you back in.",
                        fontSize = 11.sp,
                        color = VmlSlate,
                        fontWeight = FontWeight.Medium,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { viewModel.clearLoginError() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = VmlRed)
                    ) {
                        Text("Acknowledge & Close", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    if (lockedOutUser?.role.equals("ADMIN", ignoreCase = true) || lockedOutUser?.email == "admin@vmlrecover.ug") {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                showOverrideDialog = true
                                overrideErrorMsg = null
                                overridePasswordInput = "1234"
                            },
                            modifier = Modifier.fillMaxWidth(),
                            border = androidx.compose.foundation.BorderStroke(1.dp, VmlGoldLight),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = VmlGoldLight)
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Use Emergency Password (1234) to Recover", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    TextButton(
                        onClick = {
                            viewModel.unlockAllAccounts()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Clear All Lockouts & Reset Access", fontSize = 11.sp, color = VmlGold)
                    }
                }
            }
        }
    }

    // Role profiles list: Company and Individual logins removed and replaced with unified Client Login option

    // Emergency Admin Override Modal Dialog
    if (showOverrideDialog) {
        Dialog(onDismissRequest = { showOverrideDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, VmlGold)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(VmlGoldDim),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "ADMIN OVERRIDE RECOVERY",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = VmlGoldLight,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Emergency Password: 1234",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlTextPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "POLICY: Emergency password (1234) is valid ONLY for the Admin account when the account is closed/locked out due to forgotten credentials.",
                        fontSize = 11.sp,
                        color = VmlSlate,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = overridePasswordInput,
                        onValueChange = {
                            overridePasswordInput = it
                            overrideErrorMsg = null
                        },
                        label = { Text("Emergency Password (1234)", fontSize = 11.sp) },
                        placeholder = { Text("1234", color = VmlSlate) },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = VmlGoldLight) },
                        trailingIcon = {
                            TextButton(onClick = { overridePasswordInput = "1234"; overrideErrorMsg = null }) {
                                Text("Fill 1234", fontSize = 10.sp, color = VmlGold)
                            }
                        },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (overrideErrorMsg != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = overrideErrorMsg!!,
                            color = VmlRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (overrideErrorMsg!!.contains("closed / locked out")) {
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    viewModel.lockAdminAccountForEmergency { ok, msg ->
                                        overrideErrorMsg = msg
                                        overridePasswordInput = "1234"
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                border = androidx.compose.foundation.BorderStroke(1.dp, VmlRed)
                            ) {
                                Text("Close Admin Account Now to Use 1234", color = VmlRed, fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(onClick = { showOverrideDialog = false }) {
                            Text("Cancel", color = VmlSlate)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                viewModel.overrideLoginAdmin(overridePasswordInput) { success, msg ->
                                    if (success) {
                                        showOverrideDialog = false
                                    } else {
                                        overrideErrorMsg = msg
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                        ) {
                            Text("Unlock & Login (1234)", color = VmlNavyDark, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    val demoRoles = listOf(
        DemoRoleCredential(
            title = "Administrator",
            roleBadge = "ADMIN",
            email = "admin@vmlrecover.ug",
            description = "Complete control, user management, password authority & system audit trail",
            badgeColor = VmlGoldLight,
            badgeBg = VmlGoldDim
        ),
        DemoRoleCredential(
            title = "Director: Portfolio & Performance Only",
            roleBadge = "DIRECTOR",
            email = "director@vmlrecover.ug",
            description = "Executive command overview & 10 operational performance dimensions only",
            badgeColor = VmlGoldLight,
            badgeBg = VmlGoldDim
        ),
        DemoRoleCredential(
            title = "Collection Manager: Allocation & Supervision",
            roleBadge = "MANAGER",
            email = "manager@vmlrecover.ug",
            description = "Case allocation engine, supervisory workload & officer oversight",
            badgeColor = VmlBlue,
            badgeBg = VmlBlueContainer
        ),
        DemoRoleCredential(
            title = "Collection Officer: Calls, Visits, PTP & Payments",
            roleBadge = "OFFICER",
            email = "collector@vmlrecover.ug",
            description = "Assigned debtor calls, premise visits, promises to pay & payments",
            badgeColor = VmlBlue,
            badgeBg = VmlBlueContainer
        ),
        DemoRoleCredential(
            title = "Legal Officer: Legal Escalation & Litigation",
            roleBadge = "LEGAL",
            email = "legal@vmlrecover.ug",
            description = "9-stage escalation pipeline, High Court litigation & warrants of attachment",
            badgeColor = VmlGoldLight,
            badgeBg = VmlGoldDim
        ),
        DemoRoleCredential(
            title = "Finance Officer: Payments & Reconciliation",
            roleBadge = "FINANCE",
            email = "finance@vmlrecover.ug",
            description = "Assigned ledgers, payment streams & bank clearing reconciliation",
            badgeColor = VmlGreen,
            badgeBg = VmlGreenContainer
        ),
        DemoRoleCredential(
            title = "Client Login: Connect Database of Client & Assigned Debtors",
            roleBadge = "CLIENT",
            email = "client@stanbic.co.ug",
            description = "Client portal: Connect database of client with debtors assigned to them, view and sort debtors according to bank, amount, loan aging, sector of work, legal case level (company or individual)",
            badgeColor = VmlGoldLight,
            badgeBg = VmlGoldDim
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(VmlNavyDark),
        contentAlignment = Alignment.Center
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 420.dp)
                .fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // System Lockdown Banner
            if (systemConfig?.isSystemLocked == true) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlRedContainer),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, VmlRed)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(VmlNavyDark),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = "Lockdown", tint = VmlRed, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "SYSTEM LOCKDOWN ACTIVE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = VmlRed,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "During the system lockdown period, only the Administrator can login. Access for other accounts is currently prohibited.",
                                fontSize = 11.sp,
                                color = VmlTextPrimary,
                                lineHeight = 15.sp
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "Reason: ${systemConfig!!.lockdownReason}",
                                fontSize = 10.sp,
                                color = VmlGoldLight
                            )
                        }
                    }
                }
            }
        }

        // Live SMS Notification Dispatch Banner
        if (latestSmsToast != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlGreen)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(VmlGreenContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Sms, contentDescription = null, tint = VmlGreen, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = "SMS DISPATCHED", fontSize = 10.sp, fontWeight = FontWeight.Black, color = VmlGreen)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "• ${latestSmsToast!!.eventType}", fontSize = 10.sp, color = VmlGoldLight)
                            }
                            Text(
                                text = "To: ${latestSmsToast!!.recipientPhone} (${latestSmsToast!!.recipientName})",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlTextPrimary
                            )
                            Text(
                                text = latestSmsToast!!.messageContent.replace("\n", " ").take(90) + if (latestSmsToast!!.messageContent.length > 90) "..." else "",
                                fontSize = 10.sp,
                                color = VmlSlate,
                                maxLines = 2
                            )
                        }
                        IconButton(onClick = { viewModel.dismissSmsToast() }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Check, contentDescription = "Dismiss SMS Banner", tint = VmlSlate, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
            // Brand Crest Header
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(VmlGold, VmlNavySurface)
                        )
                    )
                    .border(1.5.dp, VmlGold, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Gavel,
                    contentDescription = "VML Legal Crest",
                    tint = Color.White,
                    modifier = Modifier.size(38.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "VIRGIN MARKETS MULTI LEGAL",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = VmlGoldLight,
                letterSpacing = 1.8.sp
            )
            Text(
                text = "VML RECOVER",
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.2.sp,
                color = VmlTextPrimary
            )
            Text(
                text = "Recover. Resolve. Legally.",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = VmlSlate
            )
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Login Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SECURE PORTAL LOGIN",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlGoldLight,
                            letterSpacing = 1.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = VmlGreen, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "256-Bit Encrypted", fontSize = 10.sp, color = VmlGreen)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Identifier / Email field (Horizontal Layout)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Login ID / Email",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = VmlSlateLight,
                            modifier = Modifier.width(105.dp)
                        )
                        OutlinedTextField(
                            value = identifier,
                            onValueChange = {
                                identifier = it
                                viewModel.clearLoginError()
                            },
                            placeholder = { Text("Username or Ref #", color = VmlSlate.copy(alpha = 0.5f), fontSize = 13.sp) },
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(18.dp))
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Email,
                                imeAction = ImeAction.Next
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(54.dp)
                                .testTag("input_login_username"),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = VmlGold,
                                unfocusedBorderColor = VmlNavyBorder,
                                focusedContainerColor = VmlCreamGreyElevated,
                                unfocusedContainerColor = VmlCreamGreyElevated,
                                focusedTextColor = VmlTextPrimary,
                                unfocusedTextColor = VmlTextPrimary
                            ),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium, color = VmlTextPrimary)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Password field (Horizontal Layout)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Password",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = VmlSlateLight,
                            modifier = Modifier.width(105.dp)
                        )
                        OutlinedTextField(
                            value = password,
                            onValueChange = {
                                password = it
                                viewModel.clearLoginError()
                            },
                            placeholder = { Text("Password", color = VmlSlate.copy(alpha = 0.5f), fontSize = 13.sp) },
                            leadingIcon = {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(18.dp))
                            },
                            trailingIcon = {
                                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                    Icon(
                                        imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (passwordVisible) "Hide password" else "Show password",
                                        tint = VmlSlate,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            },
                            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Password,
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = {
                                    focusManager.clearFocus()
                                    viewModel.login(identifier, password)
                                }
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(54.dp)
                                .testTag("input_login_password"),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = VmlGold,
                                unfocusedBorderColor = VmlNavyBorder,
                                focusedContainerColor = VmlCreamGreyElevated,
                                unfocusedContainerColor = VmlCreamGreyElevated,
                                focusedTextColor = VmlTextPrimary,
                                unfocusedTextColor = VmlTextPrimary
                            ),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium, color = VmlTextPrimary)
                        )
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp, start = 4.dp, end = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Standard: admin or password",
                            fontSize = 11.sp,
                            color = VmlGoldLight,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Emergency: 1234 (Locked)",
                            fontSize = 11.sp,
                            color = VmlGold,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable {
                                showOverrideDialog = true
                                overridePasswordInput = "1234"
                            }
                        )
                    }

                    if (loginError != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(VmlRedContainer)
                                .border(1.dp, VmlRed, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = VmlRed, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    val exceptionName = loginException?.let { it::class.simpleName } ?: "AuthenticationException"
                                    Text(
                                        text = "EXCEPTION: $exceptionName",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black,
                                        color = VmlRed
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = loginError!!,
                                    fontSize = 11.sp,
                                    color = VmlTextPrimary,
                                    lineHeight = 15.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                if (loginError!!.contains("1234") || loginError!!.contains("closed / locked")) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                viewModel.lockAdminAccountForEmergency { ok, msg ->
                                                    showOverrideDialog = true
                                                    overridePasswordInput = "1234"
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = VmlRed),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("Close Account Now", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                        }
                                        Button(
                                            onClick = {
                                                password = "admin"
                                                viewModel.clearLoginError()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("Use Password 'admin'", fontSize = 10.sp, color = VmlNavyDark, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                } else if (loginException is AccountLockedSecurityException || loginException is MaxAttemptsExceededException) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "• Account has locked itself. Use emergency password 1234 to restore access.",
                                        fontSize = 10.sp,
                                        color = VmlGoldLight,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Sign In Button
                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            viewModel.login(identifier, password)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_submit_login"),
                        colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                        shape = RoundedCornerShape(10.dp),
                        enabled = !isAuthenticating
                    ) {
                        if (isAuthenticating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Authenticating...", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Text("Sign In to VML Workspace", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    // Admin Emergency Override Prompt (For Forgotten Password / Closed Account)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showOverrideDialog = true
                                overrideErrorMsg = null
                                overridePasswordInput = "1234"
                            },
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Admin Forgotten Password / Locked Out? Emergency Password (1234)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = VmlGoldLight
                        )
                    }
                }
            }
        }

        // Quick Role Login Credential Selector
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ROLE ACCESS PROFILES (SELECT USER IDENTIFIER)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGoldLight,
                        letterSpacing = 1.sp
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Select any role profile below to populate its login email. Debt collectors and client banking partners can access their assigned debtor portfolio under Client Login.",
                    fontSize = 11.sp,
                    color = VmlSlate
                )
            }
        }

        items(demoRoles) { roleItem ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        identifier = roleItem.email
                        password = "admin"
                        viewModel.clearLoginError()
                    }
                    .testTag("demo_role_${roleItem.roleBadge.lowercase()}"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (identifier == roleItem.email) VmlGold else VmlNavyBorder
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(roleItem.badgeBg)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = roleItem.roleBadge,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = roleItem.badgeColor
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = roleItem.title,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlTextPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "Account: ", fontSize = 11.sp, color = VmlSlate)
                            Text(text = roleItem.email, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = VmlGoldLight)
                        }

                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = roleItem.description,
                            fontSize = 11.sp,
                            color = VmlSlate,
                            lineHeight = 15.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Select Account",
                        tint = if (identifier == roleItem.email) VmlGold else VmlSlate,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
    }
}
