package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PromiseToPayEntity
import com.example.ui.components.formatUgxShort
import com.example.ui.theme.VmlAmber
import com.example.ui.theme.VmlAmberContainer
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlGreenContainer
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlRedContainer
import com.example.ui.theme.VmlSlate
import com.example.ui.theme.VmlTextPrimary
import com.example.viewmodel.VmlViewModel

@Composable
fun PromiseTrackerScreen(
    viewModel: VmlViewModel,
    onNavigateToCase: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val promises by viewModel.allPromises.collectAsState()

    var statusFilter by remember { mutableStateOf("ALL") }
    val filteredPromises = promises.filter {
        if (statusFilter == "ALL") true else it.status.equals(statusFilter, ignoreCase = true)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(VmlNavyDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Summary Header Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(VmlAmberContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Schedule, contentDescription = null, tint = VmlAmber, modifier = Modifier.size(18.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "PROMISE TO PAY MONITOR (PTP)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    color = VmlTextPrimary,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "Automated Payment & Default Tracking",
                                    fontSize = 10.sp,
                                    color = VmlSlate
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Pending Commitment", fontSize = 11.sp, color = VmlSlate)
                            Text(
                                text = formatUgxShort(promises.filter { it.status == "PENDING" }.sumOf { it.promisedAmount }),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlAmber
                            )
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "Defaulted", fontSize = 11.sp, color = VmlSlate)
                            Text(
                                text = "${promises.count { it.status == "DEFAULTED" }} Cases",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlRed
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Fulfilled", fontSize = 11.sp, color = VmlSlate)
                            Text(
                                text = formatUgxShort(promises.filter { it.status == "FULFILLED" }.sumOf { it.promisedAmount }),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlGreen
                            )
                        }
                    }
                }
            }
        }

        // Filters
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("ALL", "PENDING", "DEFAULTED", "FULFILLED").forEach { filter ->
                    val isSelected = statusFilter == filter
                    FilterChip(
                        selected = isSelected,
                        onClick = { statusFilter = filter },
                        label = { Text(filter, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = VmlAmber,
                            selectedLabelColor = Color.Black,
                            containerColor = VmlNavySurface,
                            labelColor = VmlSlate
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) VmlAmber else VmlNavyBorder
                        )
                    )
                }
            }
        }

        // List of Promises
        items(filteredPromises) { promise ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToCase(promise.caseId) },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (promise.status == "DEFAULTED") VmlRed else VmlNavyBorder
                )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = promise.caseId,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlTextPrimary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(
                                        when (promise.status) {
                                            "PENDING" -> VmlAmberContainer
                                            "FULFILLED" -> VmlGreenContainer
                                            "DEFAULTED" -> VmlRedContainer
                                            else -> VmlNavyDark
                                        }
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = promise.status,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (promise.status) {
                                        "PENDING" -> VmlAmber
                                        "FULFILLED" -> VmlGreen
                                        "DEFAULTED" -> VmlRed
                                        else -> VmlSlate
                                    }
                                )
                            }
                        }

                        Text(
                            text = formatUgxShort(promise.promisedAmount),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            color = when (promise.status) {
                                "PENDING" -> VmlAmber
                                "FULFILLED" -> VmlGreen
                                "DEFAULTED" -> VmlRed
                                else -> VmlTextPrimary
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = promise.debtorName,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlTextPrimary
                    )

                    Text(
                        text = "Due: ${promise.promiseDate} • Method: ${promise.paymentMethod}",
                        fontSize = 11.sp,
                        color = VmlSlate
                    )
                    Text(
                        text = "Officer: ${promise.officerName}",
                        fontSize = 10.sp,
                        color = VmlSlate
                    )

                    if (promise.notes.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = promise.notes,
                            fontSize = 11.sp,
                            color = Color(0xFFCBD5E1)
                        )
                    }

                    if (promise.status == "DEFAULTED") {
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(VmlRedContainer)
                                .border(1.dp, VmlRed, RoundedCornerShape(6.dp))
                                .padding(8.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = VmlRed, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "ACTION REQUIRED: Promise missed. Escalate to Statutory Demand.",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VmlRed
                                )
                            }
                        }
                    }

                    if (promise.status == "PENDING") {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            OutlinedButton(
                                onClick = {
                                    Toast.makeText(context, "Payment reminder SMS dispatched to debtor!", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Send Reminder", fontSize = 10.sp)
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Button(
                                onClick = {
                                    viewModel.markPromiseDefaulted(promise, "Defaulted upon date expiry")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = VmlRedContainer),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("Default", fontSize = 10.sp, color = VmlRed)
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Button(
                                onClick = {
                                    viewModel.markPromiseFulfilled(promise)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = VmlGreen),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("Fulfilled", fontSize = 10.sp, color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}
