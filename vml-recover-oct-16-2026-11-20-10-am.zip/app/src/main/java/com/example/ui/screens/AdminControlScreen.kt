package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.CaseEntity
import com.example.data.model.PaymentTransactionEntity
import com.example.data.model.SmsNotificationEntity
import com.example.data.model.SystemConfigEntity
import com.example.data.model.UserEntity
import com.example.ui.components.formatUgxShort
import com.example.ui.theme.VmlAmber
import com.example.ui.theme.VmlAmberContainer
import com.example.ui.theme.VmlBlue
import com.example.ui.theme.VmlBlueContainer
import com.example.ui.theme.VmlCreamGreyElevated
import com.example.ui.theme.VmlGold
import com.example.ui.theme.VmlGoldDim
import com.example.ui.theme.VmlGoldLight
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlGreenContainer
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlRedContainer
import com.example.ui.theme.VmlSlate
import com.example.ui.theme.VmlTextPrimary
import com.example.ui.theme.VmlTextSecondary
import com.example.viewmodel.NavigationScreen
import com.example.viewmodel.UserRole
import com.example.viewmodel.VmlViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminControlScreen(
    viewModel: VmlViewModel,
    onOpenPasswordManagement: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val users by viewModel.allUsers.collectAsState()
    val lockedUsers by viewModel.allLockedUsers.collectAsState()
    val cases by viewModel.allCases.collectAsState()
    val payments by viewModel.allPayments.collectAsState()
    val smsNotifications by viewModel.allSmsNotifications.collectAsState()
    val systemConfig by viewModel.systemConfig.collectAsState()
    val timeline by viewModel.allTimeline.collectAsState()
    val metrics by viewModel.portfolioMetrics.collectAsState()

    var selectedAdminTab by remember { mutableStateOf(0) }
    var showAddUserDialog by remember { mutableStateOf(false) }
    var userToEdit by remember { mutableStateOf<UserEntity?>(null) }
    var userToDelete by remember { mutableStateOf<UserEntity?>(null) }
    var caseToEdit by remember { mutableStateOf<CaseEntity?>(null) }
    var paymentToDelete by remember { mutableStateOf<PaymentTransactionEntity?>(null) }
    var showModifyConfigDialog by remember { mutableStateOf(false) }
    var showSendSmsDialog by remember { mutableStateOf(false) }
    var showDatabaseInspectorDialog by remember { mutableStateOf(false) }
    var showAllPasswords by remember { mutableStateOf(false) }
    var revealedPasswords by remember { mutableStateOf<Map<String, Boolean>>(emptyMap()) }
    var isDbCredentialsUnlocked by remember { mutableStateOf(false) }
    var showPasswordChallengeForDbColumns by remember { mutableStateOf(false) }
    var challengePasswordInput by remember { mutableStateOf("") }
    var challengePasswordError by remember { mutableStateOf<String?>(null) }

    val adminTabs = listOf(
        "Users & Access" to users.size,
        "System Config" to (if (systemConfig.isSystemLocked) 1 else 0),
        "Debt Registry" to cases.size,
        "Payment Ledger" to payments.size,
        "SMS Hub (${smsNotifications.size})" to smsNotifications.size
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(VmlNavyDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Master System Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold.copy(alpha = 0.8f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(VmlGoldDim),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(22.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "ADMINISTRATOR: MASTER SYSTEM CONTROL",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = VmlGoldLight,
                                    letterSpacing = 1.2.sp
                                )
                                Text(
                                    text = "Virgin Markets Multi Legal Root Authority",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VmlTextPrimary
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (systemConfig.isSystemLocked) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(VmlRedContainer)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(text = "SYSTEM LOCKED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VmlRed)
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(VmlGreenContainer)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(text = "ROOT ACTIVE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VmlGreen)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Total System Users", fontSize = 10.sp, color = VmlSlate)
                            Text(text = "${users.size} Accounts", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "Locked Accounts", fontSize = 10.sp, color = VmlSlate)
                            Text(
                                text = "${lockedUsers.size} Locked",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (lockedUsers.isNotEmpty()) VmlRed else VmlGreen
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "SMS Dispatched", fontSize = 10.sp, color = VmlSlate)
                            Text(text = "${smsNotifications.size} Dispatched", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlGoldLight)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Root Admin Quick Actions Toolbar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showDatabaseInspectorDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = VmlBlue),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Storage, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("DB Inspector (####)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { showModifyConfigDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Modify System", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { showSendSmsDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = VmlGreen),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Sms, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Send SMS", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Realtime Database & Mobile Data Status Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(VmlGoldDim)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(VmlGreen)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Firebase Realtime DB: Connected & Live",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlGoldLight
                            )
                        }
                        Text(
                            text = "Mobile Data Access: Active",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = VmlSlate
                        )
                    }
                }
            }
        }

        // 2. Emergency Alert: Locked Accounts (User Requirement: App locks itself, only Admin allows in)
        if (lockedUsers.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlRedContainer),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, VmlRed)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = VmlRed, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ACCOUNTS LOCKED BY SECURITY EXCEPTION (${lockedUsers.size})",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = VmlRed,
                                letterSpacing = 0.5.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Security policy triggered: These accounts locked themselves after credential exceptions. Only the Administrator can allow them back in.",
                            fontSize = 11.sp,
                            color = VmlTextPrimary,
                            lineHeight = 15.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            lockedUsers.forEach { lockedUser ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlRed.copy(alpha = 0.7f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "${lockedUser.fullName} (${lockedUser.email})",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = VmlTextPrimary
                                            )
                                            Text(
                                                text = "Role: ${lockedUser.role} • Phone: ${lockedUser.phoneNumber}",
                                                fontSize = 10.sp,
                                                color = VmlSlate
                                            )
                                            Text(
                                                text = "Reason: ${lockedUser.lockReason ?: "Credential threshold violation"}",
                                                fontSize = 10.sp,
                                                color = VmlRed,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }

                                        Button(
                                            onClick = {
                                                viewModel.unlockUser(lockedUser.userId) { success, msg ->
                                                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = VmlGreen),
                                            shape = RoundedCornerShape(6.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                        ) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("ALLOW IN (UNLOCK)", fontSize = 10.sp, fontWeight = FontWeight.Black)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Admin Operational Subsystem Tabs
        item {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(adminTabs.size) { index ->
                    val (title, count) = adminTabs[index]
                    val isSelected = selectedAdminTab == index
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) VmlGold else VmlNavySurface)
                            .border(1.dp, if (isSelected) VmlGoldLight else VmlNavyBorder, RoundedCornerShape(8.dp))
                            .clickable { selectedAdminTab = index }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = title,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium,
                            color = if (isSelected) Color.White else VmlTextPrimary
                        )
                    }
                }
            }
        }

        // 4. TAB CONTENT
        when (selectedAdminTab) {
            0 -> {
                // TAB 0: USERS & ACCESS CONTROL (UPDATE, DELETE & MODIFY)
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "SYSTEM USER ROLES (${users.size})",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlGoldLight,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "DB Usernames & Passwords securely stored as ####. Admin holds full update & delete rights.",
                                fontSize = 10.sp,
                                color = VmlSlate
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(
                                onClick = { showAllPasswords = !showAllPasswords },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = VmlGoldLight),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = if (showAllPasswords) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (showAllPasswords) "Hide" else "Show", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            Button(
                                onClick = { showAddUserDialog = true },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add User", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                items(users) { user ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (user.isLocked) VmlRed else VmlNavyBorder)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = user.fullName,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = VmlTextPrimary
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(VmlGoldDim)
                                                .padding(horizontal = 5.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = user.role.replace("_", " "),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = VmlGoldLight
                                            )
                                        }

                                        if (user.isLocked) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(VmlRedContainer)
                                                    .padding(horizontal = 5.dp, vertical = 2.dp)
                                            ) {
                                                Text(text = "LOCKED OUT", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VmlRed)
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = "${user.email} • ${user.department}",
                                        fontSize = 11.sp,
                                        color = VmlSlate
                                    )
                                    Text(
                                        text = "Org: ${user.organization} • Phone: ${user.phoneNumber}",
                                        fontSize = 10.sp,
                                        color = VmlSlate
                                    )

                                    // Database representation showing #### masking
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(VmlNavyDark)
                                            .padding(horizontal = 6.dp, vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(text = "DB User: ", fontSize = 9.sp, color = VmlSlate)
                                        Text(text = "####", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VmlGoldLight)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = "DB Password: ", fontSize = 9.sp, color = VmlSlate)
                                        Text(text = "####", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VmlGoldLight)
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Edit / Modify Button
                                    IconButton(
                                        onClick = { userToEdit = user },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Security, contentDescription = "Edit User", tint = VmlGoldLight, modifier = Modifier.size(16.dp))
                                    }

                                    // Unlock / Allow In or Lock Button
                                    if (user.isLocked) {
                                        IconButton(
                                            onClick = {
                                                viewModel.unlockUser(user.userId) { success, msg ->
                                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = "Unlock User", tint = VmlGreen, modifier = Modifier.size(16.dp))
                                        }
                                    } else if (user.role != "ADMIN") {
                                        IconButton(
                                            onClick = {
                                                viewModel.lockUser(user.userId, "Manual Lock by Administrator") { success, msg ->
                                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Lock, contentDescription = "Lock User", tint = VmlAmber, modifier = Modifier.size(16.dp))
                                        }
                                    }

                                    // Delete User Button
                                    if (user.role != "ADMIN") {
                                        IconButton(
                                            onClick = { userToDelete = user },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete User", tint = VmlRed.copy(alpha = 0.8f), modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }

                            // Admin Visible Password Row
                            Spacer(modifier = Modifier.height(8.dp))
                            val isPassRevealed = showAllPasswords || (revealedPasswords[user.userId] == true)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(VmlNavyDark)
                                    .border(1.dp, VmlGold.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.Key, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "Password: ", fontSize = 11.sp, color = VmlSlate, fontWeight = FontWeight.Medium)
                                Text(
                                    text = if (isPassRevealed) user.password else "••••••••",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isPassRevealed) VmlGoldLight else VmlSlate
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                IconButton(
                                    onClick = {
                                        revealedPasswords = revealedPasswords.toMutableMap().apply {
                                            put(user.userId, !isPassRevealed)
                                        }
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isPassRevealed) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (isPassRevealed) "Hide Password" else "Reveal Password",
                                        tint = VmlGoldLight,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // TAB 1: SYSTEM CONFIGURATION & POLICIES (UPDATE & MODIFY SYSTEM)
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "GLOBAL SYSTEM CONFIGURATION",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VmlGoldLight,
                                    letterSpacing = 1.sp
                                )
                                Button(
                                    onClick = { showModifyConfigDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text("Modify Config", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "Legal Entity Name:", fontSize = 11.sp, color = VmlSlate)
                                Text(text = systemConfig.systemName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "Statutory Interest Rate:", fontSize = 11.sp, color = VmlSlate)
                                Text(text = "${systemConfig.statutoryInterestRate}% p.a.", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlGoldLight)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "Enforcement Grace Period:", fontSize = 11.sp, color = VmlSlate)
                                Text(text = "${systemConfig.defaultGracePeriodDays} Days", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "SMS Notification Gateway:", fontSize = 11.sp, color = VmlSlate)
                                Text(
                                    text = if (systemConfig.smsNotificationsEnabled) "ACTIVE (ENABLED)" else "SUSPENDED",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (systemConfig.smsNotificationsEnabled) VmlGreen else VmlRed
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "Emergency System Lockdown:", fontSize = 11.sp, color = VmlSlate)
                                Text(
                                    text = if (systemConfig.isSystemLocked) "LOCKDOWN ACTIVE" else "DISABLED (NORMAL)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (systemConfig.isSystemLocked) VmlRed else VmlGreen
                                )
                            }

                            if (systemConfig.isSystemLocked) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(VmlRedContainer)
                                        .padding(8.dp)
                                ) {
                                    Text(text = "Reason: ${systemConfig.lockdownReason}", fontSize = 10.sp, color = VmlRed)
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                // TAB 2: DEBT REGISTRY (ADMIN UPDATE, DELETE & MODIFY)
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "ACTIVE DEBT REGISTRY (${cases.size})",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlGoldLight,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Admin authority to modify claim balances, delete cases, or send reminder SMS",
                                fontSize = 10.sp,
                                color = VmlSlate
                            )
                        }
                    }
                }

                items(cases) { c ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = "${c.caseId} • ${c.debtorName}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                                    Text(text = "Creditor: ${c.creditorName} • Phone: ${c.debtorPhone}", fontSize = 11.sp, color = VmlSlate)
                                    Text(
                                        text = "Claim: UGX ${formatUgxShort(c.totalDebt)} | Paid: UGX ${formatUgxShort(c.amountPaid)} | Due: ${c.dueDate}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = VmlGoldLight
                                    )
                                }

                                Row {
                                    // Send SMS Reminder
                                    IconButton(
                                        onClick = {
                                            viewModel.sendPaymentReminderSms(c.caseId) { success, msg ->
                                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Sms, contentDescription = "Send Reminder SMS", tint = VmlGreen, modifier = Modifier.size(16.dp))
                                    }

                                    // Modify Case
                                    IconButton(
                                        onClick = { caseToEdit = c },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Security, contentDescription = "Modify Case", tint = VmlGoldLight, modifier = Modifier.size(16.dp))
                                    }

                                    // Delete Case
                                    IconButton(
                                        onClick = {
                                            viewModel.deleteCase(c.caseId) { success, msg ->
                                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete Case", tint = VmlRed.copy(alpha = 0.8f), modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            3 -> {
                // TAB 3: PAYMENT LEDGER (ADMIN VERIFY & REVERSE)
                item {
                    Text(
                        text = "PAYMENT & CREDIT RECONCILIATION LEDGER (${payments.size})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGoldLight,
                        letterSpacing = 1.sp
                    )
                }

                items(payments) { p ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "UGX ${formatUgxShort(p.amount)} (${p.receiptNumber})",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VmlGreen
                                )
                                Text(
                                    text = "Case: ${p.caseId} • Channel: ${p.paymentChannel} • Date: ${p.paymentDate}",
                                    fontSize = 10.sp,
                                    color = VmlSlate
                                )
                                Text(
                                    text = if (p.verified) "STATUS: VERIFIED & CREDITED" else "STATUS: PENDING RECONCILIATION",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (p.verified) VmlGreen else VmlAmber
                                )
                            }

                            Row {
                                if (!p.verified) {
                                    Button(
                                        onClick = { viewModel.reconcilePayment(p.id, true) },
                                        colors = ButtonDefaults.buttonColors(containerColor = VmlGreen),
                                        shape = RoundedCornerShape(4.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text("Credit SMS", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                }

                                IconButton(
                                    onClick = { paymentToDelete = p },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Reverse Payment", tint = VmlRed.copy(alpha = 0.8f), modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }

            4 -> {
                // TAB 4: SMS NOTIFICATIONS DISPATCH HUB
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "SMS NOTIFICATION DISPATCH OUTBOX (${smsNotifications.size})",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlGreen,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Telemetry records for Login, Debt, Credit, Payment, Reminders & Security alerts",
                                fontSize = 10.sp,
                                color = VmlSlate
                            )
                        }

                        Row {
                            Button(
                                onClick = { showSendSmsDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = VmlGreen),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("New SMS", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            OutlinedButton(
                                onClick = { viewModel.clearAllSms() },
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Clear", fontSize = 10.sp, color = VmlSlate)
                            }
                        }
                    }
                }

                if (smsNotifications.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = VmlNavySurface)
                        ) {
                            Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
                                Text(text = "No dispatched SMS records in outbox yet.", fontSize = 11.sp, color = VmlSlate)
                            }
                        }
                    }
                }

                items(smsNotifications) { sms ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(
                                                when (sms.eventType) {
                                                    "LOGIN_ALERT" -> VmlBlueContainer
                                                    "NEW_DEBT_NOTICE" -> VmlAmberContainer
                                                    "CREDIT_CONFIRMATION" -> VmlGreenContainer
                                                    "PAYMENT_RECEIVED" -> VmlGreenContainer
                                                    "PAYMENT_REMINDER" -> VmlGoldDim
                                                    else -> VmlRedContainer
                                                }
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = sms.eventType,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when (sms.eventType) {
                                                "LOGIN_ALERT" -> VmlBlue
                                                "NEW_DEBT_NOTICE" -> VmlAmber
                                                "CREDIT_CONFIRMATION" -> VmlGreen
                                                "PAYMENT_RECEIVED" -> VmlGreen
                                                "PAYMENT_REMINDER" -> VmlGoldLight
                                                else -> VmlRed
                                            }
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "To: ${sms.recipientPhone} (${sms.recipientName})",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = VmlTextPrimary
                                    )
                                }

                                Text(
                                    text = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(sms.timestamp)),
                                    fontSize = 10.sp,
                                    color = VmlSlate
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = sms.messageContent,
                                fontSize = 10.sp,
                                color = VmlTextPrimary,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // DIALOGS
    if (showAddUserDialog) {
        AddNewUserDialog(
            onDismiss = { showAddUserDialog = false },
            onConfirm = { newUser ->
                viewModel.addNewUser(newUser) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    showAddUserDialog = false
                }
            }
        )
    }

    userToEdit?.let { u ->
        EditUserDialog(
            user = u,
            onDismiss = { userToEdit = null },
            onConfirm = { updated ->
                viewModel.updateUser(updated) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    userToEdit = null
                }
            }
        )
    }

    userToDelete?.let { u ->
        ConfirmDeleteDialog(
            title = "Delete User ${u.fullName}?",
            message = "This will permanently remove account ${u.email} (${u.role}) from the system database. This action cannot be undone.",
            onDismiss = { userToDelete = null },
            onConfirm = {
                viewModel.deleteUser(u.userId) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    userToDelete = null
                }
            }
        )
    }

    caseToEdit?.let { c ->
        EditCaseDialog(
            caseItem = c,
            onDismiss = { caseToEdit = null },
            onConfirm = { updated ->
                viewModel.updateCase(updated) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    caseToEdit = null
                }
            },
            onDelete = { caseId ->
                viewModel.deleteCase(caseId) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    caseToEdit = null
                }
            }
        )
    }

    paymentToDelete?.let { p ->
        ConfirmDeleteDialog(
            title = "Reverse Payment Transaction #${p.id}?",
            message = "This will expunge receipt ${p.receiptNumber} (UGX ${p.amount}) from the ledger.",
            onDismiss = { paymentToDelete = null },
            onConfirm = {
                viewModel.deletePayment(p.id) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    paymentToDelete = null
                }
            }
        )
    }

    if (showModifyConfigDialog) {
        ModifySystemConfigDialog(
            config = systemConfig,
            onDismiss = { showModifyConfigDialog = false },
            onConfirm = { newCfg ->
                viewModel.updateSystemConfig(newCfg) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    showModifyConfigDialog = false
                }
            }
        )
    }

    if (showSendSmsDialog) {
        SendCustomSmsDialog(
            onDismiss = { showSendSmsDialog = false },
            onConfirm = { phone, name, eventType, msg ->
                viewModel.dispatchCustomSms(phone, name, eventType, msg) { success, resMsg ->
                    Toast.makeText(context, resMsg, Toast.LENGTH_SHORT).show()
                    showSendSmsDialog = false
                }
            }
        )
    }

    if (showDatabaseInspectorDialog) {
        DatabaseInspectorDialog(
            users = users,
            onDismiss = { showDatabaseInspectorDialog = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddNewUserDialog(
    onDismiss: () -> Unit,
    onConfirm: (UserEntity) -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("COLLECTION_OFFICER") }
    var department by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("+256 ") }
    var organization by remember { mutableStateOf("Virgin Markets Multi Legal") }
    var expandedRoleMenu by remember { mutableStateOf(false) }

    val roleOptions = listOf(
        "ADMIN" to "Administrator (Complete System Control)",
        "DIRECTOR" to "Director (Portfolio & Performance Only)",
        "COLLECTION_MANAGER" to "Collection Manager (Allocation & Supervision)",
        "COLLECTION_OFFICER" to "Collection Officer (Calls, Visits, PTP, Payments)",
        "LEGAL_OFFICER" to "Legal Officer (Litigation & Escalation)",
        "FINANCE_OFFICER" to "Finance Officer (Payments & Reconciliation)",
        "CLIENT_PORTAL" to "Client (Assigned Portfolio & Reports)",
        "DEBTOR_PORTAL" to "Debtor (Balance, Plan & Pay Only)"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "CREATE NEW SYSTEM USER",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = VmlGoldLight,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "DB Username & Password stored as #### in secure Room storage",
                    fontSize = 10.sp,
                    color = VmlSlate
                )
                Spacer(modifier = Modifier.height(10.dp))

                // Full Name Horizontal Row
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Full Name", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = VmlSlate, modifier = Modifier.width(95.dp))
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        placeholder = { Text("Full Name", fontSize = 11.sp, color = VmlSlate.copy(alpha = 0.5f)) },
                        singleLine = true,
                        modifier = Modifier.weight(1f).height(42.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VmlGold,
                            unfocusedBorderColor = VmlNavyBorder,
                            focusedContainerColor = VmlCreamGreyElevated,
                            unfocusedContainerColor = VmlCreamGreyElevated,
                            focusedTextColor = VmlTextPrimary,
                            unfocusedTextColor = VmlTextPrimary
                        ),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = VmlTextPrimary)
                    )
                }

                // Email Address Horizontal Row
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Login Email", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = VmlSlate, modifier = Modifier.width(95.dp))
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        placeholder = { Text("Email / Login ID", fontSize = 11.sp, color = VmlSlate.copy(alpha = 0.5f)) },
                        singleLine = true,
                        modifier = Modifier.weight(1f).height(42.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VmlGold,
                            unfocusedBorderColor = VmlNavyBorder,
                            focusedContainerColor = VmlCreamGreyElevated,
                            unfocusedContainerColor = VmlCreamGreyElevated,
                            focusedTextColor = VmlTextPrimary,
                            unfocusedTextColor = VmlTextPrimary
                        ),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = VmlTextPrimary)
                    )
                }

                // Phone Number Horizontal Row
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Phone (SMS)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = VmlSlate, modifier = Modifier.width(95.dp))
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        placeholder = { Text("Phone Number", fontSize = 11.sp, color = VmlSlate.copy(alpha = 0.5f)) },
                        singleLine = true,
                        modifier = Modifier.weight(1f).height(42.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VmlGold,
                            unfocusedBorderColor = VmlNavyBorder,
                            focusedContainerColor = VmlCreamGreyElevated,
                            unfocusedContainerColor = VmlCreamGreyElevated,
                            focusedTextColor = VmlTextPrimary,
                            unfocusedTextColor = VmlTextPrimary
                        ),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = VmlTextPrimary)
                    )
                }

                // Default Password Horizontal Row
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Password", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = VmlSlate, modifier = Modifier.width(95.dp))
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        placeholder = { Text("Default Password", fontSize = 11.sp, color = VmlSlate.copy(alpha = 0.5f)) },
                        singleLine = true,
                        modifier = Modifier.weight(1f).height(42.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VmlGold,
                            unfocusedBorderColor = VmlNavyBorder,
                            focusedContainerColor = VmlCreamGreyElevated,
                            unfocusedContainerColor = VmlCreamGreyElevated,
                            focusedTextColor = VmlTextPrimary,
                            unfocusedTextColor = VmlTextPrimary
                        ),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = VmlTextPrimary)
                    )
                }

                // Role selector Horizontal Row
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("System Role", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = VmlSlate, modifier = Modifier.width(95.dp))
                    ExposedDropdownMenuBox(
                        expanded = expandedRoleMenu,
                        onExpandedChange = { expandedRoleMenu = it },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = role.replace("_", " "),
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedRoleMenu) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = VmlGold,
                                unfocusedBorderColor = VmlNavyBorder,
                                focusedContainerColor = VmlCreamGreyElevated,
                                unfocusedContainerColor = VmlCreamGreyElevated,
                                focusedTextColor = VmlTextPrimary,
                                unfocusedTextColor = VmlTextPrimary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(42.dp)
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = VmlTextPrimary)
                        )

                        ExposedDropdownMenu(
                            expanded = expandedRoleMenu,
                            onDismissRequest = { expandedRoleMenu = false },
                            modifier = Modifier.background(VmlNavySurface)
                        ) {
                            roleOptions.forEach { (code, title) ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(text = code.replace("_", " "), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                                            Text(text = title, fontSize = 10.sp, color = VmlSlate)
                                        }
                                    },
                                    onClick = {
                                        role = code
                                        expandedRoleMenu = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("Cancel", color = VmlSlate)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (fullName.isNotBlank() && email.isNotBlank() && password.isNotBlank()) {
                                onConfirm(
                                    UserEntity(
                                        userId = "USR-${System.currentTimeMillis() % 10000}",
                                        email = email.trim(),
                                        password = password.trim(),
                                        fullName = fullName.trim(),
                                        role = role,
                                        department = department.ifBlank { "VML Operations" },
                                        phoneNumber = phone.ifBlank { "+256 700 000 000" },
                                        organization = organization,
                                        maskedUsername = "####",
                                        maskedPassword = "####"
                                    )
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                    ) {
                        Text("Save User", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
