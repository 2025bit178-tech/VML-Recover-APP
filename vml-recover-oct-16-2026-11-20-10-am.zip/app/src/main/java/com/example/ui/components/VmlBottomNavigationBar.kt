package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.AssignmentInd
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SupervisorAccount
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.VmlGold
import com.example.ui.theme.VmlGoldLight
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlSlate
import com.example.viewmodel.NavigationScreen
import com.example.viewmodel.UserRole

data class BottomNavItem(
    val screen: NavigationScreen,
    val label: String,
    val icon: ImageVector,
    val badgeCount: Int = 0
)

@Composable
fun AppBottomNav(
    currentScreen: NavigationScreen,
    currentRole: UserRole,
    onNavigate: (NavigationScreen) -> Unit,
    criticalCount: Int = 0,
    ptpCount: Int = 0
) {
    val items = when (currentRole) {
        UserRole.ADMIN -> listOf(
            BottomNavItem(NavigationScreen.ADMIN_SYSTEM_CONTROL, "Admin Control", Icons.Default.Security),
            BottomNavItem(NavigationScreen.CLIENT_PORTAL, "Clients", Icons.Default.AccountBalance),
            BottomNavItem(NavigationScreen.CASES, "Debtors", Icons.Default.AssignmentInd, criticalCount),
            BottomNavItem(NavigationScreen.REPORTS, "Reports & Audit", Icons.Default.Assessment)
        )
        UserRole.DIRECTOR -> listOf(
            BottomNavItem(NavigationScreen.DASHBOARD, "Executive", Icons.Default.Leaderboard),
            BottomNavItem(NavigationScreen.CLIENT_PORTAL, "Clients", Icons.Default.AccountBalance),
            BottomNavItem(NavigationScreen.CASES, "Debtors", Icons.Default.AssignmentInd, criticalCount),
            BottomNavItem(NavigationScreen.REPORTS, "Reports & Audit", Icons.Default.Assessment)
        )
        UserRole.COLLECTION_MANAGER -> listOf(
            BottomNavItem(NavigationScreen.MANAGER_SUPERVISION, "Supervision", Icons.Default.SupervisorAccount),
            BottomNavItem(NavigationScreen.CLIENT_PORTAL, "Clients", Icons.Default.AccountBalance),
            BottomNavItem(NavigationScreen.CASES, "Debtors", Icons.Default.AssignmentInd),
            BottomNavItem(NavigationScreen.REPORTS, "Reports & Audit", Icons.Default.Assessment)
        )
        UserRole.COLLECTION_OFFICER -> listOf(
            BottomNavItem(NavigationScreen.CASES, "Debtors", Icons.Default.AssignmentInd),
            BottomNavItem(NavigationScreen.CLIENT_PORTAL, "Clients", Icons.Default.AccountBalance),
            BottomNavItem(NavigationScreen.PROMISES, "PTP Tracker", Icons.Default.Schedule, ptpCount),
            BottomNavItem(NavigationScreen.REPORTS, "Reports", Icons.Default.Assessment)
        )
        UserRole.LEGAL_OFFICER -> listOf(
            BottomNavItem(NavigationScreen.LEGAL_HUB, "Legal Chambers", Icons.Default.Gavel),
            BottomNavItem(NavigationScreen.CLIENT_PORTAL, "Clients", Icons.Default.AccountBalance),
            BottomNavItem(NavigationScreen.CASES, "Debtors", Icons.Default.AssignmentInd),
            BottomNavItem(NavigationScreen.REPORTS, "Reports", Icons.Default.Assessment)
        )
        UserRole.FINANCE_OFFICER -> listOf(
            BottomNavItem(NavigationScreen.FINANCE_RECONCILIATION, "Finance Ledger", Icons.Default.Payment),
            BottomNavItem(NavigationScreen.CLIENT_PORTAL, "Clients", Icons.Default.AccountBalance),
            BottomNavItem(NavigationScreen.CASES, "Debtors", Icons.Default.AssignmentInd),
            BottomNavItem(NavigationScreen.REPORTS, "Reports", Icons.Default.Assessment)
        )
        UserRole.CLIENT_PORTAL -> listOf(
            BottomNavItem(NavigationScreen.CLIENT_PORTAL, "Debtor Database", Icons.Default.AccountBalance),
            BottomNavItem(NavigationScreen.CASES, "All Cases", Icons.Default.AssignmentInd),
            BottomNavItem(NavigationScreen.REPORTS, "Audit Reports", Icons.Default.Assessment)
        )
        UserRole.DEBTOR_PORTAL -> listOf(
            BottomNavItem(NavigationScreen.DEBTOR_PORTAL, "Borrower Portal", Icons.Default.Person),
            BottomNavItem(NavigationScreen.CLIENT_PORTAL, "Client Statement", Icons.Default.AccountBalance)
        )
    }

    NavigationBar(
        containerColor = VmlNavySurface,
        tonalElevation = 8.dp
    ) {
        items.forEach { item ->
            val isSelected = currentScreen == item.screen
            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(item.screen) },
                icon = {
                    if (item.badgeCount > 0) {
                        BadgedBox(
                            badge = {
                                Badge(
                                    containerColor = VmlRed,
                                    contentColor = Color.White
                                ) {
                                    Text(item.badgeCount.toString(), fontSize = 9.sp)
                                }
                            }
                        ) {
                            Icon(item.icon, contentDescription = item.label, modifier = Modifier.size(20.dp))
                        }
                    } else {
                        Icon(item.icon, contentDescription = item.label, modifier = Modifier.size(20.dp))
                    }
                },
                label = {
                    Text(
                        text = item.label,
                        fontSize = 10.sp,
                        color = if (isSelected) VmlGoldLight else VmlSlate
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = VmlGoldLight,
                    unselectedIconColor = VmlSlate,
                    indicatorColor = VmlNavyDark
                )
            )
        }
    }
}
