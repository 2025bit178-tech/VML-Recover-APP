package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CreamishGreyColorScheme = lightColorScheme(
    primary = VmlGoldLight,
    onPrimary = Color.White,
    primaryContainer = VmlGoldDim,
    onPrimaryContainer = VmlGoldLight,
    secondary = VmlBlue,
    onSecondary = Color.White,
    secondaryContainer = VmlBlueContainer,
    onSecondaryContainer = VmlBlue,
    tertiary = VmlGreen,
    onTertiary = Color.White,
    background = VmlNavyDark,
    onBackground = VmlTextPrimary,
    surface = VmlNavySurface,
    onSurface = VmlTextPrimary,
    surfaceVariant = Color(0xFFE4DFD7),
    onSurfaceVariant = VmlSlate,
    outline = VmlNavyBorder,
    error = VmlRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CreamishGreyColorScheme,
        typography = Typography,
        content = content
    )
}
