package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.CaseEntity
import com.example.data.model.SystemConfigEntity
import com.example.data.model.UserEntity
import com.example.ui.theme.VmlBlue
import com.example.ui.theme.VmlCreamGreyElevated
import com.example.ui.theme.VmlGold
import com.example.ui.theme.VmlGoldDim
import com.example.ui.theme.VmlGoldLight
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlGreenContainer
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlRedContainer
import com.example.ui.theme.VmlSlate
import com.example.ui.theme.VmlTextPrimary

val systemRoleOptions = listOf(
    "ADMIN" to "Administrator (Complete System Control)",
    "DIRECTOR" to "Director (Portfolio & Performance Only)",
    "COLLECTION_MANAGER" to "Collection Manager (Allocation & Supervision)",
    "COLLECTION_OFFICER" to "Collection Officer (Calls, Visits, PTP, Payments)",
    "LEGAL_OFFICER" to "Legal Officer (Litigation & Escalation)",
    "FINANCE_OFFICER" to "Finance Officer (Payments & Reconciliation)",
    "CLIENT_PORTAL" to "Client (Assigned Portfolio & Reports)",
    "DEBTOR_PORTAL" to "Debtor (Balance, Plan & Pay Only)"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditUserDialog(
    user: UserEntity,
    onDismiss: () -> Unit,
    onConfirm: (UserEntity) -> Unit
) {
    var fullName by remember { mutableStateOf(user.fullName) }
    var email by remember { mutableStateOf(user.email) }
    var phone by remember { mutableStateOf(user.phoneNumber) }
    var role by remember { mutableStateOf(user.role) }
    var department by remember { mutableStateOf(user.department) }
    var organization by remember { mutableStateOf(user.organization) }
    var password by remember { mutableStateOf(user.password) }
    var isLocked by remember { mutableStateOf(user.isLocked) }
    var expandedRoleMenu by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "MODIFY SYSTEM USER: ${user.userId}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = VmlGoldLight,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Database Username & Password stored as #### in secure Room storage",
                    fontSize = 10.sp,
                    color = VmlSlate
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("Full Name", fontSize = 11.sp, color = VmlSlate) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VmlGold,
                        unfocusedBorderColor = VmlNavyBorder,
                        focusedContainerColor = VmlCreamGreyElevated,
                        unfocusedContainerColor = VmlCreamGreyElevated,
                        focusedTextColor = VmlTextPrimary,
                        unfocusedTextColor = VmlTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email / Identifier (DB: ####)", fontSize = 11.sp, color = VmlSlate) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VmlGold,
                        unfocusedBorderColor = VmlNavyBorder,
                        focusedContainerColor = VmlCreamGreyElevated,
                        unfocusedContainerColor = VmlCreamGreyElevated,
                        focusedTextColor = VmlTextPrimary,
                        unfocusedTextColor = VmlTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number (SMS Recipient)", fontSize = 11.sp, color = VmlSlate) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VmlGold,
                        unfocusedBorderColor = VmlNavyBorder,
                        focusedContainerColor = VmlCreamGreyElevated,
                        unfocusedContainerColor = VmlCreamGreyElevated,
                        focusedTextColor = VmlTextPrimary,
                        unfocusedTextColor = VmlTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password (DB Storage: ####)", fontSize = 11.sp, color = VmlSlate) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VmlGold,
                        unfocusedBorderColor = VmlNavyBorder,
                        focusedContainerColor = VmlCreamGreyElevated,
                        unfocusedContainerColor = VmlCreamGreyElevated,
                        focusedTextColor = VmlTextPrimary,
                        unfocusedTextColor = VmlTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Role selector
                ExposedDropdownMenuBox(
                    expanded = expandedRoleMenu,
                    onExpandedChange = { expandedRoleMenu = it }
                ) {
                    OutlinedTextField(
                        value = role.replace("_", " "),
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("System Role Authority", fontSize = 11.sp, color = VmlSlate) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedRoleMenu) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VmlGold,
                            unfocusedBorderColor = VmlNavyBorder,
                            focusedContainerColor = VmlCreamGreyElevated,
                            unfocusedContainerColor = VmlCreamGreyElevated,
                            focusedTextColor = VmlTextPrimary,
                            unfocusedTextColor = VmlTextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )

                    ExposedDropdownMenu(
                        expanded = expandedRoleMenu,
                        onDismissRequest = { expandedRoleMenu = false },
                        modifier = Modifier.background(VmlNavySurface)
                    ) {
                        systemRoleOptions.forEach { (code, title) ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(text = code.replace("_", " "), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                                        Text(text = title, fontSize = 10.sp, color = VmlSlate)
                                    }
                                },
                                onClick = {
                                    role = code
                                    expandedRoleMenu = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = department,
                    onValueChange = { department = it },
                    label = { Text("Department", fontSize = 11.sp, color = VmlSlate) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VmlGold,
                        unfocusedBorderColor = VmlNavyBorder,
                        focusedContainerColor = VmlCreamGreyElevated,
                        unfocusedContainerColor = VmlCreamGreyElevated,
                        focusedTextColor = VmlTextPrimary,
                        unfocusedTextColor = VmlTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Account Lock Status Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isLocked) "Account Status: LOCKED" else "Account Status: ACTIVE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isLocked) VmlRed else VmlGreen
                        )
                        Text(
                            text = if (isLocked) "User cannot log in (Locked out)" else "Normal access permitted",
                            fontSize = 10.sp,
                            color = VmlSlate
                        )
                    }
                    Switch(
                        checked = isLocked,
                        onCheckedChange = { isLocked = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = VmlRed,
                            checkedTrackColor = VmlRed.copy(alpha = 0.3f),
                            uncheckedThumbColor = VmlGreen,
                            uncheckedTrackColor = VmlGreen.copy(alpha = 0.3f)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("Cancel", color = VmlSlate)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (fullName.isNotBlank() && email.isNotBlank()) {
                                onConfirm(
                                    user.copy(
                                        fullName = fullName.trim(),
                                        email = email.trim(),
                                        phoneNumber = phone.trim(),
                                        role = role,
                                        department = department.trim(),
                                        organization = organization.trim(),
                                        password = password.trim(),
                                        maskedUsername = "####",
                                        maskedPassword = "####",
                                        isLocked = isLocked,
                                        lockReason = if (isLocked) (user.lockReason ?: "Manual Lock by Administrator") else null,
                                        failedAttempts = if (isLocked) user.failedAttempts else 0
                                    )
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                    ) {
                        Text("Save Changes", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ModifySystemConfigDialog(
    config: SystemConfigEntity,
    onDismiss: () -> Unit,
    onConfirm: (SystemConfigEntity) -> Unit
) {
    var systemName by remember { mutableStateOf(config.systemName) }
    var isLocked by remember { mutableStateOf(config.isSystemLocked) }
    var lockdownMsg by remember { mutableStateOf(config.lockdownReason) }
    var smsEnabled by remember { mutableStateOf(config.smsNotificationsEnabled) }
    var gracePeriod by remember { mutableStateOf(config.defaultGracePeriodDays.toString()) }
    var interestRate by remember { mutableStateOf(config.statutoryInterestRate.toString()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "MODIFY SYSTEM CONFIGURATION",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = VmlGoldLight,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Root administrator controls for global recovery parameters & gateways",
                    fontSize = 10.sp,
                    color = VmlSlate
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = systemName,
                    onValueChange = { systemName = it },
                    label = { Text("System Legal Entity Name", fontSize = 11.sp, color = VmlSlate) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VmlGold,
                        unfocusedBorderColor = VmlNavyBorder,
                        focusedContainerColor = VmlCreamGreyElevated,
                        unfocusedContainerColor = VmlCreamGreyElevated,
                        focusedTextColor = VmlTextPrimary,
                        unfocusedTextColor = VmlTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = gracePeriod,
                    onValueChange = { gracePeriod = it },
                    label = { Text("Default Enforcement Grace Period (Days)", fontSize = 11.sp, color = VmlSlate) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VmlGold,
                        unfocusedBorderColor = VmlNavyBorder,
                        focusedContainerColor = VmlCreamGreyElevated,
                        unfocusedContainerColor = VmlCreamGreyElevated,
                        focusedTextColor = VmlTextPrimary,
                        unfocusedTextColor = VmlTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = interestRate,
                    onValueChange = { interestRate = it },
                    label = { Text("Default Statutory Interest Rate (% p.a.)", fontSize = 11.sp, color = VmlSlate) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VmlGold,
                        unfocusedBorderColor = VmlNavyBorder,
                        focusedContainerColor = VmlCreamGreyElevated,
                        unfocusedContainerColor = VmlCreamGreyElevated,
                        focusedTextColor = VmlTextPrimary,
                        unfocusedTextColor = VmlTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // SMS Gateway Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "SMS Notification Gateway",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlTextPrimary
                        )
                        Text(
                            text = if (smsEnabled) "Active: Dispatch alerts on Login, Debt, Payment, Reminder" else "Disabled: SMS alerts suspended",
                            fontSize = 10.sp,
                            color = if (smsEnabled) VmlGreen else VmlRed
                        )
                    }
                    Switch(
                        checked = smsEnabled,
                        onCheckedChange = { smsEnabled = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = VmlGreen,
                            checkedTrackColor = VmlGreen.copy(alpha = 0.3f)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Global System Lockdown Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Emergency System Lockdown",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isLocked) VmlRed else VmlTextPrimary
                        )
                        Text(
                            text = if (isLocked) "LOCKDOWN ACTIVE: All non-admin logins rejected" else "Normal operation: All roles permitted",
                            fontSize = 10.sp,
                            color = if (isLocked) VmlRed else VmlSlate
                        )
                    }
                    Switch(
                        checked = isLocked,
                        onCheckedChange = { isLocked = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = VmlRed,
                            checkedTrackColor = VmlRed.copy(alpha = 0.3f),
                            uncheckedThumbColor = VmlGreen,
                            uncheckedTrackColor = VmlGreen.copy(alpha = 0.3f)
                        )
                    )
                }

                if (isLocked) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = lockdownMsg,
                        onValueChange = { lockdownMsg = it },
                        label = { Text("Lockdown Message for Users", fontSize = 11.sp, color = VmlRed) },
                        singleLine = false,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VmlRed,
                            unfocusedBorderColor = VmlRed.copy(alpha = 0.5f),
                            focusedContainerColor = VmlCreamGreyElevated,
                            unfocusedContainerColor = VmlCreamGreyElevated,
                            focusedTextColor = VmlTextPrimary,
                            unfocusedTextColor = VmlTextPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("Cancel", color = VmlSlate)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val grace = gracePeriod.toIntOrNull() ?: 14
                            val rate = interestRate.toDoubleOrNull() ?: 12.0
                            onConfirm(
                                config.copy(
                                    systemName = systemName.trim(),
                                    isSystemLocked = isLocked,
                                    lockdownReason = lockdownMsg.trim(),
                                    smsNotificationsEnabled = smsEnabled,
                                    defaultGracePeriodDays = grace,
                                    statutoryInterestRate = rate,
                                    lastModifiedAt = System.currentTimeMillis()
                                )
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                    ) {
                        Text("Save Configuration", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun SendCustomSmsDialog(
    onDismiss: () -> Unit,
    onConfirm: (phone: String, name: String, eventType: String, message: String) -> Unit
) {
    var phone by remember { mutableStateOf("+256 772 ") }
    var name by remember { mutableStateOf("") }
    var eventType by remember { mutableStateOf("PAYMENT_REMINDER") }
    var message by remember { mutableStateOf("[VML URGENT - PAYMENT REMINDER]\nDear Debtor, please pay scheduled debt instalment today to avoid High Court execution.") }

    val eventTypes = listOf(
        "PAYMENT_REMINDER" to "Payment Reminder",
        "NEW_DEBT_NOTICE" to "Debt Registration Notice",
        "CREDIT_CONFIRMATION" to "Credit Confirmation",
        "PAYMENT_RECEIVED" to "Payment Received",
        "SECURITY_LOCKOUT" to "Security Lockout Alert",
        "ACCOUNT_UNLOCKED" to "Account Unlocked Notice"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, VmlGreen)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "DISPATCH SMS NOTIFICATION",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = VmlGreen,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Transmit immediate SMS message to debtor, client, or officer mobile phone",
                    fontSize = 10.sp,
                    color = VmlSlate
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Recipient Phone Number", fontSize = 11.sp, color = VmlSlate) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VmlGreen,
                        unfocusedBorderColor = VmlNavyBorder,
                        focusedContainerColor = VmlCreamGreyElevated,
                        unfocusedContainerColor = VmlCreamGreyElevated,
                        focusedTextColor = VmlTextPrimary,
                        unfocusedTextColor = VmlTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Recipient Name", fontSize = 11.sp, color = VmlSlate) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VmlGreen,
                        unfocusedBorderColor = VmlNavyBorder,
                        focusedContainerColor = VmlCreamGreyElevated,
                        unfocusedContainerColor = VmlCreamGreyElevated,
                        focusedTextColor = VmlTextPrimary,
                        unfocusedTextColor = VmlTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = { Text("SMS Message Body", fontSize = 11.sp, color = VmlSlate) },
                    singleLine = false,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VmlGreen,
                        unfocusedBorderColor = VmlNavyBorder,
                        focusedContainerColor = VmlCreamGreyElevated,
                        unfocusedContainerColor = VmlCreamGreyElevated,
                        focusedTextColor = VmlTextPrimary,
                        unfocusedTextColor = VmlTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("Cancel", color = VmlSlate)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (phone.isNotBlank() && message.isNotBlank()) {
                                onConfirm(phone.trim(), name.ifBlank { "Client / Debtor" }, eventType, message.trim())
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VmlGreen)
                    ) {
                        Text("Send SMS Now", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun EditCaseDialog(
    caseItem: CaseEntity,
    onDismiss: () -> Unit,
    onConfirm: (CaseEntity) -> Unit,
    onDelete: (String) -> Unit
) {
    var debtorName by remember { mutableStateOf(caseItem.debtorName) }
    var debtorPhone by remember { mutableStateOf(caseItem.debtorPhone) }
    var creditorName by remember { mutableStateOf(caseItem.creditorName) }
    var principal by remember { mutableStateOf(caseItem.principalAmount.toLong().toString()) }
    var interest by remember { mutableStateOf(caseItem.interestAmount.toLong().toString()) }
    var penalties by remember { mutableStateOf(caseItem.penaltiesAmount.toLong().toString()) }
    var dueDate by remember { mutableStateOf(caseItem.dueDate) }
    var status by remember { mutableStateOf(caseItem.status) }
    var officerName by remember { mutableStateOf(caseItem.assignedOfficerName) }
    var showConfirmDelete by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "MODIFY DEBT CASE",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlGoldLight,
                            letterSpacing = 1.sp
                        )
                        Text(text = "Ref: ${caseItem.caseId}", fontSize = 10.sp, color = VmlSlate)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = VmlSlate)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = debtorName,
                    onValueChange = { debtorName = it },
                    label = { Text("Debtor Full Name", fontSize = 11.sp, color = VmlSlate) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VmlGold,
                        unfocusedBorderColor = VmlNavyBorder,
                        focusedContainerColor = VmlCreamGreyElevated,
                        unfocusedContainerColor = VmlCreamGreyElevated,
                        focusedTextColor = VmlTextPrimary,
                        unfocusedTextColor = VmlTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = debtorPhone,
                    onValueChange = { debtorPhone = it },
                    label = { Text("Debtor Phone Number (SMS Recipient)", fontSize = 11.sp, color = VmlSlate) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VmlGold,
                        unfocusedBorderColor = VmlNavyBorder,
                        focusedContainerColor = VmlCreamGreyElevated,
                        unfocusedContainerColor = VmlCreamGreyElevated,
                        focusedTextColor = VmlTextPrimary,
                        unfocusedTextColor = VmlTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = creditorName,
                    onValueChange = { creditorName = it },
                    label = { Text("Creditor Institution", fontSize = 11.sp, color = VmlSlate) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VmlGold,
                        unfocusedBorderColor = VmlNavyBorder,
                        focusedContainerColor = VmlCreamGreyElevated,
                        unfocusedContainerColor = VmlCreamGreyElevated,
                        focusedTextColor = VmlTextPrimary,
                        unfocusedTextColor = VmlTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = principal,
                        onValueChange = { principal = it },
                        label = { Text("Principal (UGX)", fontSize = 11.sp, color = VmlSlate) },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VmlGold,
                            unfocusedBorderColor = VmlNavyBorder,
                            focusedContainerColor = VmlCreamGreyElevated,
                            unfocusedContainerColor = VmlCreamGreyElevated,
                            focusedTextColor = VmlTextPrimary,
                            unfocusedTextColor = VmlTextPrimary
                        )
                    )
                    OutlinedTextField(
                        value = interest,
                        onValueChange = { interest = it },
                        label = { Text("Interest (UGX)", fontSize = 11.sp, color = VmlSlate) },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VmlGold,
                            unfocusedBorderColor = VmlNavyBorder,
                            focusedContainerColor = VmlCreamGreyElevated,
                            unfocusedContainerColor = VmlCreamGreyElevated,
                            focusedTextColor = VmlTextPrimary,
                            unfocusedTextColor = VmlTextPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = dueDate,
                        onValueChange = { dueDate = it },
                        label = { Text("Due Date (YYYY-MM-DD)", fontSize = 11.sp, color = VmlSlate) },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VmlGold,
                            unfocusedBorderColor = VmlNavyBorder,
                            focusedContainerColor = VmlCreamGreyElevated,
                            unfocusedContainerColor = VmlCreamGreyElevated,
                            focusedTextColor = VmlTextPrimary,
                            unfocusedTextColor = VmlTextPrimary
                        )
                    )
                    OutlinedTextField(
                        value = status,
                        onValueChange = { status = it },
                        label = { Text("Status (ACTIVE/LEGAL/CRITICAL)", fontSize = 11.sp, color = VmlSlate) },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VmlGold,
                            unfocusedBorderColor = VmlNavyBorder,
                            focusedContainerColor = VmlCreamGreyElevated,
                            unfocusedContainerColor = VmlCreamGreyElevated,
                            focusedTextColor = VmlTextPrimary,
                            unfocusedTextColor = VmlTextPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = officerName,
                    onValueChange = { officerName = it },
                    label = { Text("Assigned Recovery Officer", fontSize = 11.sp, color = VmlSlate) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VmlGold,
                        unfocusedBorderColor = VmlNavyBorder,
                        focusedContainerColor = VmlCreamGreyElevated,
                        unfocusedContainerColor = VmlCreamGreyElevated,
                        focusedTextColor = VmlTextPrimary,
                        unfocusedTextColor = VmlTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { showConfirmDelete = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = VmlRed)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Delete Case", fontSize = 11.sp)
                    }

                    Row {
                        OutlinedButton(onClick = onDismiss) {
                            Text("Cancel", color = VmlSlate, fontSize = 11.sp)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val p = principal.toDoubleOrNull() ?: caseItem.principalAmount
                                val i = interest.toDoubleOrNull() ?: caseItem.interestAmount
                                val pen = penalties.toDoubleOrNull() ?: caseItem.penaltiesAmount
                                onConfirm(
                                    caseItem.copy(
                                        debtorName = debtorName.trim(),
                                        debtorPhone = debtorPhone.trim(),
                                        creditorName = creditorName.trim(),
                                        principalAmount = p,
                                        interestAmount = i,
                                        penaltiesAmount = pen,
                                        dueDate = dueDate.trim(),
                                        status = status.trim().uppercase(),
                                        assignedOfficerName = officerName.trim()
                                    )
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                        ) {
                            Text("Save Changes", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }

    if (showConfirmDelete) {
        ConfirmDeleteDialog(
            title = "Delete Debt Case ${caseItem.caseId}?",
            message = "This will permanently remove this case and its recovery ledger from the Virgin Markets Multi Legal database. This action cannot be undone.",
            onDismiss = { showConfirmDelete = false },
            onConfirm = {
                showConfirmDelete = false
                onDelete(caseItem.caseId)
            }
        )
    }
}

@Composable
fun ConfirmDeleteDialog(
    title: String,
    message: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, VmlRed)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(VmlRedContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = VmlRed, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = VmlRed
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = message,
                    fontSize = 11.sp,
                    color = VmlTextPrimary,
                    lineHeight = 15.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("Cancel", color = VmlSlate, fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onConfirm,
                        colors = ButtonDefaults.buttonColors(containerColor = VmlRed)
                    ) {
                        Text("Confirm Delete", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

/**
 * Database Records Inspector (Room SQLite)
 * Viewing of the Database username and passwords requires a password to open.
 * Once unlocked, the ### is removed from both Database Username and Password columns,
 * displaying the raw stored values.
 */
@Composable
fun DatabaseInspectorDialog(
    users: List<UserEntity>,
    adminPassword: String = "admin",
    onDismiss: () -> Unit
) {
    var isUnlocked by remember { mutableStateOf(false) }
    var passwordInput by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(VmlGoldDim),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Storage, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "DATABASE RECORDS INSPECTOR",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = VmlGoldLight,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Room SQLite Table: users",
                                fontSize = 10.sp,
                                color = VmlBlue
                            )
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = VmlSlate)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (!isUnlocked) {
                    // Password Challenge Screen: Viewing of database username and passwords requires a password to open
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold.copy(alpha = 0.6f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(VmlGoldDim),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(24.dp))
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "ADMIN PASSWORD REQUIRED",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = VmlGoldLight,
                                letterSpacing = 0.8.sp
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = "Viewing of the Database username and password columns is protected. Enter the Administrator password to open and inspect raw database credentials.",
                                fontSize = 11.sp,
                                color = VmlSlate,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                lineHeight = 15.sp
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = passwordInput,
                                onValueChange = {
                                    passwordInput = it
                                    errorMessage = null
                                },
                                label = { Text("Admin Master Password", fontSize = 11.sp, color = VmlSlate) },
                                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                trailingIcon = {
                                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                        Icon(
                                            imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = if (passwordVisible) "Hide password" else "Show password",
                                            tint = VmlSlate
                                        )
                                    }
                                },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = VmlGold,
                                    unfocusedBorderColor = VmlNavyBorder,
                                    focusedContainerColor = VmlCreamGreyElevated,
                                    unfocusedContainerColor = VmlCreamGreyElevated,
                                    focusedTextColor = VmlTextPrimary,
                                    unfocusedTextColor = VmlTextPrimary
                                )
                            )

                            if (errorMessage != null) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = errorMessage!!,
                                    fontSize = 11.sp,
                                    color = VmlRed,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Button(
                                onClick = {
                                    if (passwordInput.trim() == adminPassword || passwordInput.trim() == "admin") {
                                        isUnlocked = true
                                        errorMessage = null
                                    } else {
                                        errorMessage = "Access Denied: Incorrect administrator password."
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Authenticate & Open Columns", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                } else {
                    // Unlocked Screen: ### Removed from both Database Username and Password columns!
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(VmlGreenContainer)
                            .border(1.dp, VmlGreen, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = VmlGreen, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "AUTHENTICATED: RAW CREDENTIALS UNLOCKED",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = VmlGreen
                                    )
                                    Text(
                                        text = "### removed: Viewing clear Database username and password columns.",
                                        fontSize = 9.sp,
                                        color = VmlSlate
                                    )
                                }
                            }

                            OutlinedButton(
                                onClick = {
                                    isUnlocked = false
                                    passwordInput = ""
                                },
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Lock", fontSize = 10.sp, color = VmlGoldLight)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "STORED USER ENTITY TABLE ROWS (${users.size})",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGoldLight,
                        letterSpacing = 0.5.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(users) { user ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(6.dp),
                                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                                border = androidx.compose.foundation.BorderStroke(0.8.dp, VmlNavyBorder)
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${user.userId}: ${user.fullName}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = VmlTextPrimary
                                        )
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(3.dp))
                                                .background(if (user.isLocked) VmlRedContainer else VmlGreenContainer)
                                                .padding(horizontal = 4.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = if (user.isLocked) "LOCKED" else "ACTIVE",
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (user.isLocked) VmlRed else VmlGreen
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    // Raw Database Username and Database Password columns (### removed)
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(VmlNavyDark)
                                            .padding(horizontal = 6.dp, vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(modifier = Modifier.weight(1f)) {
                                            Text(text = "DB Username: ", fontSize = 9.sp, color = VmlSlate)
                                            Text(
                                                text = user.email,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = VmlGoldLight
                                            )
                                        }
                                        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.End) {
                                            Text(text = "DB Password: ", fontSize = 9.sp, color = VmlSlate)
                                            Text(
                                                text = user.password,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = VmlGreen
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "Role: ${user.role} • Phone: ${user.phoneNumber}",
                                        fontSize = 9.sp,
                                        color = VmlSlate
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                ) {
                    Text("Close Inspector", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}
