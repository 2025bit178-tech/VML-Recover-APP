package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CaseEntity
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatUgxShort
import com.example.ui.theme.VmlGold
import com.example.ui.theme.VmlGoldDim
import com.example.ui.theme.VmlGoldLight
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlNavy
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlSlate
import com.example.ui.theme.VmlTextPrimary
import com.example.viewmodel.VmlViewModel

@Composable
fun CaseListScreen(
    viewModel: VmlViewModel,
    onCaseSelected: (String) -> Unit,
    onOpenNewCaseDialog: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cases by viewModel.filteredCases.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedStatus by viewModel.selectedStatusFilter.collectAsState()
    val selectedAgeing by viewModel.selectedAgeingFilter.collectAsState()

    val statusFilters = listOf("ALL", "CRITICAL", "ACTIVE", "LEGAL", "PROMISE_PENDING", "CLOSED")
    val ageingFilters = listOf("ALL", "0-30", "31-60", "61-90", "91-180", "181-365", "1+ year")

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = VmlNavyDark,
        floatingActionButton = {
            FloatingActionButton(
                onClick = onOpenNewCaseDialog,
                containerColor = VmlGold,
                contentColor = VmlNavyDark,
                modifier = Modifier.testTag("fab_new_case")
            ) {
                Icon(Icons.Default.Add, contentDescription = "New Case")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header / Search Bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(VmlNavyDark)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text("Search debtor, Case ID, creditor, phone...", fontSize = 13.sp, color = VmlSlate) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = VmlGoldLight) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = VmlSlate)
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_cases_input"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VmlGold,
                        unfocusedBorderColor = VmlNavyBorder,
                        focusedContainerColor = VmlNavySurface,
                        unfocusedContainerColor = VmlNavySurface,
                        focusedTextColor = VmlTextPrimary,
                        unfocusedTextColor = VmlTextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Status Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    statusFilters.forEach { status ->
                        val isSelected = selectedStatus == status
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setStatusFilter(status) },
                            label = { Text(status.replace("_", " "), fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = VmlGold,
                                selectedLabelColor = VmlNavyDark,
                                containerColor = VmlNavySurface,
                                labelColor = VmlSlate
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) VmlGold else VmlNavyBorder
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Ageing Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Ageing:",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlSlate
                    )
                    ageingFilters.forEach { ageing ->
                        val isSelected = selectedAgeing == ageing
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setAgeingFilter(ageing) },
                            label = { Text(ageing, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = VmlGoldDim,
                                selectedLabelColor = VmlGoldLight,
                                containerColor = VmlNavyDark,
                                labelColor = VmlSlate
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) VmlGoldLight else VmlNavyBorder
                            )
                        )
                    }
                }
            }

            // Cases Count Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${cases.size} DEBT RECOVERY CASES FOUND",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = VmlSlate,
                    letterSpacing = 1.sp
                )
            }

            // Case List
            if (cases.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.FilterList,
                            contentDescription = "No cases",
                            tint = VmlSlate,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No cases match current filter",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlTextPrimary
                        )
                        Text(
                            text = "Try adjusting your search terms or status criteria",
                            fontSize = 12.sp,
                            color = VmlSlate
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(cases) { caseItem ->
                        CaseListItem(
                            caseItem = caseItem,
                            onClick = { onCaseSelected(caseItem.caseId) }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(60.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun CaseListItem(
    caseItem: CaseEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("case_row_${caseItem.caseId}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Case ID & Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = caseItem.caseId,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = VmlGoldLight
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    StatusBadge(caseItem.status)
                }

                Text(
                    text = formatUgxShort(caseItem.outstandingBalance),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = VmlRed
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Debtor Name
            Text(
                text = caseItem.debtorName,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = VmlTextPrimary
            )

            // Creditor & Details
            Text(
                text = "${caseItem.creditorName} • Ref: ${caseItem.originalAgreementRef}",
                fontSize = 11.sp,
                color = VmlSlate
            )
            Text(
                text = "${caseItem.debtorEmployer} • ${caseItem.debtorPhone}",
                fontSize = 11.sp,
                color = VmlSlate
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Progress bar
            LinearProgressIndicator(
                progress = { (caseItem.recoveryPercentage / 100.0).toFloat().coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = VmlGreen,
                trackColor = VmlNavyDark
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Footer row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(VmlGoldDim)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = caseItem.legalStage.replace("_", " "),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlGoldLight
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = caseItem.ageingCategory,
                        fontSize = 10.sp,
                        color = VmlSlate
                    )
                }

                Text(
                    text = "Officer: ${caseItem.assignedOfficerName.split(" ").lastOrNull() ?: ""}",
                    fontSize = 10.sp,
                    color = VmlSlate,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
