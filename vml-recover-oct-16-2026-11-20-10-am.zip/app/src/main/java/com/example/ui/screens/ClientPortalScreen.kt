package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.CaseEntity
import com.example.data.model.PaymentTransactionEntity
import com.example.ui.components.AdaptiveSegmentedTabRow
import com.example.ui.components.PrintUtils
import com.example.ui.components.formatUgxShort
import com.example.ui.theme.VmlAmber
import com.example.ui.theme.VmlAmberContainer
import com.example.ui.theme.VmlBlue
import com.example.ui.theme.VmlBlueContainer
import com.example.ui.theme.VmlGold
import com.example.ui.theme.VmlGoldDim
import com.example.ui.theme.VmlGoldLight
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlGreenContainer
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlRedContainer
import com.example.ui.theme.VmlSlate
import com.example.ui.theme.VmlTextPrimary
import com.example.viewmodel.UserRole
import com.example.viewmodel.VmlViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class ClientSortOption(val label: String) {
    BANK("Bank / Creditor"),
    AMOUNT_DESC("Amount (High to Low)"),
    AMOUNT_ASC("Amount (Low to High)"),
    LOAN_AGING("Loan Aging"),
    SECTOR("Sector of Work"),
    LEGAL_LEVEL("Legal Case Level")
}

@Composable
fun ClientPortalScreen(
    viewModel: VmlViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val cases by viewModel.allCases.collectAsState()
    val allPayments by viewModel.allPayments.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val currentRole by viewModel.currentRole.collectAsState()

    // Determine Client context (if logged in as client or view-all)
    val clientName = currentUser?.organization?.takeIf { it.isNotBlank() } ?: "Stanbic Bank Uganda Ltd"
    val isClientSpecific = currentUser?.role?.equals("CLIENT", ignoreCase = true) == true

    // Base debtors list: Client can see all debtors or their assigned ones
    val baseCases = if (isClientSpecific && !clientName.contains("VML", ignoreCase = true)) {
        cases.filter {
            it.creditorName.contains(clientName.split(" ").first(), ignoreCase = true) ||
                    it.creditorName.contains("Stanbic", ignoreCase = true)
        }
    } else {
        cases
    }

    // Permissions:
    // Can Add: Admin, Director, Collection Manager, or user with explicitly permitted role
    val canAddClients = currentUser?.role in listOf("ADMIN", "DIRECTOR", "MANAGER", "OFFICER") ||
            currentRole in listOf(UserRole.ADMIN, UserRole.DIRECTOR, UserRole.COLLECTION_MANAGER, UserRole.COLLECTION_OFFICER)

    // Can Delete: Admin only
    val isAdmin = currentUser?.role in listOf("ADMIN", "DIRECTOR") || currentRole in listOf(UserRole.ADMIN, UserRole.DIRECTOR)

    // Filter & Sort State
    var selectedSortOption by remember { mutableStateOf(ClientSortOption.BANK) }
    var selectedDebtorTypeFilter by remember { mutableStateOf("ALL") } // ALL, COMPANY, INDIVIDUAL
    var selectedBankFilter by remember { mutableStateOf("ALL") }
    var selectedSectorFilter by remember { mutableStateOf("ALL") }
    var selectedLegalLevelFilter by remember { mutableStateOf("ALL") }
    var selectedAgingFilter by remember { mutableStateOf("ALL") }

    // Dialog States
    var showNewClientDialog by remember { mutableStateOf(false) }
    var viewingCaseDetail by remember { mutableStateOf<CaseEntity?>(null) }
    var casePendingDeletion by remember { mutableStateOf<CaseEntity?>(null) }

    // Get unique banks and sectors for dropdown filters
    val availableBanks = listOf("ALL") + cases.map { it.creditorName }.distinct()
    val availableSectors = listOf("ALL") + cases.map { it.sectorOfWork }.distinct()
    val availableLegalLevels = listOf("ALL", "PRE_LEGAL", "DEMAND_LETTER", "SUMMONS_ISSUED", "COURT_HEARING", "JUDGMENT_ENFORCEMENT", "COLLECTION", "LITIGATION")
    val availableAging = listOf("ALL", "0-30 days", "30_DAYS", "60_DAYS", "90_DAYS", "180_PLUS")

    // Filtered and Sorted Cases
    val processedCases = baseCases
        .filter { c ->
            val matchType = when (selectedDebtorTypeFilter) {
                "COMPANY" -> c.debtorType.equals("COMPANY", ignoreCase = true)
                "INDIVIDUAL" -> c.debtorType.equals("INDIVIDUAL", ignoreCase = true)
                else -> true
            }
            val matchBank = selectedBankFilter == "ALL" || c.creditorName.equals(selectedBankFilter, ignoreCase = true)
            val matchSector = selectedSectorFilter == "ALL" || c.sectorOfWork.equals(selectedSectorFilter, ignoreCase = true)
            val matchLegal = selectedLegalLevelFilter == "ALL" || c.legalStage.equals(selectedLegalLevelFilter, ignoreCase = true)
            val matchAging = selectedAgingFilter == "ALL" || c.ageingCategory.equals(selectedAgingFilter, ignoreCase = true)
            matchType && matchBank && matchSector && matchLegal && matchAging
        }
        .let { list ->
            when (selectedSortOption) {
                ClientSortOption.BANK -> list.sortedBy { it.creditorName }
                ClientSortOption.AMOUNT_DESC -> list.sortedByDescending { it.totalDebt }
                ClientSortOption.AMOUNT_ASC -> list.sortedBy { it.totalDebt }
                ClientSortOption.LOAN_AGING -> list.sortedBy { it.ageingCategory }
                ClientSortOption.SECTOR -> list.sortedBy { it.sectorOfWork }
                ClientSortOption.LEGAL_LEVEL -> list.sortedBy { it.legalStage }
            }
        }

    // Client Balance Computations
    val totalAssignedClaim = processedCases.sumOf { it.totalDebt }
    val totalRecovered = processedCases.sumOf { it.amountPaid }
    val totalOutstanding = (totalAssignedClaim - totalRecovered).coerceAtLeast(0.0)

    val selectedTab by viewModel.clientPortalTab.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(VmlNavyDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Client Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(VmlGoldDim),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.AccountBalance, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(22.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "CLIENT & DEBTOR DATABASE",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = VmlGoldLight,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = clientName,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VmlTextPrimary
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (canAddClients) {
                                Button(
                                    onClick = { showNewClientDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("btn_add_client")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, tint = VmlNavyDark, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Client", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlNavyDark)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Balance overview
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "TOTAL OUTSTANDING BALANCE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlSlate,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = formatUgxShort(totalOutstanding),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                color = VmlRed
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "ASSIGNED DEBTORS",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlSlate
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${processedCases.size} Accounts",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlGoldLight
                            )
                        }
                    }
                }
            }
        }

        // Debtor Type Toggle: Either Company or Individual
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "DEBTOR CATEGORY (COMPANY OR INDIVIDUAL)",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGoldLight,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedDebtorTypeFilter == "ALL",
                            onClick = { selectedDebtorTypeFilter = "ALL" },
                            label = { Text("All Debtors (${baseCases.size})", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = VmlGold,
                                selectedLabelColor = VmlNavyDark,
                                containerColor = VmlNavyDark,
                                labelColor = VmlTextPrimary
                            )
                        )
                        FilterChip(
                            selected = selectedDebtorTypeFilter == "COMPANY",
                            onClick = { selectedDebtorTypeFilter = "COMPANY" },
                            leadingIcon = { Icon(Icons.Default.Business, contentDescription = null, modifier = Modifier.size(14.dp)) },
                            label = { Text("Company (${baseCases.count { it.debtorType.equals("COMPANY", true) }})", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = VmlAmber,
                                selectedLabelColor = VmlNavyDark,
                                containerColor = VmlNavyDark,
                                labelColor = VmlTextPrimary
                            )
                        )
                        FilterChip(
                            selected = selectedDebtorTypeFilter == "INDIVIDUAL",
                            onClick = { selectedDebtorTypeFilter = "INDIVIDUAL" },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(14.dp)) },
                            label = { Text("Individual (${baseCases.count { it.debtorType.equals("INDIVIDUAL", true) }})", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = VmlBlue,
                                selectedLabelColor = Color.White,
                                containerColor = VmlNavyDark,
                                labelColor = VmlTextPrimary
                            )
                        )
                    }
                }
            }
        }

        // Sorting Controls Row: Sort according to Bank, Amount, Loan Aging, Sector of Work, Legal Case Level
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Sort, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "SORT DEBTORS ACCORDING TO:",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = VmlGoldLight,
                                letterSpacing = 1.sp
                            )
                        }
                        Text(
                            text = selectedSortOption.label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlTextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Horizontal scrollable sort chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ClientSortOption.values().forEach { option ->
                            FilterChip(
                                selected = selectedSortOption == option,
                                onClick = { selectedSortOption = option },
                                label = { Text(option.label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = VmlGold,
                                    selectedLabelColor = VmlNavyDark,
                                    containerColor = VmlNavyDark,
                                    labelColor = VmlSlate
                                )
                            )
                        }
                    }
                }
            }
        }

        // Sub-filters row: Bank, Sector, Legal Stage
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterDropdownButton(
                    label = "Bank: ${if (selectedBankFilter == "ALL") "All Banks" else selectedBankFilter}",
                    options = availableBanks,
                    selected = selectedBankFilter,
                    onSelect = { selectedBankFilter = it }
                )
                FilterDropdownButton(
                    label = "Sector: ${if (selectedSectorFilter == "ALL") "All Sectors" else selectedSectorFilter}",
                    options = availableSectors,
                    selected = selectedSectorFilter,
                    onSelect = { selectedSectorFilter = it }
                )
                FilterDropdownButton(
                    label = "Legal: ${if (selectedLegalLevelFilter == "ALL") "All Levels" else selectedLegalLevelFilter}",
                    options = availableLegalLevels,
                    selected = selectedLegalLevelFilter,
                    onSelect = { selectedLegalLevelFilter = it }
                )
                FilterDropdownButton(
                    label = "Aging: ${if (selectedAgingFilter == "ALL") "All Aging" else selectedAgingFilter}",
                    options = availableAging,
                    selected = selectedAgingFilter,
                    onSelect = { selectedAgingFilter = it }
                )
            }
        }

        // Debtor List Count Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ASSIGNED DEBTORS (${processedCases.size})",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    color = VmlGoldLight,
                    letterSpacing = 1.sp
                )

                if (selectedBankFilter != "ALL" || selectedSectorFilter != "ALL" || selectedLegalLevelFilter != "ALL" || selectedAgingFilter != "ALL" || selectedDebtorTypeFilter != "ALL") {
                    Text(
                        text = "Reset Filters",
                        fontSize = 11.sp,
                        color = VmlBlue,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable {
                            selectedBankFilter = "ALL"
                            selectedSectorFilter = "ALL"
                            selectedLegalLevelFilter = "ALL"
                            selectedAgingFilter = "ALL"
                            selectedDebtorTypeFilter = "ALL"
                        }
                    )
                }
            }
        }

        // Debtors List
        if (processedCases.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.FilterList, contentDescription = null, tint = VmlSlate, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No debtors match current filters",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlTextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Try clearing the sector, bank, or legal level filters.",
                            fontSize = 11.sp,
                            color = VmlSlate
                        )
                    }
                }
            }
        } else {
            items(processedCases) { caseItem ->
                DebtorClientCard(
                    caseItem = caseItem,
                    isAdmin = isAdmin,
                    onViewStatement = { viewingCaseDetail = caseItem },
                    onPrintStatement = {
                        val relatedPayments = allPayments.filter { it.caseId == caseItem.caseId }
                        val html = PrintUtils.generateAccountStatementHtml(caseItem, relatedPayments)
                        PrintUtils.printDocument(context, "Statement_${caseItem.caseId}", html)
                    },
                    onDeleteRequest = {
                        if (isAdmin) {
                            casePendingDeletion = caseItem
                        } else {
                            Toast.makeText(context, "Permission Denied: Deleting anything requires Administrator permission.", Toast.LENGTH_LONG).show()
                        }
                    }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(60.dp))
        }
    }

    // Modal Statement & Detail Dialog
    if (viewingCaseDetail != null) {
        val item = viewingCaseDetail!!
        val casePayments = allPayments.filter { it.caseId == item.caseId }

        Dialog(onDismissRequest = { viewingCaseDetail = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
            ) {
                Column(
                    modifier = Modifier
                        .padding(18.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "DEBTOR ACCOUNT STATEMENT",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            color = VmlGoldLight,
                            letterSpacing = 1.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Print button for statement
                            IconButton(
                                onClick = {
                                    val html = PrintUtils.generateAccountStatementHtml(item, casePayments)
                                    PrintUtils.printDocument(context, "Statement_${item.caseId}", html)
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Print, contentDescription = "Print Statement", tint = VmlGoldLight)
                            }
                            IconButton(
                                onClick = { viewingCaseDetail = null },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = VmlSlate)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = item.debtorName, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                    Text(text = "Bank: ${item.creditorName} • Sector: ${item.sectorOfWork}", fontSize = 11.sp, color = VmlSlate)
                    Text(text = "Stage: ${item.legalStage} • Ageing: ${item.ageingCategory}", fontSize = 11.sp, color = VmlGoldLight)

                    Spacer(modifier = Modifier.height(14.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            ClientBalanceRow("Principal Assigned", formatUgxShort(item.principalAmount), VmlTextPrimary)
                            ClientBalanceRow("Interest Accrued", formatUgxShort(item.interestAmount), VmlTextPrimary)
                            ClientBalanceRow("Penalty / Statutory Fees", formatUgxShort(item.penaltiesAmount), VmlAmber)
                            ClientBalanceRow("Total Claim Instructed", formatUgxShort(item.totalDebt), VmlGoldLight)
                            ClientBalanceRow("Total Recovered (Paid)", formatUgxShort(item.amountPaid), VmlGreen)
                            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(VmlNavyBorder).padding(vertical = 4.dp))
                            ClientBalanceRow("NET OUTSTANDING BALANCE", formatUgxShort(item.outstandingBalance), VmlRed)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Print action button inside dialog
                    Button(
                        onClick = {
                            val html = PrintUtils.generateAccountStatementHtml(item, casePayments)
                            PrintUtils.printDocument(context, "Statement_${item.caseId}", html)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, tint = VmlNavyDark, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Print Official Document", color = VmlNavyDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Admin Deletion Confirmation Dialog
    if (casePendingDeletion != null) {
        val targetCase = casePendingDeletion!!
        Dialog(onDismissRequest = { casePendingDeletion = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, VmlRed)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(VmlRedContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = VmlRed, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "ADMIN AUTHORIZATION REQUIRED",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = VmlRed
                            )
                            Text(
                                text = "Confirm Deletion of Debtor",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlTextPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "You are deleting case ${targetCase.caseId} for debtor ${targetCase.debtorName} (Bank: ${targetCase.creditorName}). This action requires Administrator permission and will permanently remove this obligation.",
                        fontSize = 11.sp,
                        color = VmlTextPrimary,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = { casePendingDeletion = null },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Cancel", color = VmlSlate)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                viewModel.deleteCase(targetCase.caseId) { success, msg ->
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                    casePendingDeletion = null
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = VmlRed),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Authorize & Delete", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Add Client Dialog
    if (showNewClientDialog) {
        NewClientDebtorDialog(
            onDismiss = { showNewClientDialog = false },
            onSubmit = { dName, dId, phone, email, address, employer, cred, acc, ref, p, i, pen, off, dtype, sector ->
                viewModel.registerNewCase(dName, dId, phone, email, address, employer, cred, acc, ref, p, i, pen, off)
                Toast.makeText(context, "Debtor $dName added successfully under $cred", Toast.LENGTH_SHORT).show()
                showNewClientDialog = false
            }
        )
    }
}

@Composable
fun DebtorClientCard(
    caseItem: CaseEntity,
    isAdmin: Boolean,
    onViewStatement: () -> Unit,
    onPrintStatement: () -> Unit,
    onDeleteRequest: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onViewStatement() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Case ID, Type, Bank Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = caseItem.caseId,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = VmlGoldLight
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (caseItem.debtorType.equals("COMPANY", true)) VmlAmberContainer else VmlBlueContainer)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = caseItem.debtorType.uppercase(),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (caseItem.debtorType.equals("COMPANY", true)) VmlAmber else VmlBlue
                        )
                    }
                }

                // Bank Name
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(VmlNavyDark)
                        .border(1.dp, VmlGold.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = caseItem.creditorName,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGoldLight
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Debtor Name
            Text(
                text = caseItem.debtorName,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = VmlTextPrimary
            )

            // Dimensions: Sector, Legal Level, Aging
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Sector: ${caseItem.sectorOfWork}",
                    fontSize = 10.sp,
                    color = VmlSlate
                )
                Text(text = "•", fontSize = 10.sp, color = VmlNavyBorder)
                Text(
                    text = "Legal: ${caseItem.legalStage}",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = VmlGoldLight
                )
                Text(text = "•", fontSize = 10.sp, color = VmlNavyBorder)
                Text(
                    text = "Aging: ${caseItem.ageingCategory}",
                    fontSize = 10.sp,
                    color = VmlAmber
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Amount summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Total Debt", fontSize = 9.sp, color = VmlSlate)
                    Text(text = formatUgxShort(caseItem.totalDebt), fontSize = 11.sp, color = VmlTextPrimary, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "Amount Paid", fontSize = 9.sp, color = VmlSlate)
                    Text(text = formatUgxShort(caseItem.amountPaid), fontSize = 11.sp, color = VmlGreen, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "Outstanding", fontSize = 9.sp, color = VmlSlate)
                    Text(text = formatUgxShort(caseItem.outstandingBalance), fontSize = 13.sp, color = VmlRed, fontWeight = FontWeight.Black)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Actions: Print Document & Delete (Admin-protected)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onPrintStatement,
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold.copy(alpha = 0.5f))
                ) {
                    Icon(Icons.Default.Print, contentDescription = "Print", tint = VmlGoldLight, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Print Document", fontSize = 10.sp, color = VmlGoldLight, fontWeight = FontWeight.Bold)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = onViewStatement,
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("View Statement", fontSize = 10.sp, color = VmlTextPrimary)
                    }

                    // Delete button with explicit admin check
                    Button(
                        onClick = onDeleteRequest,
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isAdmin) VmlRedContainer else VmlNavyDark
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isAdmin) VmlRed else VmlNavyBorder)
                    ) {
                        Text(
                            text = if (isAdmin) "Delete" else "Delete (Admin)",
                            fontSize = 10.sp,
                            color = if (isAdmin) VmlRed else VmlSlate,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FilterDropdownButton(
    label: String,
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = VmlNavySurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, if (selected != "ALL") VmlGold else VmlNavyBorder),
            modifier = Modifier.clickable { expanded = true }
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = label,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (selected != "ALL") VmlGoldLight else VmlTextPrimary
                )
            }
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(VmlNavySurface)
        ) {
            options.forEach { opt ->
                DropdownMenuItem(
                    text = {
                        Text(
                            text = if (opt == "ALL") "All" else opt,
                            color = if (opt == selected) VmlGoldLight else VmlTextPrimary,
                            fontWeight = if (opt == selected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 11.sp
                        )
                    },
                    onClick = {
                        onSelect(opt)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun ClientBalanceRow(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 11.sp, color = VmlSlate)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = valueColor)
    }
}

@Composable
fun NewClientDebtorDialog(
    onDismiss: () -> Unit,
    onSubmit: (
        debtorName: String,
        debtorId: String,
        phone: String,
        email: String,
        address: String,
        employer: String,
        creditorName: String,
        creditorAcc: String,
        agreementRef: String,
        principal: Double,
        interest: Double,
        penalties: Double,
        officer: String,
        debtorType: String,
        sector: String
    ) -> Unit
) {
    var debtorName by remember { mutableStateOf("") }
    var debtorId by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("+256 ") }
    var email by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var employer by remember { mutableStateOf("") }
    var creditorName by remember { mutableStateOf("Stanbic Bank Uganda Ltd") }
    var creditorAcc by remember { mutableStateOf("") }
    var agreementRef by remember { mutableStateOf("") }
    var principalStr by remember { mutableStateOf("") }
    var interestStr by remember { mutableStateOf("") }
    var penaltiesStr by remember { mutableStateOf("") }
    var officer by remember { mutableStateOf("Officer David Ochieng") }
    var debtorType by remember { mutableStateOf("INDIVIDUAL") }
    var sector by remember { mutableStateOf("Trade & Retail") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
        ) {
            Column(
                modifier = Modifier
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ADD CLIENT DEBTOR TO DATABASE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = VmlGoldLight,
                        letterSpacing = 1.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = VmlSlate)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Debtor Entity Type: Company or Individual
                Text(text = "Entity Classification", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = debtorType == "INDIVIDUAL",
                        onClick = { debtorType = "INDIVIDUAL" },
                        label = { Text("Individual Debtor", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = debtorType == "COMPANY",
                        onClick = { debtorType = "COMPANY" },
                        label = { Text("Company Debtor", fontSize = 11.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                androidx.compose.material3.OutlinedTextField(
                    value = debtorName,
                    onValueChange = { debtorName = it },
                    label = { Text(if (debtorType == "COMPANY") "Company Name *" else "Debtor Full Name *", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(6.dp))
                androidx.compose.material3.OutlinedTextField(
                    value = creditorName,
                    onValueChange = { creditorName = it },
                    label = { Text("Creditor Bank / Financial Institution *", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(6.dp))
                androidx.compose.material3.OutlinedTextField(
                    value = sector,
                    onValueChange = { sector = it },
                    label = { Text("Sector of Work (e.g. Logistics, Trade, Agriculture)", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(6.dp))
                androidx.compose.material3.OutlinedTextField(
                    value = principalStr,
                    onValueChange = { principalStr = it },
                    label = { Text("Principal Amount (UGX) *", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(6.dp))
                androidx.compose.material3.OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Telephone Contact *", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(6.dp))
                androidx.compose.material3.OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Registered Physical Address", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(14.dp))
                Button(
                    onClick = {
                        val principal = principalStr.toDoubleOrNull() ?: 0.0
                        val interest = interestStr.toDoubleOrNull() ?: 0.0
                        val penalties = penaltiesStr.toDoubleOrNull() ?: 0.0
                        if (debtorName.isNotBlank() && principal > 0) {
                            onSubmit(
                                debtorName, debtorId, phone, email, address, employer,
                                creditorName, creditorAcc, agreementRef, principal,
                                interest, penalties, officer, debtorType, sector
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                ) {
                    Text("Register Debtor into Database", color = VmlNavyDark, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
