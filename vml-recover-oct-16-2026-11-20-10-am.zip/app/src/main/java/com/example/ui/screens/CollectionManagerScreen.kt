package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AssignmentInd
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SupervisorAccount
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.CaseEntity
import com.example.ui.components.AdaptiveSegmentedTabRow
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatUgxShort
import com.example.ui.theme.VmlAmber
import com.example.ui.theme.VmlAmberContainer
import com.example.ui.theme.VmlBlue
import com.example.ui.theme.VmlBlueContainer
import com.example.ui.theme.VmlCreamGreyElevated
import com.example.ui.theme.VmlGold
import com.example.ui.theme.VmlGoldDim
import com.example.ui.theme.VmlGoldLight
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlGreenContainer
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlRedContainer
import com.example.ui.theme.VmlSlate
import com.example.ui.theme.VmlTextPrimary
import com.example.ui.theme.VmlTextSecondary
import com.example.viewmodel.VmlViewModel

@Composable
fun CollectionManagerScreen(
    viewModel: VmlViewModel,
    onNavigateToCaseDetail: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val cases by viewModel.allCases.collectAsState()
    val metrics by viewModel.portfolioMetrics.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    val selectedTab by viewModel.collectionManagerTab.collectAsState()
    var reallocatingCase by remember { mutableStateOf<CaseEntity?>(null) }

    val officersList = listOf(
        "OFF-001" to "Officer David Ochieng",
        "OFF-002" to "Officer Ronald Ssenyonga",
        "OFF-003" to "Officer Beatrice Alupo",
        "OFF-004" to "Officer Moses Kiggundu"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(VmlNavyDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Manager Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold.copy(alpha = 0.8f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(VmlGoldDim),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.SupervisorAccount, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "COLLECTIONS MANAGER",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = VmlGoldLight,
                                    letterSpacing = 1.2.sp
                                )
                                Text(
                                    text = "Case Allocation & Supervisory Oversight",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VmlTextPrimary
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(VmlBlueContainer)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = "MANAGER ACTIVE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VmlBlue)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Manager KPI summary
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Active Portfolio", fontSize = 10.sp, color = VmlSlate)
                            Text(text = "${cases.size} Files", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "Monthly Recovery Target", fontSize = 10.sp, color = VmlSlate)
                            Text(text = "UGX 185M / 320M (58%)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlGreen)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Officers Supervised", fontSize = 10.sp, color = VmlSlate)
                            Text(text = "4 Field Officers", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlGoldLight)
                        }
                    }
                }
            }
        }

        // Adaptive Cross-Platform Tabs (iOS & Android)
        item {
            AdaptiveSegmentedTabRow(
                tabs = listOf("Supervision & Team Workload", "Case Allocation (${cases.size})"),
                selectedIndex = selectedTab,
                onTabSelected = { viewModel.setCollectionManagerTab(it) }
            )
        }

        if (selectedTab == 0) {
            // TAB 0: SUPERVISION & WORKLOAD
            item {
                Text(
                    text = "FIELD OFFICER WORKLOAD ALLOCATION",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = VmlGoldLight,
                    letterSpacing = 1.sp
                )
            }

            item {
                OfficerWorkloadCard(
                    name = "Officer David Ochieng",
                    zone = "Kampala Central Commercial District",
                    casesAssigned = 48,
                    claimVolume = 1_420_000_000.0,
                    recovered = 580_000_000.0,
                    rate = 40.8f,
                    status = "HIGH LOAD • OPTIMAL YIELD"
                )
            }

            item {
                OfficerWorkloadCard(
                    name = "Officer Ronald Ssenyonga",
                    zone = "Entebbe & Wakiso Industrial Corridor",
                    casesAssigned = 42,
                    claimVolume = 1_180_000_000.0,
                    recovered = 440_000_000.0,
                    rate = 37.3f,
                    status = "BALANCED CAPACITY"
                )
            }

            item {
                OfficerWorkloadCard(
                    name = "Officer Beatrice Alupo",
                    zone = "Jinja & Eastern Agro-Industrial Hub",
                    casesAssigned = 32,
                    claimVolume = 980_000_000.0,
                    recovered = 350_000_000.0,
                    rate = 35.7f,
                    status = "AVAILABLE CAPACITY"
                )
            }

            item {
                OfficerWorkloadCard(
                    name = "Officer Moses Kiggundu",
                    zone = "Mbarara & Western Trade Belt",
                    casesAssigned = 20,
                    claimVolume = 1_240_000_000.0,
                    recovered = 390_000_000.0,
                    rate = 31.5f,
                    status = "AVAILABLE FOR ALLOCATION"
                )
            }

            // Supervisory Escalation Approval Queue
            item {
                Text(
                    text = "SUPERVISORY ESCALATION APPROVAL QUEUE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = VmlGoldLight,
                    letterSpacing = 1.sp
                )
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlAmber)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "Walusimbi Maize Mills Ltd", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                            Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(VmlAmberContainer).padding(horizontal = 6.dp, vertical = 2.dp)) {
                                Text(text = "ESCALATION REQUESTED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VmlAmber)
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Claim: UGX 117,000,000 • Assigned: Officer David Ochieng", fontSize = 11.sp, color = VmlSlate)
                        Text(text = "Officer Reason: Debtor defaulted on second statutory notice. Recommended transfer to Legal Chambers for Commercial Court Plaint.", fontSize = 10.sp, color = VmlSlate)

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Button(
                                onClick = {
                                    viewModel.escalateLegalStage("VML-2026-00391", "LITIGATION", "Manager approved escalation to High Court.")
                                    Toast.makeText(context, "Escalation approved for High Court litigation.", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("Approve Legal Escalation", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        } else {
            // TAB 1: CASE ALLOCATION ENGINE
            item {
                Text(
                    text = "CASE ALLOCATION & REASSIGNMENT ENGINE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = VmlGoldLight,
                    letterSpacing = 1.sp
                )
            }

            items(cases) { c ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = c.caseId, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VmlGoldLight)
                                Spacer(modifier = Modifier.width(6.dp))
                                StatusBadge(c.status)
                            }
                            Text(text = formatUgxShort(c.outstandingBalance), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlRed)
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = c.debtorName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                        Text(text = "${c.creditorName} • ${c.debtorAddress}", fontSize = 10.sp, color = VmlSlate)

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = "Currently Assigned Officer:", fontSize = 9.sp, color = VmlSlate)
                                Text(text = c.assignedOfficerName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlBlue)
                            }

                            Button(
                                onClick = { reallocatingCase = c },
                                colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 3.dp),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("Reassign Officer", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Reallocate Officer Dialog
    if (reallocatingCase != null) {
        ReallocateOfficerDialog(
            caseEntity = reallocatingCase!!,
            officers = officersList,
            onDismiss = { reallocatingCase = null },
            onConfirm = { officerId, officerName, reason ->
                viewModel.reassignCase(reallocatingCase!!.caseId, officerId, officerName, reason) {
                    Toast.makeText(context, "Case reallocated to $officerName.", Toast.LENGTH_SHORT).show()
                    reallocatingCase = null
                }
            }
        )
    }
}

@Composable
fun OfficerWorkloadCard(
    name: String,
    zone: String,
    casesAssigned: Int,
    claimVolume: Double,
    recovered: Double,
    rate: Float,
    status: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(VmlGoldDim).padding(horizontal = 6.dp, vertical = 2.dp)) {
                    Text(text = status, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = VmlGoldLight)
                }
            }
            Text(text = zone, fontSize = 10.sp, color = VmlSlate)

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Active Files: $casesAssigned", fontSize = 11.sp, color = VmlSlate)
                Text(text = "Claim: ${formatUgxShort(claimVolume)}", fontSize = 11.sp, color = VmlSlate)
                Text(text = "Recovered: ${formatUgxShort(recovered)} (${String.format("%.1f", rate)}%)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = VmlGreen)
            }

            Spacer(modifier = Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { (rate / 100f).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                color = VmlGreen,
                trackColor = VmlNavyDark
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReallocateOfficerDialog(
    caseEntity: CaseEntity,
    officers: List<Pair<String, String>>,
    onDismiss: () -> Unit,
    onConfirm: (String, String, String) -> Unit
) {
    var selectedOfficerId by remember { mutableStateOf(officers.first().first) }
    var selectedOfficerName by remember { mutableStateOf(officers.first().second) }
    var reason by remember { mutableStateOf("Workload rebalancing and specialized geographic proximity.") }
    var expandedDropdown by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "REALLOCATE CASE OFFICER",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = VmlGoldLight,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = "${caseEntity.caseId} • ${caseEntity.debtorName}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                Text(text = "Current Officer: ${caseEntity.assignedOfficerName}", fontSize = 11.sp, color = VmlSlate)

                Spacer(modifier = Modifier.height(12.dp))

                ExposedDropdownMenuBox(
                    expanded = expandedDropdown,
                    onExpandedChange = { expandedDropdown = it }
                ) {
                    OutlinedTextField(
                        value = selectedOfficerName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Select New Officer", fontSize = 11.sp, color = VmlSlate) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDropdown) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VmlGold,
                            unfocusedBorderColor = VmlNavyBorder,
                            focusedContainerColor = VmlCreamGreyElevated,
                            unfocusedContainerColor = VmlCreamGreyElevated,
                            focusedTextColor = VmlTextPrimary,
                            unfocusedTextColor = VmlTextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )

                    ExposedDropdownMenu(
                        expanded = expandedDropdown,
                        onDismissRequest = { expandedDropdown = false },
                        modifier = Modifier.background(VmlNavySurface)
                    ) {
                        officers.forEach { (id, name) ->
                            DropdownMenuItem(
                                text = { Text(text = name, fontSize = 12.sp, color = VmlTextPrimary) },
                                onClick = {
                                    selectedOfficerId = id
                                    selectedOfficerName = name
                                    expandedDropdown = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("Managerial Reallocation Reason", fontSize = 11.sp, color = VmlSlate) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VmlGold,
                        unfocusedBorderColor = VmlNavyBorder,
                        focusedContainerColor = VmlCreamGreyElevated,
                        unfocusedContainerColor = VmlCreamGreyElevated,
                        focusedTextColor = VmlTextPrimary,
                        unfocusedTextColor = VmlTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("Cancel", color = VmlSlate)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onConfirm(selectedOfficerId, selectedOfficerName, reason) },
                        colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                    ) {
                        Text("Confirm Reallocation", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
