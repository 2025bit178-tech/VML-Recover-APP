package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.UserEntity
import com.example.ui.theme.VmlCreamGreyElevated
import com.example.ui.theme.VmlGold
import com.example.ui.theme.VmlGoldDim
import com.example.ui.theme.VmlGoldLight
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlSlate
import com.example.ui.theme.VmlTextPrimary
import com.example.viewmodel.UserRole
import com.example.viewmodel.VmlViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPasswordManagementDialog(
    viewModel: VmlViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val users by viewModel.allUsers.collectAsState()
    val currentRole by viewModel.currentRole.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    val isAdmin = currentRole in listOf(UserRole.ADMIN, UserRole.DIRECTOR) || currentUser?.role in listOf("ADMIN", "DIRECTOR")

    var selectedUser by remember(users) {
        mutableStateOf(users.firstOrNull { it.userId == "USR-002" } ?: users.firstOrNull())
    }
    var expandedUserMenu by remember { mutableStateOf(false) }

    var currentPasswordVisible by remember { mutableStateOf(true) }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(VmlGoldDim),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = null,
                            tint = VmlGoldLight,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "SECURITY & PASSWORD CONTROL",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            color = VmlGoldLight,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Admin-Exclusive Password Authority",
                            fontSize = 11.sp,
                            color = VmlSlate
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (!isAdmin) {
                    // Non-admin warning block
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(VmlNavySurface)
                            .border(1.dp, VmlRed, RoundedCornerShape(8.dp))
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = VmlRed, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "ACCESS RESTRICTED",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VmlRed
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Only the System Administrator / Director has authority to modify user passwords. Please contact VML Administration to request a credential reset.",
                                fontSize = 11.sp,
                                color = VmlTextPrimary,
                                lineHeight = 16.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = VmlNavySurface)
                    ) {
                        Text("Close", color = VmlSlate)
                    }
                    return@Column
                }

                // Admin Authorized View
                Text(
                    text = "Select Account to Change Password:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = VmlTextPrimary
                )

                Spacer(modifier = Modifier.height(6.dp))

                // User Selector Dropdown
                ExposedDropdownMenuBox(
                    expanded = expandedUserMenu,
                    onExpandedChange = { expandedUserMenu = it }
                ) {
                    OutlinedTextField(
                        value = if (selectedUser != null) "${selectedUser!!.fullName} (${selectedUser!!.role})" else "Select user",
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedUserMenu) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VmlGold,
                            unfocusedBorderColor = VmlNavyBorder,
                            focusedContainerColor = VmlCreamGreyElevated,
                            unfocusedContainerColor = VmlCreamGreyElevated,
                            focusedTextColor = VmlTextPrimary,
                            unfocusedTextColor = VmlTextPrimary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )

                    ExposedDropdownMenu(
                        expanded = expandedUserMenu,
                        onDismissRequest = { expandedUserMenu = false },
                        modifier = Modifier.background(VmlNavySurface)
                    ) {
                        users.forEach { user ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(text = user.fullName, fontWeight = FontWeight.Bold, color = VmlTextPrimary, fontSize = 13.sp)
                                        Text(text = "${user.role} • ${user.email}", fontSize = 10.sp, color = VmlSlate)
                                    }
                                },
                                onClick = {
                                    selectedUser = user
                                    expandedUserMenu = false
                                    errorMessage = null
                                    successMessage = null
                                }
                            )
                        }
                    }
                }

                if (selectedUser != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(text = "Target Account ID: ${selectedUser!!.userId}", fontSize = 11.sp, color = VmlGoldLight, fontWeight = FontWeight.Bold)
                            Text(text = "Email / Login ID: ${selectedUser!!.email}", fontSize = 11.sp, color = VmlTextPrimary)
                            Text(text = "Department: ${selectedUser!!.department}", fontSize = 10.sp, color = VmlSlate)

                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(VmlNavyDark)
                                    .border(1.dp, VmlGold.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Key, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Current Password: ", fontSize = 11.sp, color = VmlSlate, fontWeight = FontWeight.Medium)
                                Text(
                                    text = if (currentPasswordVisible) selectedUser!!.password else "••••••••",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (currentPasswordVisible) VmlGoldLight else VmlSlate
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                IconButton(
                                    onClick = { currentPasswordVisible = !currentPasswordVisible },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = if (currentPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = "Toggle password visibility",
                                        tint = VmlGoldLight,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // New Password Input (Horizontal Row)
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("New Password", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = VmlSlate, modifier = Modifier.width(105.dp))
                    OutlinedTextField(
                        value = newPassword,
                        onValueChange = {
                            newPassword = it
                            errorMessage = null
                            successMessage = null
                        },
                        placeholder = { Text("New password", color = VmlSlate.copy(alpha = 0.5f), fontSize = 11.sp) },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null,
                                    tint = VmlSlate,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        },
                        singleLine = true,
                        modifier = Modifier.weight(1f).height(42.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VmlGold,
                            unfocusedBorderColor = VmlNavyBorder,
                            focusedContainerColor = VmlCreamGreyElevated,
                            unfocusedContainerColor = VmlCreamGreyElevated,
                            focusedTextColor = VmlTextPrimary,
                            unfocusedTextColor = VmlTextPrimary
                        ),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = VmlTextPrimary)
                    )
                }

                // Confirm Password Input (Horizontal Row)
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Confirm Pass", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = VmlSlate, modifier = Modifier.width(105.dp))
                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = {
                            confirmPassword = it
                            errorMessage = null
                            successMessage = null
                        },
                        placeholder = { Text("Confirm password", color = VmlSlate.copy(alpha = 0.5f), fontSize = 11.sp) },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.weight(1f).height(42.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VmlGold,
                            unfocusedBorderColor = VmlNavyBorder,
                            focusedContainerColor = VmlCreamGreyElevated,
                            unfocusedContainerColor = VmlCreamGreyElevated,
                            focusedTextColor = VmlTextPrimary,
                            unfocusedTextColor = VmlTextPrimary
                        ),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = VmlTextPrimary)
                    )
                }

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = errorMessage!!, color = VmlRed, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }

                if (successMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = successMessage!!, color = VmlGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = VmlNavySurface)
                    ) {
                        Text("Cancel", color = VmlSlate)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            if (newPassword.isBlank() || newPassword.length < 3) {
                                errorMessage = "Password must be at least 3 characters."
                                return@Button
                            }
                            if (newPassword != confirmPassword) {
                                errorMessage = "Passwords do not match."
                                return@Button
                            }
                            if (selectedUser == null) {
                                errorMessage = "Please select a target user."
                                return@Button
                            }

                            viewModel.changeUserPassword(selectedUser!!.userId, newPassword) { success, msg ->
                                if (success) {
                                    successMessage = "Password successfully updated for ${selectedUser!!.fullName}!"
                                    newPassword = ""
                                    confirmPassword = ""
                                    Toast.makeText(context, "Password updated successfully!", Toast.LENGTH_SHORT).show()
                                } else {
                                    errorMessage = msg
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = VmlNavyDark, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Update Password", color = VmlNavyDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
