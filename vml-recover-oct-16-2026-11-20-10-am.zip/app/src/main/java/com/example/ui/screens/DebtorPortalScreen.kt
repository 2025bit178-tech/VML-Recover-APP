package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.components.AdaptiveSegmentedTabRow
import com.example.ui.components.formatUgxShort
import com.example.ui.theme.VmlAmber
import com.example.ui.theme.VmlAmberContainer
import com.example.ui.theme.VmlBlue
import com.example.ui.theme.VmlBlueContainer
import com.example.ui.theme.VmlCreamGreyElevated
import com.example.ui.theme.VmlGold
import com.example.ui.theme.VmlGoldDim
import com.example.ui.theme.VmlGoldLight
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlGreenContainer
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlRedContainer
import com.example.ui.theme.VmlSlate
import com.example.ui.theme.VmlTextPrimary
import com.example.ui.theme.VmlTextSecondary
import com.example.viewmodel.VmlViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DebtorPortalScreen(
    viewModel: VmlViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val cases by viewModel.allCases.collectAsState()
    val allPayments by viewModel.allPayments.collectAsState()
    val allPlans by viewModel.allPlans.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    // Debtor's own case: VML-2026-00482 (Mukasa Godfrey Kasule)
    val debtorCase = cases.find { it.caseId == "VML-2026-00482" } ?: cases.firstOrNull()
    val debtorPayments = allPayments.filter { it.caseId == debtorCase?.caseId }
    val debtorPlan = allPlans.find { it.caseId == debtorCase?.caseId }

    val selectedTab by viewModel.debtorPortalTab.collectAsState()
    var showPaymentSuccessDialog by remember { mutableStateOf<Pair<Double, String>?>(null) }

    // Direct Payment Form States
    var paymentAmountInput by remember { mutableStateOf("5000000") }
    var selectedChannel by remember { mutableStateOf("MTN Mobile Money") }
    var debtorPhoneInput by remember { mutableStateOf(debtorCase?.debtorPhone ?: "+256 772 458 912") }
    var isProcessingPayment by remember { mutableStateOf(false) }

    if (debtorCase == null) {
        Box(modifier = modifier.fillMaxSize().background(VmlNavyDark), contentAlignment = Alignment.Center) {
            Text("No debtor profile loaded.", color = VmlSlate)
        }
        return
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(VmlNavyDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Debtor Profile Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold.copy(alpha = 0.8f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(VmlGoldDim),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "DEBTOR SELF-SERVICE PORTAL",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = VmlGoldLight,
                                    letterSpacing = 1.2.sp
                                )
                                Text(
                                    text = debtorCase.debtorName,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VmlTextPrimary
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(VmlNavyDark)
                                .border(1.dp, VmlNavyBorder, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = debtorCase.caseId, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VmlGoldLight)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "National ID: ${debtorCase.debtorNationalId} • Creditor: ${debtorCase.creditorName} (${debtorCase.creditorAccountNumber})",
                        fontSize = 11.sp,
                        color = VmlSlate
                    )
                }
            }
        }

        // Adaptive Cross-Platform Tabs (iOS & Android)
        item {
            AdaptiveSegmentedTabRow(
                tabs = listOf("My Balance", "Payment Plan", "Make Payment"),
                selectedIndex = selectedTab,
                onTabSelected = { viewModel.setDebtorPortalTab(it) }
            )
        }

        if (selectedTab == 0) {
            // TAB 0: INDIVIDUAL BALANCE BREAKDOWN
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "CURRENT OUTSTANDING BALANCE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlSlate,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = formatUgxShort(debtorCase.outstandingBalance),
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = VmlRed
                        )
                        Text(
                            text = "Remaining balance required to obtain formal Certificate of Debt Clearance",
                            fontSize = 11.sp,
                            color = VmlSlate
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = { (debtorCase.recoveryPercentage / 100.0).toFloat().coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                            color = VmlGreen,
                            trackColor = VmlNavyDark
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Paid: ${formatUgxShort(debtorCase.amountPaid)}", fontSize = 10.sp, color = VmlGreen, fontWeight = FontWeight.Bold)
                            Text(text = "${String.format("%.1f", debtorCase.recoveryPercentage)}% Cleared", fontSize = 10.sp, color = VmlGoldLight, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "CERTIFIED DEBT ACCOUNT BREAKDOWN",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlGoldLight,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        DebtorBalanceRow("Original Principal Debt", formatUgxShort(debtorCase.principalAmount), VmlTextPrimary)
                        DebtorBalanceRow("Contractual Interest Accrued", formatUgxShort(debtorCase.interestAmount), VmlTextPrimary)
                        DebtorBalanceRow("Statutory Penalties & Late Fees", formatUgxShort(debtorCase.penaltiesAmount), VmlAmber)
                        DebtorBalanceRow("Total Instructed Claim", formatUgxShort(debtorCase.totalDebt), VmlGoldLight)
                        DebtorBalanceRow("Total Amount Paid to Date", formatUgxShort(debtorCase.amountPaid), VmlGreen)

                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(VmlNavyBorder).padding(vertical = 4.dp))
                        DebtorBalanceRow("NET OUTSTANDING BALANCE", formatUgxShort(debtorCase.outstandingBalance), VmlRed)
                    }
                }
            }

            // Quick Pay CTA
            item {
                Button(
                    onClick = { viewModel.setDebtorPortalTab(2) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = VmlGreen),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    Icon(Icons.Default.Payment, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Make an Instant Payment", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        } else if (selectedTab == 1) {
            // TAB 1: REPAYMENT PLAN
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "STRUCTURED REPAYMENT SCHEDULE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = VmlGoldLight,
                                letterSpacing = 1.sp
                            )
                            Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(VmlGreenContainer).padding(horizontal = 6.dp, vertical = 2.dp)) {
                                Text(text = "ON-SCHEDULE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VmlGreen)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        DebtorBalanceRow("Agreed Settlement Sum", "UGX 30,000,000", VmlGoldLight)
                        DebtorBalanceRow("Instalment Frequency", "Bi-Weekly Standing Order", VmlTextPrimary)
                        DebtorBalanceRow("Instalment Amount", "UGX 5,000,000 per cycle", VmlGreen)
                        DebtorBalanceRow("Next Due Milestone", "05 Oct 2026", VmlAmber)
                        DebtorBalanceRow("Legal Standstill Status", "Enforcement Stayed during Adherence", VmlBlue)
                    }
                }
            }

            item {
                Text(
                    text = "PAYMENT HISTORY (OFFICIAL RECEIPTS)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = VmlGoldLight,
                    letterSpacing = 1.sp
                )
            }

            val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())

            items(debtorPayments) { p ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Receipt, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = p.receiptNumber, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                            }
                            Text(text = "${sdf.format(Date(p.paymentDate))} • ${p.paymentChannel}", fontSize = 10.sp, color = VmlSlate)
                        }

                        Text(text = formatUgxShort(p.amount), fontSize = 13.sp, fontWeight = FontWeight.Black, color = VmlGreen)
                    }
                }
            }
        } else {
            // TAB 2: MAKE PAYMENT ONLY
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "INSTANT DEBT SETTLEMENT PAYMENT",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = VmlGoldLight,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Instant automated settlement receipt and balance reduction",
                            fontSize = 10.sp,
                            color = VmlSlate
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Amount to Pay Input
                        OutlinedTextField(
                            value = paymentAmountInput,
                            onValueChange = { paymentAmountInput = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Amount to Pay (UGX)", fontSize = 12.sp, color = VmlSlate) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = VmlGold,
                                unfocusedBorderColor = VmlNavyBorder,
                                focusedContainerColor = VmlCreamGreyElevated,
                                unfocusedContainerColor = VmlCreamGreyElevated,
                                focusedTextColor = VmlTextPrimary,
                                unfocusedTextColor = VmlTextPrimary
                            ),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 15.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, color = VmlTextPrimary)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Channel Selection Chips
                        Text(text = "Payment Method:", fontSize = 11.sp, color = VmlSlate, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("MTN Mobile Money", "Airtel Money", "Stanbic EFT").forEach { ch ->
                                val isSelected = selectedChannel == ch
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { selectedChannel = ch },
                                    label = { Text(ch, fontSize = 10.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = VmlGold,
                                        selectedLabelColor = Color.White,
                                        containerColor = VmlNavyDark,
                                        labelColor = VmlSlate
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = isSelected,
                                        borderColor = if (isSelected) VmlGold else VmlNavyBorder
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Phone Number
                        OutlinedTextField(
                            value = debtorPhoneInput,
                            onValueChange = { debtorPhoneInput = it },
                            label = { Text("Payer Mobile Money / Bank Number", fontSize = 12.sp, color = VmlSlate) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = VmlGold,
                                unfocusedBorderColor = VmlNavyBorder,
                                focusedContainerColor = VmlCreamGreyElevated,
                                unfocusedContainerColor = VmlCreamGreyElevated,
                                focusedTextColor = VmlTextPrimary,
                                unfocusedTextColor = VmlTextPrimary
                            ),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium, color = VmlTextPrimary)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                val amount = paymentAmountInput.toDoubleOrNull() ?: 0.0
                                if (amount > 0) {
                                    isProcessingPayment = true
                                    viewModel.makeDebtorPayment(
                                        caseId = debtorCase.caseId,
                                        amount = amount,
                                        channel = selectedChannel,
                                        phone = debtorPhoneInput
                                    ) { receipt ->
                                        isProcessingPayment = false
                                        showPaymentSuccessDialog = Pair(amount, receipt)
                                    }
                                } else {
                                    Toast.makeText(context, "Please enter a valid payment amount.", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = VmlGreen),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(vertical = 12.dp),
                            enabled = !isProcessingPayment
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isProcessingPayment) "Processing Payment..." else "Authorize & Pay ${formatUgxShort(paymentAmountInput.toDoubleOrNull() ?: 0.0)}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Success Dialog
    if (showPaymentSuccessDialog != null) {
        val (amount, receipt) = showPaymentSuccessDialog!!
        Dialog(onDismissRequest = { showPaymentSuccessDialog = null }) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlGreen)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier.size(48.dp).clip(CircleShape).background(VmlGreenContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = VmlGreen, modifier = Modifier.size(28.dp))
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "PAYMENT SUCCESSFUL", fontSize = 15.sp, fontWeight = FontWeight.Black, color = VmlGreen)
                    Text(text = "Official Debt Payment Receipt", fontSize = 11.sp, color = VmlSlate)

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = formatUgxShort(amount), fontSize = 24.sp, fontWeight = FontWeight.Black, color = VmlTextPrimary)
                    Text(text = "Receipt Number: $receipt", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VmlGoldLight)
                    Text(text = "Channel: $selectedChannel", fontSize = 11.sp, color = VmlSlate)

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Your account balance has been automatically reconciled. Creditor and legal officers have been notified.",
                        fontSize = 11.sp,
                        color = VmlSlate,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            showPaymentSuccessDialog = null
                            viewModel.setDebtorPortalTab(0) // View updated balance
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                    ) {
                        Text("View Updated Balance", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun DebtorBalanceRow(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 11.sp, color = VmlSlate)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = valueColor)
    }
}
