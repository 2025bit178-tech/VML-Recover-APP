package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PaymentTransactionEntity
import com.example.ui.components.AdaptiveSegmentedTabRow
import com.example.ui.components.formatUgxShort
import com.example.ui.theme.VmlAmber
import com.example.ui.theme.VmlAmberContainer
import com.example.ui.theme.VmlBlue
import com.example.ui.theme.VmlBlueContainer
import com.example.ui.theme.VmlGold
import com.example.ui.theme.VmlGoldDim
import com.example.ui.theme.VmlGoldLight
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlGreenContainer
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlRedContainer
import com.example.ui.theme.VmlSlate
import com.example.ui.theme.VmlTextPrimary
import com.example.ui.theme.VmlTextSecondary
import com.example.viewmodel.VmlViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FinanceOfficerScreen(
    viewModel: VmlViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val cases by viewModel.allCases.collectAsState()
    val payments by viewModel.allPayments.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    val selectedTab by viewModel.financeOfficerTab.collectAsState()
    var selectedClientFilter by remember { mutableStateOf("ALL") }

    val clientList = listOf(
        "Stanbic Bank Uganda Ltd",
        "Centenary SACCO Federation",
        "QuickLoans Corporate Capital",
        "Equity Bank Uganda"
    )

    // Financial Metrics per Client
    val clientStats = clientList.map { client ->
        val clientCases = cases.filter { it.creditorName.contains(client.split(" ").first(), ignoreCase = true) }
        val assigned = clientCases.sumOf { it.totalDebt }
        val recovered = clientCases.sumOf { it.amountPaid }
        val outstanding = (assigned - recovered).coerceAtLeast(0.0)
        val vmlSuccessFee = recovered * 0.10 // 10% legal recovery commission
        val netDueToClient = recovered - vmlSuccessFee
        object {
            val name = client
            val totalAssigned = assigned
            val totalRecovered = recovered
            val totalOutstanding = outstanding
            val successFee = vmlSuccessFee
            val payableToClient = netDueToClient
            val count = clientCases.size
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(VmlNavyDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Finance Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold.copy(alpha = 0.8f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(VmlGoldDim),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.AttachMoney, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "FINANCE & CLIENT RECONCILIATION",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = VmlGoldLight,
                                    letterSpacing = 1.2.sp
                                )
                                Text(
                                    text = "Assigned Clients Information & Payments Stream",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VmlTextPrimary
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(VmlGreenContainer)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = "AUDIT READY", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VmlGreen)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Total Collections", fontSize = 10.sp, color = VmlSlate)
                            Text(text = formatUgxShort(payments.sumOf { it.amount }), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlGreen)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "Verified Reconciled", fontSize = 10.sp, color = VmlSlate)
                            Text(text = "${payments.count { it.verified }} / ${payments.size}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlBlue)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "VML Recovery Fees", fontSize = 10.sp, color = VmlSlate)
                            Text(text = formatUgxShort(payments.sumOf { it.amount } * 0.10), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlGoldLight)
                        }
                    }
                }
            }
        }

        // Adaptive Cross-Platform Tabs (iOS & Android)
        item {
            AdaptiveSegmentedTabRow(
                tabs = listOf("Assigned Clients Ledgers", "Payment Reconciliation (${payments.size})"),
                selectedIndex = selectedTab,
                onTabSelected = { viewModel.setFinanceOfficerTab(it) }
            )
        }

        if (selectedTab == 0) {
            // TAB 0: ASSIGNED CLIENTS INFORMATION
            item {
                Text(
                    text = "INDIVIDUAL CLIENT INFORMATION & STATEMENT LEDGERS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = VmlGoldLight,
                    letterSpacing = 1.sp
                )
            }

            items(clientStats) { c ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(VmlGoldDim),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.AccountBalance, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(16.dp))
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(text = c.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                                    Text(text = "${c.count} Active Assigned Accounts", fontSize = 10.sp, color = VmlSlate)
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(VmlNavyDark)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(text = "Fee: 10%", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VmlGoldLight)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "Total Instructed", fontSize = 10.sp, color = VmlSlate)
                                Text(text = formatUgxShort(c.totalAssigned), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "Total Recovered", fontSize = 10.sp, color = VmlSlate)
                                Text(text = formatUgxShort(c.totalRecovered), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VmlGreen)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "Outstanding Claim", fontSize = 10.sp, color = VmlSlate)
                                Text(text = formatUgxShort(c.totalOutstanding), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VmlRed)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(VmlNavyBorder))
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = "Net Payable to Client (90%):", fontSize = 10.sp, color = VmlSlate)
                                Text(text = formatUgxShort(c.payableToClient), fontSize = 13.sp, fontWeight = FontWeight.Black, color = VmlGoldLight)
                            }

                            Button(
                                onClick = {
                                    Toast.makeText(context, "Client statement dispatched to ${c.name}.", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 3.dp),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("Client Statement", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }
        } else {
            // TAB 1: PAYMENTS & RECONCILIATION ENGINE
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PAYMENT TRANSACTIONS & BANK RECONCILIATION",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGoldLight,
                        letterSpacing = 1.sp
                    )

                    OutlinedButton(
                        onClick = {
                            Toast.makeText(context, "Exporting bank reconciliation certificate...", Toast.LENGTH_SHORT).show()
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(12.dp), tint = VmlGoldLight)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export Audit", fontSize = 10.sp, color = VmlGoldLight)
                    }
                }
            }

            val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())

            items(payments) { p ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (p.verified) VmlGreen.copy(alpha = 0.5f) else VmlAmber)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Receipt, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = p.receiptNumber, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                            }

                            Text(text = formatUgxShort(p.amount), fontSize = 14.sp, fontWeight = FontWeight.Black, color = VmlGreen)
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "File: ${p.caseId} • Channel: ${p.paymentChannel}", fontSize = 11.sp, color = VmlGoldLight)
                        Text(text = "Recorded by: ${p.recordedBy} • Date: ${sdf.format(Date(p.paymentDate))}", fontSize = 10.sp, color = VmlSlate)

                        if (p.notes.isNotBlank()) {
                            Text(text = "Notes: ${p.notes}", fontSize = 10.sp, color = VmlSlate, maxLines = 1)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (p.verified) VmlGreenContainer else VmlAmberContainer)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (p.verified) "BANK RECONCILED" else "PENDING CLEARANCE",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (p.verified) VmlGreen else VmlAmber
                                )
                            }

                            Button(
                                onClick = {
                                    viewModel.reconcilePayment(p.id, !p.verified)
                                    val newStatus = if (!p.verified) "Reconciled" else "Marked Pending"
                                    Toast.makeText(context, "${p.receiptNumber} $newStatus.", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (p.verified) VmlNavyDark else VmlGreen
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 3.dp),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = if (p.verified) "Undo Reconcile" else "Verify & Reconcile",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (p.verified) VmlSlate else Color.White
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
