package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.VmlAmber
import com.example.ui.theme.VmlAmberContainer
import com.example.ui.theme.VmlBlue
import com.example.ui.theme.VmlGold
import com.example.ui.theme.VmlGoldDim
import com.example.ui.theme.VmlGoldLight
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlGreenContainer
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlRedContainer
import com.example.ui.theme.VmlSlate
import com.example.ui.theme.VmlSlateLight
import com.example.ui.theme.VmlTextPrimary
import kotlinx.coroutines.launch

// ==========================================
// STRICT VALIDATION HELPER FUNCTIONS
// ==========================================

object FormValidators {

    fun validateDebtorName(name: String): String? {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return "Debtor full name or company is required."
        if (trimmed.length < 3) return "Name must be at least 3 characters."
        if (trimmed.length > 100) return "Name cannot exceed 100 characters."
        if (trimmed.all { it.isDigit() || it.isWhitespace() }) return "Numbers-only name is not allowed."
        if (trimmed.count { it.isLetter() } < 2) return "Must contain at least 2 alphabetical characters."
        // Disallow dangerous or invalid special characters, allow hyphens, apostrophes, spaces, dots, ampersand, parentheses
        val validCharsRegex = "^[a-zA-Z0-9\\s'.,&()/-]+$".toRegex()
        if (!validCharsRegex.matches(trimmed)) return "Contains invalid special characters."
        return null
    }

    fun validateNationalId(id: String): String? {
        val trimmed = id.trim().replace("\\s+".toRegex(), "")
        if (trimmed.isEmpty()) return "National ID / Registration Number is required."
        if (trimmed.length < 5) return "ID / Registration Number is too short (min 5 chars)."
        if (trimmed.length > 25) return "ID / Registration Number is too long (max 25 chars)."

        // Uganda NIN format for individuals: 14 chars starting with CM or CF
        val isIndividualNinCandidate = trimmed.startsWith("CM", ignoreCase = true) || trimmed.startsWith("CF", ignoreCase = true)
        if (isIndividualNinCandidate) {
            if (trimmed.length != 14) return "Uganda National ID (NIN) must be exactly 14 characters (currently ${trimmed.length})."
            val ninRegex = "^C[MF][0-9A-Za-z]{12}$".toRegex(RegexOption.IGNORE_CASE)
            if (!ninRegex.matches(trimmed)) return "Invalid Uganda NIN format. Must start with CM/CF followed by 12 alphanumeric characters."
            return null
        }

        // Starts with C but 3rd char is not M/F and length 14 -> warn user
        if (trimmed.startsWith("C", ignoreCase = true) && trimmed.length == 14 && !isIndividualNinCandidate) {
            return "Ugandan NIN must start with 'CM' (Male) or 'CF' (Female)."
        }

        // Company registration candidate (e.g. CO-REG-882910-UG, 80020..., etc.)
        val validRegRegex = "^[0-9A-Za-z/-]{5,25}$".toRegex()
        if (!validRegRegex.matches(trimmed)) return "Registration number contains invalid characters."
        return null
    }

    fun validatePhone(phone: String): String? {
        val trimmed = phone.trim().replace(" ", "").replace("-", "")
        if (trimmed.isEmpty() || trimmed == "+256" || trimmed == "256") return "Telephone contact is required."
        if (trimmed.any { it.isLetter() }) return "Phone number cannot contain letters."

        val normalized = normalizeUgandaPhone(phone)
        // Must be +256 followed by 9 digits (total 13 chars)
        if (!normalized.startsWith("+256")) return "Ugandan numbers must start with Uganda country code (+256)."
        val afterPrefix = normalized.removePrefix("+256")
        if (afterPrefix.length != 9) return "Uganda phone must have 9 digits after +256 (currently ${afterPrefix.length} digits)."
        if (!afterPrefix.all { it.isDigit() }) return "Phone number must contain only numeric digits."

        // Valid Uganda numbering plan prefixes: 7 (mobile MTN/Airtel/Lyca) or 3/4/2 (landline/fixed CDMA)
        val firstDigit = afterPrefix.first()
        if (firstDigit != '7' && firstDigit != '3' && firstDigit != '4' && firstDigit != '2') {
            return "Invalid Ugandan prefix. Mobile numbers start with +256 7XX, landlines with +256 3XX."
        }
        return null
    }

    fun normalizeUgandaPhone(phone: String): String {
        var clean = phone.trim().replace(" ", "").replace("-", "")
        if (clean.startsWith("+256")) return clean
        if (clean.startsWith("256")) return "+$clean"
        if (clean.startsWith("0")) return "+256" + clean.substring(1)
        if (clean.length == 9 && (clean.startsWith("7") || clean.startsWith("3"))) return "+256$clean"
        return if (clean.startsWith("+")) clean else "+256$clean"
    }

    fun validateEmail(email: String): String? {
        val trimmed = email.trim()
        if (trimmed.isEmpty()) return "Email address is required."
        if (trimmed.contains(" ")) return "Email cannot contain spaces."
        val emailRegex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$".toRegex()
        if (!emailRegex.matches(trimmed)) return "Please enter a valid email address (e.g., name@domain.com)."
        return null
    }

    fun validateAddress(address: String): String? {
        val trimmed = address.trim()
        if (trimmed.isEmpty()) return "Physical trading address is required."
        if (trimmed.length < 5) return "Please enter a complete address (minimum 5 characters)."
        if (trimmed.length > 150) return "Address is too long (maximum 150 characters)."
        return null
    }

    fun validateEmployer(employer: String): String? {
        val trimmed = employer.trim()
        if (trimmed.isEmpty()) return "Employer or business type is required."
        if (trimmed.length < 3) return "Employer / business type must be at least 3 characters."
        return null
    }

    fun validateCreditorName(creditor: String): String? {
        val trimmed = creditor.trim()
        if (trimmed.isEmpty()) return "Creditor institution name is required."
        if (trimmed.length < 3) return "Creditor name must be at least 3 characters."
        return null
    }

    fun validateCreditorAccount(creditor: String, acc: String): String? {
        val trimmed = acc.trim()
        if (trimmed.isEmpty()) return "Creditor account / reference number is required."
        val cLower = creditor.lowercase()

        if (cLower.contains("stanbic")) {
            if (trimmed.length != 13 || !trimmed.all { it.isDigit() }) {
                return "Stanbic Bank accounts must be exactly 13 digits (e.g. 9030018274910)."
            }
        } else if (cLower.contains("centenary")) {
            if (trimmed.length !in 10..13 || !trimmed.all { it.isDigit() }) {
                return "Centenary Bank accounts must be 10–13 digits (e.g. 3100293847192)."
            }
        } else if (cLower.contains("dfcu")) {
            if (trimmed.length !in 10..14 || !trimmed.all { it.isDigit() }) {
                return "DFCU Bank accounts must be 10–14 digits (e.g. 0182749100293)."
            }
        } else if (cLower.contains("absa")) {
            if (trimmed.length !in 10..13 || !trimmed.all { it.isDigit() }) {
                return "Absa Bank accounts must be 10–13 digits (e.g. 6002918475819)."
            }
        } else {
            if (trimmed.length < 6 || trimmed.length > 25) {
                return "Account/Reference number must be between 6 and 25 characters."
            }
        }
        return null
    }

    fun validateAgreementRef(ref: String): String? {
        val trimmed = ref.trim()
        if (trimmed.isEmpty()) return "Original agreement reference is required."
        if (trimmed.length < 4) return "Agreement reference must be at least 4 characters (e.g., LN-2024-001)."
        return null
    }

    fun validateFinancialPrincipal(principalStr: String): String? {
        val trimmed = principalStr.trim().replace(",", "")
        if (trimmed.isEmpty()) return "Principal claim amount is required."
        val parsed = trimmed.toDoubleOrNull() ?: return "Principal must be a valid numeric monetary amount."
        if (parsed <= 0.0) return "Principal claim amount must be greater than UGX 0."
        if (parsed > 50_000_000_000.0) return "Principal amount exceeds statutory recoverable ceiling (UGX 50B)."
        return null
    }

    fun validateFinancialInterest(interestStr: String): String? {
        val trimmed = interestStr.trim().replace(",", "")
        if (trimmed.isEmpty()) return "Interest amount is required (enter 0 if none)."
        val parsed = trimmed.toDoubleOrNull() ?: return "Interest must be a valid numeric amount."
        if (parsed < 0.0) return "Interest amount cannot be negative."
        return null
    }

    fun validateFinancialPenalties(penaltiesStr: String): String? {
        val trimmed = penaltiesStr.trim().replace(",", "")
        if (trimmed.isEmpty()) return "Penalties amount is required (enter 0 if none)."
        val parsed = trimmed.toDoubleOrNull() ?: return "Penalties must be a valid numeric amount."
        if (parsed < 0.0) return "Penalties cannot be negative."
        return null
    }
}

@Composable
fun VmlValidatedField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    errorText: String?,
    isValid: Boolean,
    onBlur: () -> Unit,
    modifier: Modifier = Modifier,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    singleLine: Boolean = true,
    leadingIcon: @Composable (() -> Unit)? = null,
    testTag: String = ""
) {
    var hasFocused by remember { mutableStateOf(false) }

    Column(modifier = modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (errorText != null) VmlRed else VmlSlateLight,
                modifier = Modifier.width(115.dp),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.width(6.dp))
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                placeholder = { Text(label, fontSize = 12.sp, color = VmlSlate.copy(alpha = 0.5f), maxLines = 1) },
                isError = errorText != null,
                leadingIcon = leadingIcon,
                trailingIcon = {
                    if (isValid) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Valid Field",
                            tint = VmlGreen,
                            modifier = Modifier.size(18.dp)
                        )
                    } else if (errorText != null) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Invalid Field",
                            tint = VmlRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .testTag(testTag)
                    .onFocusChanged { focusState ->
                        if (focusState.isFocused) {
                            hasFocused = true
                        } else if (hasFocused) {
                            onBlur()
                        }
                    },
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = if (errorText != null) VmlRed else if (isValid) VmlGreen else VmlGold,
                    unfocusedBorderColor = if (errorText != null) VmlRed else if (isValid) VmlGreen.copy(alpha = 0.8f) else VmlNavyBorder,
                    errorBorderColor = VmlRed,
                    focusedContainerColor = VmlNavySurface,
                    unfocusedContainerColor = VmlNavySurface,
                    focusedTextColor = VmlTextPrimary,
                    unfocusedTextColor = VmlTextPrimary
                ),
                keyboardOptions = keyboardOptions,
                singleLine = singleLine,
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium, color = VmlTextPrimary)
            )
        }

        if (errorText != null) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 121.dp, top = 2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(4.dp)
                        .clip(CircleShape)
                        .background(VmlRed)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = errorText,
                    color = VmlRed,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun NewCaseDialog(
    onDismiss: () -> Unit,
    onSubmit: (
        debtorName: String,
        debtorId: String,
        phone: String,
        email: String,
        address: String,
        employer: String,
        creditorName: String,
        creditorAcc: String,
        agreementRef: String,
        principal: Double,
        interest: Double,
        penalties: Double,
        officer: String
    ) -> Unit
) {
    // Form Inputs
    var debtorName by remember { mutableStateOf("") }
    var debtorId by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("+256 ") }
    var email by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var employer by remember { mutableStateOf("") }
    var creditorName by remember { mutableStateOf("Stanbic Bank Uganda Ltd") }
    var creditorAcc by remember { mutableStateOf("") }
    var agreementRef by remember { mutableStateOf("") }
    var principalStr by remember { mutableStateOf("") }
    var interestStr by remember { mutableStateOf("0") }
    var penaltiesStr by remember { mutableStateOf("0") }
    var officer by remember { mutableStateOf("Officer David Ochieng") }

    // Validation Errors
    var debtorNameError by remember { mutableStateOf<String?>(null) }
    var debtorIdError by remember { mutableStateOf<String?>(null) }
    var phoneError by remember { mutableStateOf<String?>(null) }
    var emailError by remember { mutableStateOf<String?>(null) }
    var addressError by remember { mutableStateOf<String?>(null) }
    var employerError by remember { mutableStateOf<String?>(null) }
    var creditorNameError by remember { mutableStateOf<String?>(null) }
    var creditorAccError by remember { mutableStateOf<String?>(null) }
    var agreementRefError by remember { mutableStateOf<String?>(null) }
    var principalError by remember { mutableStateOf<String?>(null) }
    var interestError by remember { mutableStateOf<String?>(null) }
    var penaltiesError by remember { mutableStateOf<String?>(null) }

    val scrollState = rememberScrollState()
    val coroutineScope = rememberCoroutineScope()

    // Real-time Validity Checks
    val isDebtorNameValid = debtorName.isNotBlank() && FormValidators.validateDebtorName(debtorName) == null
    val isDebtorIdValid = debtorId.isNotBlank() && FormValidators.validateNationalId(debtorId) == null
    val isPhoneValid = phone.isNotBlank() && FormValidators.validatePhone(phone) == null
    val isEmailValid = email.isNotBlank() && FormValidators.validateEmail(email) == null
    val isAddressValid = address.isNotBlank() && FormValidators.validateAddress(address) == null
    val isEmployerValid = employer.isNotBlank() && FormValidators.validateEmployer(employer) == null
    val isCreditorNameValid = creditorName.isNotBlank() && FormValidators.validateCreditorName(creditorName) == null
    val isCreditorAccValid = creditorAcc.isNotBlank() && FormValidators.validateCreditorAccount(creditorName, creditorAcc) == null
    val isAgreementRefValid = agreementRef.isNotBlank() && FormValidators.validateAgreementRef(agreementRef) == null
    val isPrincipalValid = principalStr.isNotBlank() && FormValidators.validateFinancialPrincipal(principalStr) == null
    val isInterestValid = interestStr.isNotBlank() && FormValidators.validateFinancialInterest(interestStr) == null
    val isPenaltiesValid = penaltiesStr.isNotBlank() && FormValidators.validateFinancialPenalties(penaltiesStr) == null

    val isFormCompleteAndValid = isDebtorNameValid &&
            isDebtorIdValid &&
            isPhoneValid &&
            isEmailValid &&
            isAddressValid &&
            isEmployerValid &&
            isCreditorNameValid &&
            isCreditorAccValid &&
            isAgreementRefValid &&
            isPrincipalValid &&
            isInterestValid &&
            isPenaltiesValid

    fun validateAll(): Boolean {
        debtorNameError = FormValidators.validateDebtorName(debtorName)
        debtorIdError = FormValidators.validateNationalId(debtorId)
        phoneError = FormValidators.validatePhone(phone)
        emailError = FormValidators.validateEmail(email)
        addressError = FormValidators.validateAddress(address)
        employerError = FormValidators.validateEmployer(employer)
        creditorNameError = FormValidators.validateCreditorName(creditorName)
        creditorAccError = FormValidators.validateCreditorAccount(creditorName, creditorAcc)
        agreementRefError = FormValidators.validateAgreementRef(agreementRef)
        principalError = FormValidators.validateFinancialPrincipal(principalStr)
        interestError = FormValidators.validateFinancialInterest(interestStr)
        penaltiesError = FormValidators.validateFinancialPenalties(penaltiesStr)

        val hasError = debtorNameError != null ||
                debtorIdError != null ||
                phoneError != null ||
                emailError != null ||
                addressError != null ||
                employerError != null ||
                creditorNameError != null ||
                creditorAccError != null ||
                agreementRefError != null ||
                principalError != null ||
                interestError != null ||
                penaltiesError != null

        if (hasError) {
            coroutineScope.launch {
                // Scroll to top or first invalid field
                scrollState.animateScrollTo(0)
            }
        }
        return !hasError
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
            border = androidx.compose.foundation.BorderStroke(1.2.dp, VmlGold)
        ) {
            Column(
                modifier = Modifier
                    .padding(18.dp)
                    .verticalScroll(scrollState)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "REGISTER DEBTOR & CLAIM",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = VmlGoldLight,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "VML Legal Creditor Recovery Instruction Form",
                            fontSize = 11.sp,
                            color = VmlSlate
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isFormCompleteAndValid) VmlGreenContainer else VmlAmberContainer)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (isFormCompleteAndValid) "ALL 10 FIELDS VALID" else "VALIDATION PENDING",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isFormCompleteAndValid) VmlGreen else VmlAmber
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // SECTION 1: DEBTOR IDENTIFICATION
                Text(
                    text = "1. DEBTOR IDENTIFICATION (ALL REQUIRED)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = VmlGoldLight,
                    letterSpacing = 0.8.sp
                )
                Spacer(modifier = Modifier.height(4.dp))

                // 1. Debtor Full Name / Company
                VmlValidatedField(
                    value = debtorName,
                    onValueChange = {
                        debtorName = it
                        if (debtorNameError != null) debtorNameError = FormValidators.validateDebtorName(it)
                    },
                    label = "Debtor Full Name / Registered Company *",
                    errorText = debtorNameError,
                    isValid = isDebtorNameValid,
                    onBlur = { debtorNameError = FormValidators.validateDebtorName(debtorName) },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(16.dp)) },
                    testTag = "input_debtor_name"
                )

                // 2. National ID / Registration Number
                VmlValidatedField(
                    value = debtorId,
                    onValueChange = {
                        debtorId = it
                        if (debtorIdError != null) debtorIdError = FormValidators.validateNationalId(it)
                    },
                    label = "National ID (NIN) / Company Reg No. *",
                    errorText = debtorIdError,
                    isValid = isDebtorIdValid,
                    onBlur = { debtorIdError = FormValidators.validateNationalId(debtorId) },
                    leadingIcon = { Icon(Icons.Default.Receipt, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(16.dp)) },
                    testTag = "input_debtor_nin"
                )

                // 3. Telephone Contact (+256)
                VmlValidatedField(
                    value = phone,
                    onValueChange = {
                        phone = it
                        if (phoneError != null) phoneError = FormValidators.validatePhone(it)
                    },
                    label = "Telephone Contact (+256...) *",
                    errorText = phoneError,
                    isValid = isPhoneValid,
                    onBlur = { phoneError = FormValidators.validatePhone(phone) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(16.dp)) },
                    testTag = "input_debtor_phone"
                )

                // 4. Email Address
                VmlValidatedField(
                    value = email,
                    onValueChange = {
                        email = it
                        if (emailError != null) emailError = FormValidators.validateEmail(it)
                    },
                    label = "Email Address *",
                    errorText = emailError,
                    isValid = isEmailValid,
                    onBlur = { emailError = FormValidators.validateEmail(email) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(16.dp)) },
                    testTag = "input_debtor_email"
                )

                // 5. Physical Trading Address
                VmlValidatedField(
                    value = address,
                    onValueChange = {
                        address = it
                        if (addressError != null) addressError = FormValidators.validateAddress(it)
                    },
                    label = "Physical Trading Address (Plot, Street, City) *",
                    errorText = addressError,
                    isValid = isAddressValid,
                    onBlur = { addressError = FormValidators.validateAddress(address) },
                    leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(16.dp)) },
                    testTag = "input_debtor_address"
                )

                // 6. Employer / Business Type
                VmlValidatedField(
                    value = employer,
                    onValueChange = {
                        employer = it
                        if (employerError != null) employerError = FormValidators.validateEmployer(it)
                    },
                    label = "Employer / Business Sector *",
                    errorText = employerError,
                    isValid = isEmployerValid,
                    onBlur = { employerError = FormValidators.validateEmployer(employer) },
                    leadingIcon = { Icon(Icons.Default.Business, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(16.dp)) },
                    testTag = "input_debtor_employer"
                )

                Spacer(modifier = Modifier.height(10.dp))

                // SECTION 2: CREDITOR INSTRUCTION
                Text(
                    text = "2. CREDITOR INSTRUCTION (ALL REQUIRED)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = VmlGoldLight,
                    letterSpacing = 0.8.sp
                )
                Spacer(modifier = Modifier.height(4.dp))

                // 7. Creditor Name
                VmlValidatedField(
                    value = creditorName,
                    onValueChange = {
                        creditorName = it
                        if (creditorNameError != null) creditorNameError = FormValidators.validateCreditorName(it)
                        if (creditorAcc.isNotBlank()) creditorAccError = FormValidators.validateCreditorAccount(it, creditorAcc)
                    },
                    label = "Creditor Name (e.g., Stanbic, Centenary, DFCU, Absa) *",
                    errorText = creditorNameError,
                    isValid = isCreditorNameValid,
                    onBlur = { creditorNameError = FormValidators.validateCreditorName(creditorName) },
                    leadingIcon = { Icon(Icons.Default.AccountBalance, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(16.dp)) },
                    testTag = "input_creditor_name"
                )

                // 8. Creditor Account / Reference Number
                VmlValidatedField(
                    value = creditorAcc,
                    onValueChange = {
                        creditorAcc = it
                        if (creditorAccError != null) creditorAccError = FormValidators.validateCreditorAccount(creditorName, it)
                    },
                    label = "Creditor Account / Ref # (Format validated per bank) *",
                    errorText = creditorAccError,
                    isValid = isCreditorAccValid,
                    onBlur = { creditorAccError = FormValidators.validateCreditorAccount(creditorName, creditorAcc) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                    leadingIcon = { Icon(Icons.Default.Receipt, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(16.dp)) },
                    testTag = "input_creditor_account"
                )

                // 9. Original Agreement Reference
                VmlValidatedField(
                    value = agreementRef,
                    onValueChange = {
                        agreementRef = it
                        if (agreementRefError != null) agreementRefError = FormValidators.validateAgreementRef(it)
                    },
                    label = "Original Credit Agreement Reference *",
                    errorText = agreementRefError,
                    isValid = isAgreementRefValid,
                    onBlur = { agreementRefError = FormValidators.validateAgreementRef(agreementRef) },
                    leadingIcon = { Icon(Icons.Default.Receipt, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(16.dp)) },
                    testTag = "input_agreement_ref"
                )

                Spacer(modifier = Modifier.height(10.dp))

                // SECTION 3: CLAIM FINANCIALS (UGX)
                Text(
                    text = "3. CLAIM FINANCIALS (UGX - ALL REQUIRED)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = VmlGoldLight,
                    letterSpacing = 0.8.sp
                )
                Spacer(modifier = Modifier.height(4.dp))

                // 10. Financials: Principal, Interest, Penalties
                VmlValidatedField(
                    value = principalStr,
                    onValueChange = {
                        principalStr = it
                        if (principalError != null) principalError = FormValidators.validateFinancialPrincipal(it)
                    },
                    label = "Principal Claim Amount (UGX) *",
                    errorText = principalError,
                    isValid = isPrincipalValid,
                    onBlur = { principalError = FormValidators.validateFinancialPrincipal(principalStr) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    testTag = "input_principal_amount"
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    VmlValidatedField(
                        value = interestStr,
                        onValueChange = {
                            interestStr = it
                            if (interestError != null) interestError = FormValidators.validateFinancialInterest(it)
                        },
                        label = "Interest (UGX) *",
                        errorText = interestError,
                        isValid = isInterestValid,
                        onBlur = { interestError = FormValidators.validateFinancialInterest(interestStr) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        testTag = "input_interest_amount"
                    )

                    VmlValidatedField(
                        value = penaltiesStr,
                        onValueChange = {
                            penaltiesStr = it
                            if (penaltiesError != null) penaltiesError = FormValidators.validateFinancialPenalties(it)
                        },
                        label = "Penalties / Fees (UGX) *",
                        errorText = penaltiesError,
                        isValid = isPenaltiesValid,
                        onBlur = { penaltiesError = FormValidators.validateFinancialPenalties(penaltiesStr) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        testTag = "input_penalties_amount"
                    )
                }

                // Financial Total Preview
                val parsedP = principalStr.toDoubleOrNull() ?: 0.0
                val parsedI = interestStr.toDoubleOrNull() ?: 0.0
                val parsedPen = penaltiesStr.toDoubleOrNull() ?: 0.0
                val totalClaim = parsedP + parsedI + parsedPen

                if (totalClaim > 0.0) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(VmlNavySurface)
                            .border(1.dp, VmlGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Total Legally Recoverable Claim:", fontSize = 11.sp, color = VmlSlate)
                            Text("UGX %,d".format(totalClaim.toLong()), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlGoldLight)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = VmlSlate)
                    ) {
                        Text("Cancel")
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Button(
                        onClick = {
                            if (validateAll()) {
                                val normalizedPhone = FormValidators.normalizeUgandaPhone(phone)
                                val p = principalStr.toDouble()
                                val i = interestStr.toDouble()
                                val pen = penaltiesStr.toDouble()
                                onSubmit(
                                    debtorName.trim(),
                                    debtorId.trim(),
                                    normalizedPhone,
                                    email.trim(),
                                    address.trim(),
                                    employer.trim(),
                                    creditorName.trim(),
                                    creditorAcc.trim(),
                                    agreementRef.trim(),
                                    p,
                                    i,
                                    pen,
                                    officer
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isFormCompleteAndValid) VmlGold else VmlNavySurface,
                            disabledContainerColor = VmlNavySurface
                        ),
                        enabled = isFormCompleteAndValid,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("btn_instruct_case_submit")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = if (isFormCompleteAndValid) VmlNavyDark else VmlSlate,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Instruct Case",
                            color = if (isFormCompleteAndValid) VmlNavyDark else VmlSlate,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RecordPaymentDialog(
    caseId: String,
    onDismiss: () -> Unit,
    onSubmit: (amount: Double, channel: String, receipt: String, notes: String) -> Unit
) {
    var amountStr by remember { mutableStateOf("") }
    var channel by remember { mutableStateOf("Stanbic Bank EFT / Direct Wire") }
    var receiptNumber by remember { mutableStateOf("REC-2026-" + (1000..9999).random()) }
    var notes by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, VmlGreen)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "RECORD VERIFIED PAYMENT",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = VmlGreen
                )
                Text(
                    text = "Case: $caseId • Audited Ledger Entry",
                    fontSize = 11.sp,
                    color = VmlSlate
                )

                Spacer(modifier = Modifier.height(12.dp))

                VmlTextField(value = amountStr, onValueChange = { amountStr = it }, label = "Payment Amount (UGX)")
                VmlTextField(value = receiptNumber, onValueChange = { receiptNumber = it }, label = "Receipt / Reference Number")
                VmlTextField(value = channel, onValueChange = { channel = it }, label = "Payment Channel (Bank, MTN MoMo, etc.)")
                VmlTextField(value = notes, onValueChange = { notes = it }, label = "Transaction Notes / Depositor Name")

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = VmlNavySurface)
                    ) {
                        Text("Cancel", color = VmlSlate)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val amt = amountStr.toDoubleOrNull() ?: 5_000_000.0
                            onSubmit(amt, channel, receiptNumber, notes)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VmlGreen)
                    ) {
                        Text("Confirm & Reconcile", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun RecordPromiseDialog(
    caseId: String,
    debtorName: String,
    onDismiss: () -> Unit,
    onSubmit: (amount: Double, date: String, method: String, notes: String) -> Unit
) {
    var amountStr by remember { mutableStateOf("10000000") }
    var promiseDate by remember { mutableStateOf("10 October 2026") }
    var paymentMethod by remember { mutableStateOf("Bank Wire / EFT") }
    var notes by remember { mutableStateOf("Debtor agreed to payment following supplier invoice settlement.") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, VmlAmber)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "RECORD PROMISE TO PAY (PTP)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = VmlAmber
                )
                Text(
                    text = "Case: $caseId • Debtor: $debtorName",
                    fontSize = 11.sp,
                    color = VmlSlate
                )

                Spacer(modifier = Modifier.height(12.dp))

                VmlTextField(value = amountStr, onValueChange = { amountStr = it }, label = "Promised Amount (UGX)")
                VmlTextField(value = promiseDate, onValueChange = { promiseDate = it }, label = "Promise Date (e.g. 10 October 2026)")
                VmlTextField(value = paymentMethod, onValueChange = { paymentMethod = it }, label = "Payment Method (Bank Wire, MoMo, etc.)")
                VmlTextField(value = notes, onValueChange = { notes = it }, label = "Debtor Undertaking / Notes")

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = VmlNavySurface)
                    ) {
                        Text("Cancel", color = VmlSlate)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val amt = amountStr.toDoubleOrNull() ?: 10_000_000.0
                            onSubmit(amt, promiseDate, paymentMethod, notes)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VmlAmber)
                    ) {
                        Text("Record Undertaking", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun LogCallDialog(
    caseId: String,
    onDismiss: () -> Unit,
    onSubmit: (title: String, notes: String, acknowledged: Boolean) -> Unit
) {
    var title by remember { mutableStateOf("Officer called debtor") }
    var notes by remember { mutableStateOf("Debtor reached. Discussed outstanding claim balance and agreed on next steps.") }
    var acknowledged by remember { mutableStateOf(true) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, VmlBlue)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "LOG TELEPHONE INTERACTION",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = VmlBlue
                )
                Text(
                    text = "Case: $caseId • Auditable Call Log",
                    fontSize = 11.sp,
                    color = VmlSlate
                )

                Spacer(modifier = Modifier.height(12.dp))

                VmlTextField(value = title, onValueChange = { title = it }, label = "Call Title / Subject")
                VmlTextField(value = notes, onValueChange = { notes = it }, label = "Conversation Summary & Debtor Statements")

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = acknowledged,
                        onCheckedChange = { acknowledged = it },
                        colors = CheckboxDefaults.colors(checkedColor = VmlGold)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Debtor Formally Acknowledged Debt Balance", fontSize = 11.sp, color = Color.White)
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = VmlNavySurface)
                    ) {
                        Text("Cancel", color = VmlSlate)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onSubmit(title, notes, acknowledged) },
                        colors = ButtonDefaults.buttonColors(containerColor = VmlBlue)
                    ) {
                        Text("Save Call Log", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EscalateStageDialog(
    caseId: String,
    currentStage: String,
    onDismiss: () -> Unit,
    onSubmit: (nextStage: String, notes: String) -> Unit
) {
    val stages = listOf(
        "COLLECTION", "DEMAND", "NEGOTIATION", "LEGAL_REVIEW",
        "LITIGATION", "JUDGMENT", "ENFORCEMENT", "RECOVERY", "CLOSURE"
    )
    var selectedStage by remember {
        val nextIdx = (stages.indexOf(currentStage) + 1).coerceAtMost(stages.size - 1)
        mutableStateOf(stages[nextIdx])
    }
    var notes by remember {
        mutableStateOf("Case escalated following review of debtor responsiveness and security documentation.")
    }
    var expanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "ESCALATE LEGAL STAGE",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = VmlGoldLight
                )
                Text(
                    text = "Case: $caseId • Current Stage: $currentStage",
                    fontSize = 11.sp,
                    color = VmlSlate
                )

                Spacer(modifier = Modifier.height(12.dp))

                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedStage.replace("_", " "),
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Next Legal Stage", color = VmlSlate) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VmlGold,
                            unfocusedBorderColor = VmlNavyBorder,
                            focusedTextColor = VmlTextPrimary,
                            unfocusedTextColor = VmlTextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )

                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier.background(VmlNavySurface)
                    ) {
                        stages.forEach { stage ->
                            DropdownMenuItem(
                                text = { Text(stage.replace("_", " "), color = Color.White) },
                                onClick = {
                                    selectedStage = stage
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                VmlTextField(value = notes, onValueChange = { notes = it }, label = "Escalation Justification & Legal Instructions")

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = VmlNavySurface)
                    ) {
                        Text("Cancel", color = VmlSlate)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onSubmit(selectedStage, notes) },
                        colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                    ) {
                        Text("Apply Escalation", color = VmlNavyDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun CreatePaymentPlanDialog(
    caseId: String,
    debtorName: String,
    outstandingBalance: Double,
    onDismiss: () -> Unit,
    onSubmit: (amount: Double, instalments: Int, freq: String, startDate: String) -> Unit
) {
    var agreedAmountStr by remember { mutableStateOf(outstandingBalance.toLong().toString()) }
    var instalmentsCountStr by remember { mutableStateOf("4") }
    var frequency by remember { mutableStateOf("Bi-Weekly") }
    var startDate by remember { mutableStateOf("05 Oct 2026") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "STRUCTURE REPAYMENT PLAN",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = VmlGoldLight
                )
                Text(
                    text = "Case: $caseId • Debtor: $debtorName",
                    fontSize = 11.sp,
                    color = VmlSlate
                )

                Spacer(modifier = Modifier.height(12.dp))

                VmlTextField(value = agreedAmountStr, onValueChange = { agreedAmountStr = it }, label = "Total Agreed Settlement (UGX)")
                VmlTextField(value = instalmentsCountStr, onValueChange = { instalmentsCountStr = it }, label = "Number of Instalments (e.g. 4)")
                VmlTextField(value = frequency, onValueChange = { frequency = it }, label = "Frequency (Weekly, Bi-Weekly, Monthly)")
                VmlTextField(value = startDate, onValueChange = { startDate = it }, label = "Commencement Date")

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = VmlNavySurface)
                    ) {
                        Text("Cancel", color = VmlSlate)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val amt = agreedAmountStr.toDoubleOrNull() ?: outstandingBalance
                            val count = instalmentsCountStr.toIntOrNull() ?: 4
                            onSubmit(amt, count, frequency, startDate)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                    ) {
                        Text("Generate Plan", color = VmlNavyDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ScheduleVisitDialog(
    caseId: String,
    debtorName: String,
    address: String,
    onDismiss: () -> Unit,
    onSubmit: (scheduledTime: String, outcome: String) -> Unit
) {
    var scheduledTime by remember { mutableStateOf("Tomorrow, 10:00 AM") }
    var objective by remember { mutableStateOf("Physical site inspection of business premises & trading stock verification.") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "SCHEDULE FIELD OFFICER VISIT",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = VmlGoldLight
                )
                Text(
                    text = "$debtorName • $address",
                    fontSize = 11.sp,
                    color = VmlSlate
                )

                Spacer(modifier = Modifier.height(12.dp))

                VmlTextField(value = scheduledTime, onValueChange = { scheduledTime = it }, label = "Scheduled Date & Time")
                VmlTextField(value = objective, onValueChange = { objective = it }, label = "Inspection Objective & Fair Collection Instructions")

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = VmlNavySurface)
                    ) {
                        Text("Cancel", color = VmlSlate)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onSubmit(scheduledTime, objective) },
                        colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                    ) {
                        Text("Assign Officer", color = VmlNavyDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun VmlTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    textColor: Color = VmlTextPrimary,
    modifier: Modifier = Modifier,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    singleLine: Boolean = true
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = VmlSlateLight,
            modifier = Modifier.width(115.dp),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.width(6.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            placeholder = { Text(label, fontSize = 12.sp, color = VmlSlate.copy(alpha = 0.5f), maxLines = 1) },
            modifier = Modifier
                .weight(1f)
                .height(52.dp),
            shape = RoundedCornerShape(8.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = VmlGold,
                unfocusedBorderColor = VmlNavyBorder,
                focusedContainerColor = VmlNavySurface,
                unfocusedContainerColor = VmlNavySurface,
                focusedTextColor = textColor,
                unfocusedTextColor = textColor
            ),
            keyboardOptions = keyboardOptions,
            singleLine = singleLine,
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium, color = textColor)
        )
    }
}
