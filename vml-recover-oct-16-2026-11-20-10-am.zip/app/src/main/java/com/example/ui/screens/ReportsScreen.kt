package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.AuditLogEntity
import com.example.data.model.CaseEntity
import com.example.data.model.UserEntity
import com.example.ui.components.PrintUtils
import com.example.ui.components.formatUgxShort
import com.example.ui.theme.VmlAmber
import com.example.ui.theme.VmlAmberContainer
import com.example.ui.theme.VmlBlue
import com.example.ui.theme.VmlBlueContainer
import com.example.ui.theme.VmlCreamGreyElevated
import com.example.ui.theme.VmlGold
import com.example.ui.theme.VmlGoldDim
import com.example.ui.theme.VmlGoldLight
import com.example.ui.theme.VmlGreen
import com.example.ui.theme.VmlGreenContainer
import com.example.ui.theme.VmlNavyBorder
import com.example.ui.theme.VmlNavyDark
import com.example.ui.theme.VmlNavySurface
import com.example.ui.theme.VmlRed
import com.example.ui.theme.VmlRedContainer
import com.example.ui.theme.VmlSlate
import com.example.ui.theme.VmlTextPrimary
import com.example.viewmodel.UserRole
import com.example.viewmodel.VmlViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReportsScreen(
    viewModel: VmlViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val currentRole by viewModel.currentRole.collectAsState()
    val cases: List<CaseEntity> by viewModel.allCases.collectAsState()
    val users: List<UserEntity> by viewModel.allUsers.collectAsState()
    val allPayments by viewModel.allPayments.collectAsState()
    val auditLogs: List<AuditLogEntity> by viewModel.allAuditLogs.collectAsState()

    // Permissions:
    // Printing permitted for: Admin, Director, Manager
    val canPrint = currentUser?.role in listOf("ADMIN", "DIRECTOR", "MANAGER") ||
            currentRole in listOf(UserRole.ADMIN, UserRole.DIRECTOR, UserRole.COLLECTION_MANAGER)

    // Editing & Deletion: ONLY Admin can edit and delete
    val isAdmin = currentUser?.role.equals("ADMIN", ignoreCase = true) || currentRole == UserRole.ADMIN

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Clients, 1: Debtors, 2: Employees (with login/logout trail)
    var searchQuery by remember { mutableStateOf("") }

    // Dialog state for viewing full employee audit history modal
    var viewingEmployeeAudit by remember { mutableStateOf<UserEntity?>(null) }
    var viewingDebtorReport by remember { mutableStateOf<CaseEntity?>(null) }
    var editingCaseItem by remember { mutableStateOf<CaseEntity?>(null) }
    var casePendingDelete by remember { mutableStateOf<CaseEntity?>(null) }

    // Grouping for Clients Report
    val clientInstitutions = cases.map { it.creditorName }.distinct()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(VmlNavyDark),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Master Report Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold.copy(alpha = 0.7f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(VmlGoldDim),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Assessment, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "CENTRAL AUDIT & REPORTS HUB",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = VmlGoldLight,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "Clients, Debtors & Employee Audit Trails",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VmlTextPrimary
                                )
                            }
                        }

                        // Authority Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isAdmin) VmlGoldDim else if (canPrint) VmlBlueContainer else VmlRedContainer)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (isAdmin) "ADMIN: EDIT & DELETE" else if (canPrint) "VIEW & PRINT ACCESS" else "OFFICER: READ ONLY",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isAdmin) VmlGoldLight else if (canPrint) VmlBlue else VmlRed
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Statutory reporting module. Officers cannot edit or delete records. Full activity logs show employee login/logout timestamps, credential changes, and system activities.",
                        fontSize = 11.sp,
                        color = VmlSlate,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // Section Tabs
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = VmlNavyDark,
                contentColor = VmlGoldLight,
                edgePadding = 0.dp,
                indicator = { tabPositions ->
                    SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = VmlGold,
                        height = 2.dp
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Business, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Client Institutions (${clientInstitutions.size})", fontSize = 11.sp)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Debtors Registry (${cases.size})", fontSize = 11.sp)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Badge, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Employee Audit (${users.size})", fontSize = 11.sp)
                        }
                    }
                )
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search records by name, reference, email...", color = VmlSlate, fontSize = 11.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = VmlGoldLight) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = VmlGold,
                    unfocusedBorderColor = VmlNavyBorder,
                    focusedContainerColor = VmlNavySurface,
                    unfocusedContainerColor = VmlNavySurface,
                    focusedTextColor = VmlTextPrimary,
                    unfocusedTextColor = VmlTextPrimary
                )
            )
        }

        when (selectedTab) {
            0 -> {
                // TAB 0: CLIENT INSTITUTIONS REPORT
                val filteredClients = clientInstitutions.filter { it.contains(searchQuery, ignoreCase = true) }
                if (filteredClients.isEmpty()) {
                    item { Text("No client institutions found.", color = VmlSlate, fontSize = 12.sp) }
                } else {
                    items(filteredClients) { clientName ->
                        val clientCases = cases.filter { it.creditorName.equals(clientName, ignoreCase = true) }
                        val totalClaim = clientCases.sumOf { it.totalDebt }
                        val totalPaid = clientCases.sumOf { it.amountPaid }
                        val totalBal = (totalClaim - totalPaid).coerceAtLeast(0.0)

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.AccountBalance, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = clientName,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = VmlTextPrimary
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(VmlGoldDim)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = "${clientCases.size} Debtors", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VmlGoldLight)
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(text = "Total Claim Instructed", fontSize = 9.sp, color = VmlSlate)
                                        Text(text = formatUgxShort(totalClaim), fontSize = 12.sp, color = VmlTextPrimary, fontWeight = FontWeight.Bold)
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(text = "Recovered Cash", fontSize = 9.sp, color = VmlSlate)
                                        Text(text = formatUgxShort(totalPaid), fontSize = 12.sp, color = VmlGreen, fontWeight = FontWeight.Bold)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(text = "Net Outstanding", fontSize = 9.sp, color = VmlSlate)
                                        Text(text = formatUgxShort(totalBal), fontSize = 13.sp, color = VmlRed, fontWeight = FontWeight.Black)
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    if (canPrint) {
                                        Button(
                                            onClick = {
                                                val html = PrintUtils.generateClientPortfolioReportHtml(clientName, clientCases)
                                                PrintUtils.printDocument(context, "Report_${clientName.replace(" ", "_")}", html)
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                                            shape = RoundedCornerShape(6.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Icon(Icons.Default.Print, contentDescription = null, tint = VmlNavyDark, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Print Client Report", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VmlNavyDark)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            1 -> {
                // TAB 1: DEBTORS REPORT
                val filteredDebtors = cases.filter {
                    it.debtorName.contains(searchQuery, ignoreCase = true) ||
                            it.caseId.contains(searchQuery, ignoreCase = true) ||
                            it.creditorName.contains(searchQuery, ignoreCase = true)
                }

                if (filteredDebtors.isEmpty()) {
                    item { Text("No debtors found.", color = VmlSlate, fontSize = 12.sp) }
                } else {
                    items(filteredDebtors) { debtor ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(text = debtor.caseId, fontSize = 12.sp, fontWeight = FontWeight.Black, color = VmlGoldLight)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(3.dp))
                                                .background(if (debtor.debtorType.equals("COMPANY", true)) VmlAmberContainer else VmlBlueContainer)
                                                .padding(horizontal = 5.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = debtor.debtorType,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (debtor.debtorType.equals("COMPANY", true)) VmlAmber else VmlBlue
                                            )
                                        }
                                    }
                                    Text(text = debtor.creditorName, fontSize = 10.sp, color = VmlSlate, fontWeight = FontWeight.Bold)
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                Text(text = debtor.debtorName, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                                Text(text = "Sector: ${debtor.sectorOfWork} • Stage: ${debtor.legalStage}", fontSize = 10.sp, color = VmlSlate)

                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "Total: UGX ${formatUgxShort(debtor.totalDebt)}", fontSize = 11.sp, color = VmlTextPrimary)
                                    Text(text = "Paid: UGX ${formatUgxShort(debtor.amountPaid)}", fontSize = 11.sp, color = VmlGreen, fontWeight = FontWeight.Bold)
                                    Text(text = "Balance: UGX ${formatUgxShort(debtor.outstandingBalance)}", fontSize = 11.sp, color = VmlRed, fontWeight = FontWeight.Black)
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (canPrint) {
                                        OutlinedButton(
                                            onClick = {
                                                val payments = allPayments.filter { it.caseId == debtor.caseId }
                                                val html = PrintUtils.generateAccountStatementHtml(debtor, payments)
                                                PrintUtils.printDocument(context, "Debtor_${debtor.caseId}", html)
                                            },
                                            shape = RoundedCornerShape(6.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold.copy(alpha = 0.5f))
                                        ) {
                                            Icon(Icons.Default.Print, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(13.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Print Statement", fontSize = 10.sp, color = VmlGoldLight, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        // Edit: ONLY Admin
                                        if (isAdmin) {
                                            Button(
                                                onClick = { editingCaseItem = debtor },
                                                shape = RoundedCornerShape(6.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = VmlBlueContainer),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                            ) {
                                                Icon(Icons.Default.Edit, contentDescription = null, tint = VmlBlue, modifier = Modifier.size(12.dp))
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text("Edit", fontSize = 10.sp, color = VmlBlue, fontWeight = FontWeight.Bold)
                                            }

                                            Button(
                                                onClick = { casePendingDelete = debtor },
                                                shape = RoundedCornerShape(6.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = VmlRedContainer),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = null, tint = VmlRed, modifier = Modifier.size(12.dp))
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text("Delete", fontSize = 10.sp, color = VmlRed, fontWeight = FontWeight.Bold)
                                            }
                                        } else {
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(VmlNavyDark)
                                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                                            ) {
                                                Text("Edit/Delete: Admin Only", fontSize = 9.sp, color = VmlSlate)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            2 -> {
                // TAB 2: EMPLOYEE AUDIT TRAIL REPORT (LOGIN, LOGOUT, & ACTIVITY)
                val filteredEmployees = users.filter {
                    it.fullName.contains(searchQuery, ignoreCase = true) ||
                            it.email.contains(searchQuery, ignoreCase = true) ||
                            it.role.contains(searchQuery, ignoreCase = true)
                }

                if (filteredEmployees.isEmpty()) {
                    item { Text("No employees found.", color = VmlSlate, fontSize = 12.sp) }
                } else {
                    items(filteredEmployees) { emp ->
                        val empLogs: List<AuditLogEntity> = auditLogs.filter { log: AuditLogEntity ->
                            log.actorUserId == emp.userId || log.actorUserId == emp.email || log.targetId == emp.userId
                        }
                        val lastLoginStr = if (emp.lastLoginAt > 0) {
                            SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(emp.lastLoginAt))
                        } else "Never"

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(32.dp)
                                                .clip(CircleShape)
                                                .background(VmlNavyDark),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Person, contentDescription = null, tint = VmlGoldLight, modifier = Modifier.size(16.dp))
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(text = emp.fullName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                                            Text(text = "${emp.email} • ${emp.role}", fontSize = 10.sp, color = VmlSlate)
                                        }
                                    }

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(if (emp.isLocked) VmlRedContainer else VmlGreenContainer)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = if (emp.isLocked) "LOCKED / CLOSED" else "ACTIVE",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (emp.isLocked) VmlRed else VmlGreen
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "Last Login: $lastLoginStr", fontSize = 10.sp, color = VmlGoldLight)
                                    Text(text = "Audit Events: ${empLogs.size}", fontSize = 10.sp, color = VmlSlate)
                                }

                                // Recent Activity Snippet
                                if (empLogs.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(VmlNavyDark)
                                            .padding(8.dp)
                                    ) {
                                        val latest = empLogs.first()
                                        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(latest.timestamp))
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(text = "LATEST TRAIL: ", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = VmlSlate)
                                                Text(text = latest.action, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = VmlGreen)
                                                Text(text = " ($timeStr)", fontSize = 8.sp, color = VmlSlate)
                                            }
                                            Text(text = latest.details, fontSize = 9.sp, color = VmlTextPrimary, maxLines = 1)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedButton(
                                        onClick = { viewingEmployeeAudit = emp },
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(Icons.Default.History, contentDescription = null, tint = VmlTextPrimary, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("View Login/Logout Trail", fontSize = 10.sp, color = VmlTextPrimary)
                                    }

                                    if (canPrint) {
                                        Button(
                                            onClick = {
                                                val html = PrintUtils.generateEmployeeAuditReportHtml(emp, auditLogs)
                                                PrintUtils.printDocument(context, "Audit_${emp.fullName.replace(" ", "_")}", html)
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                                            shape = RoundedCornerShape(6.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Icon(Icons.Default.Print, contentDescription = null, tint = VmlNavyDark, modifier = Modifier.size(13.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Print Trail", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = VmlNavyDark)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(60.dp))
        }
    }

    // Modal: Full Employee Audit Trail & Activity Logs
    if (viewingEmployeeAudit != null) {
        val emp = viewingEmployeeAudit!!
        val empLogs: List<AuditLogEntity> = auditLogs.filter { log: AuditLogEntity ->
            log.actorUserId == emp.userId || log.actorUserId == emp.email || log.targetId == emp.userId
        }

        Dialog(onDismissRequest = { viewingEmployeeAudit = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
            ) {
                Column(
                    modifier = Modifier
                        .padding(18.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "EMPLOYEE AUDIT TRAIL",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            color = VmlGoldLight,
                            letterSpacing = 1.sp
                        )
                        IconButton(onClick = { viewingEmployeeAudit = null }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = VmlSlate)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = emp.fullName, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = VmlTextPrimary)
                    Text(text = "Role: ${emp.role} • Email: ${emp.email} • ID: ${emp.userId}", fontSize = 11.sp, color = VmlSlate)
                    Text(text = "Department: ${emp.department} • Phone: ${emp.phoneNumber}", fontSize = 11.sp, color = VmlGoldLight)

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "LOGIN & LOGOUT TRAIL / EVENTS (${empLogs.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = VmlGoldLight
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    if (empLogs.isEmpty()) {
                        Text("No audit events recorded for this employee yet.", color = VmlSlate, fontSize = 11.sp)
                    } else {
                        val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.getDefault())
                        empLogs.forEach { logItem: AuditLogEntity ->
                            val timeStr = sdf.format(Date(logItem.timestamp))
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(containerColor = VmlNavySurface),
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, VmlNavyBorder)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = logItem.action,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when (logItem.action) {
                                                "LOGIN_SUCCESS" -> VmlGreen
                                                "LOGOUT" -> VmlSlate
                                                "OVERRIDE_LOGIN" -> VmlRed
                                                "LOGIN_FAILED" -> VmlAmber
                                                else -> VmlBlue
                                            }
                                        )
                                        Text(text = timeStr, fontSize = 9.sp, color = VmlSlate)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = logItem.details, fontSize = 11.sp, color = VmlTextPrimary)
                                    Text(text = "Target: ${logItem.targetEntity} • Device: ${logItem.ipOrDevice}", fontSize = 9.sp, color = VmlSlate)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (canPrint) {
                        Button(
                            onClick = {
                                val html = PrintUtils.generateEmployeeAuditReportHtml(emp, auditLogs)
                                PrintUtils.printDocument(context, "Audit_${emp.fullName.replace(" ", "_")}", html)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = VmlGold),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, tint = VmlNavyDark, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Print Audit Trail Report", color = VmlNavyDark, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Modal: Admin Edit Case
    if (editingCaseItem != null) {
        val target = editingCaseItem!!
        var debtorName by remember { mutableStateOf(target.debtorName) }
        var creditorName by remember { mutableStateOf(target.creditorName) }
        var principalStr by remember { mutableStateOf(target.principalAmount.toString()) }
        var interestStr by remember { mutableStateOf(target.interestAmount.toString()) }
        var penaltiesStr by remember { mutableStateOf(target.penaltiesAmount.toString()) }
        var legalStage by remember { mutableStateOf(target.legalStage) }

        Dialog(onDismissRequest = { editingCaseItem = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, VmlGold)
            ) {
                Column(
                    modifier = Modifier
                        .padding(18.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "ADMIN EDIT: CASE ${target.caseId}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = VmlGoldLight
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = debtorName,
                        onValueChange = { debtorName = it },
                        label = { Text("Debtor Full Name", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = creditorName,
                        onValueChange = { creditorName = it },
                        label = { Text("Creditor Bank", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = principalStr,
                        onValueChange = { principalStr = it },
                        label = { Text("Principal Amount (UGX)", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = interestStr,
                        onValueChange = { interestStr = it },
                        label = { Text("Interest (UGX)", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = legalStage,
                        onValueChange = { legalStage = it },
                        label = { Text("Legal Stage", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            val p = principalStr.toDoubleOrNull() ?: target.principalAmount
                            val i = interestStr.toDoubleOrNull() ?: target.interestAmount
                            val updated = target.copy(
                                debtorName = debtorName,
                                creditorName = creditorName,
                                principalAmount = p,
                                interestAmount = i,
                                legalStage = legalStage
                            )
                            viewModel.updateCase(updated) { success, msg ->
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                editingCaseItem = null
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = VmlGold)
                    ) {
                        Text("Save Changes (Admin Authorized)", color = VmlNavyDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Modal: Admin Delete Confirmation
    if (casePendingDelete != null) {
        val target = casePendingDelete!!
        Dialog(onDismissRequest = { casePendingDelete = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = VmlNavyDark),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, VmlRed)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "ADMIN PERMISSION REQUIRED",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = VmlRed
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Permanently expunge Case ${target.caseId} (${target.debtorName}) from central debt registry?",
                        fontSize = 12.sp,
                        color = VmlTextPrimary
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(onClick = { casePendingDelete = null }) {
                            Text("Cancel", color = VmlSlate)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                viewModel.deleteCase(target.caseId) { success, msg ->
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                    casePendingDelete = null
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = VmlRed)
                        ) {
                            Text("Authorize & Delete", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
